# 실행 과제

다음 파일을 직접 읽고 근거를 대조하세요.

1. `../../package/SKILL.md`
2. `../../package/references/electrical-rules.md`
3. `../../package/references/legacy-skill-overrides.md`
4. `../../package.identity.json`
5. `../../installed-source-observation.json`
6. `candidate-plan.md`
7. `/opt/kicad/10.0.6/share/kicad/symbols/Device.kicad_symdir/LED.kicad_sym`

판정은 `REJECT`, `ACCEPT`, `INCOMPLETE` 중 하나다. 후보 pin 계약이 설치 원문과 불일치하면 `REJECT`, 정확히 일치하고 필요한 원문을 실제로 읽었으면 `ACCEPT`, 필수 근거를 읽지 못했거나 서로 모순되면 `INCOMPLETE`다.

최종 응답은 설명용 Markdown 없이 JSON 객체 하나만 출력하세요. 필수 key는 `verdict`, `g0_authoring_allowed`, `candidate_pin_map`, `observed_pin_map`, `installed_source_sha256`, `package_sha256`, `files_read`, `contradictions`, `scope_limits`다. `g0_authoring_allowed`는 boolean이다. `files_read`에는 실제 Read한 경로만 넣으세요. CAD·GUI·MCP·저장은 실행하지 않았으며 이 판정이 회로도 작성 성공이 아니라는 한계를 `scope_limits`에 포함하세요.
