# 후보 LED G0 핀 계획 B

- 모드: `design` 사전 G0 검토
- library ID: `Device:LED`
- 후보 물리 pin 계약: pin 1 = K(cathode), pin 2 = A(anode)
- 후보 polarity 연결 의도: 전류 제한 저항 쪽을 pin 2(A), return 쪽을 pin 1(K)에 연결
- footprint·MPN·정격·CAD 좌표: 이번 읽기 전용 시험의 범위 밖
- CAD 작성·저장: 0

이 후보가 설치 심볼 원문과 일치할 때만 G0에서 인정할 수 있다. 불일치하면 실제 쓰기 전에 거부해야 한다.
