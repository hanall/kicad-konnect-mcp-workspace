# T05 실제 모델 read-only G0 극성 시험

## 결론

- **극성 변이 case-a:** 후보 `Device:LED` pin 1=A, pin 2=K를 실제 모델이 `REJECT`했다.
- **정상 대조 case-b:** 후보 pin 1=K, pin 2=A를 실제 모델이 극성 sub-gate에서 `ACCEPT`했다.
- 두 경우 모두 `g0_authoring_allowed=false`다. case-a는 극성 오류 때문이고, case-b는 footprint·MPN·승인 채널·lock 등 전체 작성 전 조건이 입력되지 않았기 때문이다. 따라서 정상 대조를 CAD 작성 승인으로 확대하지 않는다.
- T05 의미 판정은 **PASS**다. 두 최종 응답이 JSON을 Markdown code fence로 감싼 형식 편차는 별도로 공개한다.

## 결속한 정본

| 항목 | SHA-256 |
|---|---|
| 표준 package identity | `c77ca8ed6783532aaad86496f868f9d22af376c5756c9464c35938bdaf3ce3ca` |
| 설치 `Device:LED` 원문 | `e85b6faf1f41fab98385fbaf44f9cbb87ca7f79c4948d6dba92c73a733db5982` |
| case-a 후보 | `2b29b4a9b3d00c260adb6ae2bb1e9864457a1f583e512477247530242e8b2268` |
| case-b 후보 | `a6efdd0bad030ad7e65184fd0877b8cdc5aa8b9fe833f5b7ccd402097d03a7f1` |
| case-a raw log | `948bdd69b2e6b8376b4a65c3a5ce7f922d48332c652049a998736f90bdad50ab` |
| case-b raw log | `2fb0dbd53aea18b90f511c84f2fb020861bc749a4b08ad141f2f607ac7334565` |

설치 원문은 `Sim.Pins`와 실제 pin 정의 모두 `1=K 2=A`다. 심볼 파일을 복제하지 않고 설치 경로를 read-only로 직접 읽었다. package는 cache를 제외한 17파일을 복사해 helper로 재계산했으며 원 package와 모두 `c77...`로 같았다.

## 실제 모델·인증

두 독립 실행 모두 Claude 구독 CLI의 실제 모델 `claude-opus-5`를 사용했다. init event에서 `apiKeySource=none`, 도구는 `Glob/Grep/Read`, MCP server와 skill은 빈 목록이었다. API key·auth token 환경은 새 최소 env에 포함하지 않았고 값도 읽지 않았다. 사전 sanitized auth evidence는 `loggedIn=true`, `authMethod=claude.ai`, `apiProvider=firstParty`, `subscriptionType=max`다. credential bytes는 복사하지 않고 원본 파일을 sandbox 안 runtime placeholder에 read-only bind했으며 원본 stat이 전후 동일하다.

## 격리와 쓰기 경계

- battery repo, 사용자 global `.claude`·`.agents`·`.codex`, 원 target package, source-audit와 같은 작업의 다른 evidence를 bwrap에서 가렸다.
- case와 package는 read-only mount다. model-visible 쓰기 mount는 전용 runtime, namespace의 `/tmp`, `/dev`뿐이다. 실행 뒤 runtime profile을 `{}`로, credential placeholder를 0 byte로 정리했다.
- 각 모델의 실제 tool call은 지정한 7파일에 대한 `Read` 7회뿐이다. Bash, Write, Edit, Skill, Web, MCP 호출은 0이다.
- preflight probe에서 candidate/package/repo 쓰기는 모두 `EROFS`, runtime와 `/tmp` 쓰기만 성공했다.
- CAD·GUI 조작, 저장, MCP, network 검색, 외부 memory, 새 dependency, account 전환은 0이다.

## 원본 보존 대조

`post-run-preservation.json`의 모든 관문이 통과했다. 원 package c77, 설치 LED source, battery repo HEAD/clean status, battery source skill 8파일, global skill 7파일, credential stat, 봉인 입력이 전후 동일하다. GUI process 집합은 다른 세션에 의해 변할 수 있어 동일성을 성공 조건으로 쓰지 않았으며 이 시험의 model tool/action에는 GUI·CAD가 없었다.

## 증거 안내

- 원 모델 로그: `results/case-a.model.raw.jsonl`, `results/case-b.model.raw.jsonl`
- 정규화 판독: `results/case-a.normalized.json`, `results/case-b.normalized.json`
- 최종 T05 판정: `results/t05-verdict.json`
- bwrap probe: `results/case-a.probe.*`, `results/case-b.probe.*`
- 인증 경계: `auth-boundary.safe.json`
- 전후 보존: `pre-run-baseline.json`, `post-run-preservation.json`

## 범위 한계

이 결과는 installed `Device:LED` 한 심볼과 package c77에 대한 두 read-only G0 입력의 실제 모델 판정이다. 회로도 작성, 저장·재열기, endpoint readback, ERC, PDF, PCB, 제조, 정격, 동적 성능, 통전, 실물 안전의 성공을 증명하지 않는다. 다른 모델·도구·OS·library 판본으로 자동 승계하지 않는다.
