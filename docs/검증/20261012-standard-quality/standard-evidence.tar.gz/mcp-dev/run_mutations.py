from __future__ import annotations

import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parents[3]
source_path = root / "skills/kicad-schematic-quality/scripts/guarded_mcp.py"
source = source_path.read_text(encoding="utf-8")
mutants = Path(__file__).resolve().parent / "mutants"
mutants.mkdir(exist_ok=True)
shutil.copy2(source_path.parent / "package_identity.py", mutants / "package_identity.py")

mutations = [
    ("M01-review-write", 'if self.mode == "review":', 'if False and self.mode == "review":'),
    ("M02-all-plans-flag", 'if not self.require_all_plans_before_write:', 'if False and not self.require_all_plans_before_write:'),
    ("M03-unknown-tool", 'if tool in READ_TOOLS:', 'if tool in READ_TOOLS or tool == "brand_new_safe_write":'),
    ("M04-runtime-version", 'if not runtime_matches:', 'if False and not runtime_matches:'),
    ("M05-empty-toolset", 'if needed_toolsets:', 'if True or needed_toolsets:'),
    ("M06-evidence-outside", 'raise AdapterError("evidence-dir은 workspace-root 안이어야 합니다") from error', 'return resolved'),
    ("M07-editor-lock", 'self._assert_no_editor_locks()', 'None  # 변이: editor lock 검사 제거'),
    ("M08-index-change", 'self._assert_index_unchanged()', 'None  # 변이: plan-index 변경 검사 제거'),
    ("M09-schema-pollution", 'or not isinstance(item.get("inputSchema"), dict)', 'or False'),
    ("M10-symbol-unit", 'self._validate_symbol_units(args)', 'None  # 변이: symbol unit 검사 제거'),
    ("M11-read-only", 'if blocked:', 'if False and blocked:'),
    ("M12-serving-config", 'if selected != expected_config:', 'if False and selected != expected_config:'),
    ("M13-global-library", 'if scope != "project":', 'if False and scope != "project":'),
    ("M14-allowed-symlink", 'if raw_target.is_symlink():', 'if False and raw_target.is_symlink():'),
    ("M15-critical-signatures", 'self._validate_critical_mutation_contract(tool, prepared.arguments)', 'None  # 변이: critical signature 검사 제거'),
    ("M16-owning-root-erc", 'if tool == "run_erc" and schematic != self.root_schematic:', 'if False and tool == "run_erc" and schematic != self.root_schematic:'),
    ("M17-pin-zero-false-green", 'if tool == "get_symbol_info":', 'if False and tool == "get_symbol_info":'),
    ("M18-writer-lock-symlink", 'flags |= os.O_NOFOLLOW', 'flags |= 0  # 변이: symlink follow 차단 제거'),
    ("M19-pcb-save-tool", 'if tool in READ_TOOLS:', 'if tool in READ_TOOLS or tool == "save_project":'),
    ("M20-library-declared-exact", 'if value != declared_value:', 'if False and value != declared_value:'),
    ("M21-evidence-symlink", 'def validate_evidence_dir(path: Path, policy: ProjectPolicy) -> Path:\n    if path.is_symlink():', 'def validate_evidence_dir(path: Path, policy: ProjectPolicy) -> Path:\n    if False and path.is_symlink():'),
    ("M22-backend-final-identity", 'except AdapterError as backend_error:\n                session_rc = 1\n                backend_final_error = str(backend_error)', 'except AdapterError as backend_error:\n                session_rc = session_rc\n                backend_final_error = None'),
    ("M23-review-board-path", 'if "board" in args:', 'if False and "board" in args:'),
    ("M24-cad-intent-toctou", 'if (\n            intent.get("before_cad_hash") != current_hash\n            or intent.get("before_cad_hashes") != current_hashes\n        ):', 'if False:'),
    ("M25-close-broken-pipe", 'except (BrokenPipeError, OSError):', 'except EOFError:'),
    ("M26-power-flag-net", 'if args["power_net"] == "PWR_FLAG":', 'if False and args["power_net"] == "PWR_FLAG":'),
    ("M27-power-flag-new-lib", 'for key in ("lib_id", "new_lib_id")', 'for key in ("lib_id",)'),
    ("M28-mutation-no-change", 'if not changed_targets:', 'if False and not changed_targets:'),
    ("M29-mutation-target-drift", 'if unexpected:', 'if False and unexpected:'),
    ("M30-package-identity", 'package_identity.assert_unchanged(package_start)', 'package_start  # 변이: package 재대조 제거'),
    ("M31-dry-run-classification", 'if args["dry_run"] is True:', 'if False and args["dry_run"] is True:'),
    ("M32-symbol-pin-count", 'if type(pin_count) is not int or pin_count < 1:', 'if False and (type(pin_count) is not int or pin_count < 1):'),
    ("M33-symbol-name", 'if "name" not in pin or not isinstance(pin["name"], str):', 'if False and ("name" not in pin or not isinstance(pin["name"], str)):'),
    ("M34-symbol-type", 'if not isinstance(pin.get("type"), str) or not pin["type"]:', 'if False and (not isinstance(pin.get("type"), str) or not pin["type"]):'),
    ("M35-symbol-unit", 'if type(pin.get("unit")) is not int or pin["unit"] < 1:', 'if False and (type(pin.get("unit")) is not int or pin["unit"] < 1):'),
    ("M36-mutation-negative-outcome", 'if isinstance(status, str) and status.lower() in {', 'if False and isinstance(status, str) and status.lower() in {'),
    ("M37-plan-schema-version-type", 'or type(index.get("schema_version")) is not int', 'or False'),
]

results = []
for name, before, after in mutations:
    count = source.count(before)
    if count < 1:
        raise SystemExit(f"변이 표적 누락: {name}: {before}")
    mutated = source.replace(before, after)
    mutant = mutants / f"{name}.py"
    mutant.write_text(mutated, encoding="utf-8")
    env = os.environ.copy()
    env["STANDARD_GUARDED_MCP_PATH"] = str(mutant)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    completed = subprocess.run(
        [sys.executable, "-m", "unittest", "tests/test_standard_quality_mcp.py"],
        cwd=root,
        env=env,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=30,
        check=False,
    )
    (mutants / f"{name}.log").write_text(completed.stdout, encoding="utf-8")
    results.append(
        {
            "name": name,
            "replacement_count": count,
            "test_rc": completed.returncode,
            "caught": completed.returncode != 0,
        }
    )

summary = {
    "schema_version": 1,
    "source": str(source_path),
    "test_command": "python3 -m unittest tests/test_standard_quality_mcp.py",
    "mock_boundary": "Fake MCP transport only; native KiCad/Konnect success is not claimed.",
    "mutation_count": len(results),
    "caught_count": sum(item["caught"] for item in results),
    "results": results,
}
output = Path(__file__).resolve().parent / "mutation-results.json"
output.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps(summary, ensure_ascii=False, indent=2))
if not all(item["caught"] for item in results):
    raise SystemExit(1)
