# 외부 KiCad 스킬 7파일 전수 주장 감사

## 결론

- **판정:** 사용자 global의 legacy `0.2.2` 지침은 current pinned Konnect에 직접 재사용하면 안 된다. 새 `kicad-schematic-quality` 오버레이가 잘못된 호출 서명, library ID, 극성, audit 범위, 제조 경계를 교정해야 한다.
- 검토 대상은 7/7파일, 누락 0이다. 각 파일의 전체 줄 범위와 모든 heading group을 아래 표에 대응시켰다.
- global 7파일 중 pinned asset과 동일한 파일은 `error-taxonomy.md` 1개뿐이다. 동일하다는 사실은 내용 타당성을 뜻하지 않는다.
- fresh STDIO 증거는 실제 build `0.13.0+hanall.1`, commit `94f80350...`, pinned executable을 확인했다. `response-0005.json`의 130 schema는 명시적으로 로드한 9 toolset의 목록일 뿐 **전체 지원 도구 수가 아니다**.
- fresh runtime HOME의 guidance `missing`은 격리 HOME에 설치하지 않았다는 뜻이며 사용자 global 스킬의 발견 실패 증거가 아니다.
- fresh symbol query에서 4개 구 ID는 의도대로 `isError=true`였지만, 이는 global 문서의 구식 반례이지 이번 작업의 미해결 제품 오류 4건이 아니다. 반대로 `Amplifier_Operational:LM358`는 `isError=false`이면서 `pin_count=0`, `pins=[]`여서 **호출 성공만으로 pin 전수 확인을 주장할 수 없음**도 확인됐다.
- 실제 모델·GUI·live IPC·CAD 쓰기·정식 package 쓰기는 수행하지 않았다. 제품 정격 검토도 범위 밖이다.

## 정본과 증거

| 항목 | 값 |
|---|---|
| 사용자 global marker | `0.2.2`, `.guidance-checked-claude` 상태 `out_of_sync` |
| pinned upstream | `94f80350cf67db27b179a06a8f6dbebfe4717927` |
| fresh installation evidence | `fresh-schema/response-0003.json`, SHA-256 `5e7bd38ea90b383cc5d664b0b43be20807e792c8a1531ca3107abb6d2508d7c0` |
| fresh subset schema | `fresh-schema/response-0005.json`, SHA-256 `d2970574e5dcff250bca232e9e3632d4cc8df020ab4e4c68a3adf7c045138232` |
| subset 범위 | `project`, `library`, `sch_components`, `sch_wiring`, `sch_analysis`, `sch_batch`, `sch_export`, `verification`, `design_review` |
| subset schema 수 | 130, 전체 수로 해석 금지 |
| static source | pinned registry/schema/handler와 설치 KiCad 10.0.6 `*.kicad_symdir` |
| 쓰기 | 이 `source-audit/`의 JSON·MD만 |

## 파일 SHA

| 파일 | 줄 | global SHA-256 | pinned asset SHA-256 | 동일 |
|---|---:|---|---|---:|
| `konnect/SKILL.md` | 138 | `9a5620117a5b611870e23729f60b44deb13f21f8b8612a35b14a3a65ef1bf195` | `d2b60e075339937f0230e0660d5821236ea6f746eccd176479ea737f40d00f6b` | 아니오 |
| `kicad-schematic/SKILL.md` | 234 | `913c4a3ad7cb2d75729820bc8a5c9a4c370eaf71f9231562b464f4904d2e2392` | `75ed3bcb86c299df05be77753b2a316fae196f82070a5cfe850614de6b090605` | 아니오 |
| `kicad-schematic/references/common-lib-ids.md` | 84 | `898a0e40d107b72ade9d45268f6aa73565b5e1b01542e22a51ed8776290c7ef9` | `ec9e215b15d22a6fc3046f482015a1b96e220ac45b49f9fe3216e46013053a82` | 아니오 |
| `kicad-schematic/references/wiring-patterns.md` | 88 | `8b7ae5cd58463279b66af6688533637f67c95312f33cad7d6a508d68c3c787ac` | `8a50539181553573dd6d8de2bad223dde121406502f2c8c16ed99dada5d6be6a` | 아니오 |
| `kicad-review/SKILL.md` | 306 | `c71ba3e27f3deeaa9b697a084b7fd8d0064aced9d84c56708ba08b21d8bf40ab` | `f9f4e8e527b1aab57f6882e4122b81d5f9015e79d702dac47b7970214e260c47` | 아니오 |
| `kicad-review/references/design-checklist.md` | 80 | `b172bd293a0f5ce51d22370dde0a8b51aea99bdd4746d02fc98e5378f5ced84d` | `87ce875772bdca9f5d14d774a3d24803bff86e59dd96558a2e19a9598a1cb1e4` | 아니오 |
| `kicad-review/references/error-taxonomy.md` | 72 | `14f4d53338d23db57aebc02748fb4462b428be88619c084b952d390ea679bc9d` | `14f4d53338d23db57aebc02748fb4462b428be88619c084b952d390ea679bc9d` | 예 |

## 최종 차단 목록

| ID | 주제 | 차단 사유 | 새 표준 교정 |
|---|---|---|---|
| B01 | legacy drift | global marker `0.2.2`; 7파일 중 6개가 pinned asset과 다르다. | global은 수정하지 않고 portable overlay가 legacy 주장을 override한다. |
| B02 | 잘못된 호출 서명 | `connect_pins`, `connect_to_net`, `add_power_symbol` 예시 required fields가 fresh schema와 다르다. | current schema 미확인 호출은 쓰기 전 거부한다. |
| B03 | 없는 library ID | Device transistor 4종, `Ferrite_Bead`, 구 MCP1700/CP2102 ID가 설치 KiCad 10.0.6에 없다. | search/get 정보와 physical pin map 없이는 배치하지 않는다. |
| B04 | polarity 반전 | wiring pattern이 `Device:LED`를 pin 1=A, 2=K로 배선한다. 실제는 1=K, 2=A다. | polarity mutation과 query-back을 필수 gate로 둔다. |
| B05 | phantom tool | `audit_esd_protection`은 pinned registry와 fresh 9-toolset schema에 없다. | 미지원 항목은 manual/profile 검토로 남기며 다른 audit 성공으로 대체하지 않는다. |
| B06 | 거짓 full review | `run_design_review`는 ERC와 `find_orphan_items`/`find_shorted_nets`/`find_single_pin_nets`를 실행하지 않는다. | direct ERC·connectivity와 aggregate audit를 독립 실행·대조한다. |
| B07 | audit 범위 과장 | decoupling/connection/power/manufacturing 문서 주장이 handler보다 넓다. | handler가 반환한 실제 coverage만 주장한다. |
| B08 | 저장 의미 오류 | `save_project`는 fresh schema상 인자 없는 도구이고 source상 live PCB IPC save다. offline schematic 저장이 아니다. | schematic edit의 atomic commit/readback와 file SHA를 저장 증거로 쓴다. |
| B09 | PWR_FLAG 오용 | ERC 경고 제거 일반 처방으로 서술한다. | 실제 외부/수동 power source를 모델링할 때만 사용한다. |
| B10 | 제조승인 확대 | DRC/audit/`READY`를 제조·발주 승인으로 오해할 수 있다. | 산출물, BOM/CPL, fab profile, order preview, 사람/명시 승인을 별도 gate로 둔다. |
| B11 | symbol 성공 false-green | `get_symbol_info(LM358)`가 `isError=false`지만 pin 0개를 반환했다. 상속 symbol 해석 한계 가능성이 있으며 성공 flag만으로 pin map 완전성을 주장할 수 없다. | `isError=false` AND 기대 pin coverage·단위·번호·이름·physical map이 모두 충족돼야 수용한다. |

## 파일별 절 전수 판정

분류는 `현재일치`, `구식`, `과잉일반화`, `불충분`, `환경조건부`만 사용했다. 한 절에 복수 판정이 가능하다.

### `konnect/SKILL.md` 전체 1-138

| 줄 | 절 | 분류 | 주요 주장과 판정 근거 | 필요한 교정 |
|---:|---|---|---|---|
| 1-4 | frontmatter | 과잉일반화 | 모든 KiCad 작업에 강제되고 Konnect가 손상을 방지한다고 한다. 읽기 작업과 target의 승인 GUI 예외를 포괄하지 못한다. | 핵심을 직접 텍스트 쓰기 금지로 좁히고 실제 허용 채널은 프로젝트 정책에서 정한다. |
| 6-23 | 단일 규칙·보호 파일 | 과잉일반화/환경조건부 | 보호 목록과 raw write 금지는 맞지만 MCP-only/no-exception은 승인 GUI와 충돌한다. | MCP·승인 GUI·project adapter 중 schema/lock/승인이 확인된 하나만 사용한다. |
| 25-37 | 세 채널 | 불충분/환경조건부 | export 우선과 raw read 최후 수단은 안전하지만 보존 검증, 열린 편집기, GUI 예외가 없다. | 읽기 출처와 쓰기 권한을 분리하고 raw read는 허용하되 raw write는 금지한다. |
| 39-46 | 표준 순서 | 불충분 | outcome/source/coverage/recovery, build/schema, lock/revision, 저장본 SHA가 없다. 재조회 하나로 전체 완료를 증명할 수 없다. | 전후 SHA·target·schema·outcome·readback·native check를 결속한다. |
| 48-61 | 결정표 | 구식/불충분 | 회로 검토가 `sch_analysis`에 그치고 제조 준비를 verification+review로 축약한다. | ERC/render/requirements와 제조 artifact gate를 분리한다. |
| 63-71 | IPC 설명 | 과잉일반화/환경조건부 | PCB의 “모든 객체 full CRUD”는 실제 registry와 live guard보다 넓다. | capability를 fresh schema와 source provenance로 확인한다. |
| 73-96 | discovery/toolset | 구식 | 187/18 고정 수와 목록은 stale이다. pinned registry에는 `sch_bus`, `placement`도 있다. | 고정 수 삭제. fresh 130도 9-toolset subset일 뿐 전체 수가 아니다. |
| 98-106 | quick design rules | 과잉일반화/환경조건부 | decoupling 거리, reset, I2C, LED 값을 범용 상수로 둔다. | 수치는 datasheet/profile/calculation 입력으로 이동한다. |
| 108-117 | common IDs | 현재일치/불충분 | 기초 ID는 존재하지만 generic symbol이 MPN/package/pad 적합성을 증명하지 않는다. | physical pin map을 별도 승인한다. |
| 119-129 | tool usage | 구식 | `verification`을 불러 `run_erc`/`run_design_review`를 부른다. fresh mapping은 각각 `sch_export`/`design_review`다. | 실제 toolset과 필수 `schematic` 인자를 사용하고 결과를 독립 판독한다. |
| 131-138 | refusal | 현재일치/불충분 | raw write 거부는 맞지만 동의 뒤 schema·lock·readback이 빠진다. | 동의는 권한일 뿐 성공 조건이 아니며 guard 실패 시 중단한다. |

### `kicad-schematic/SKILL.md` 전체 1-234

| 줄 | 절 | 분류 | 주요 주장과 판정 근거 | 필요한 교정 |
|---:|---|---|---|---|
| 1-15 | scope·쓰기 원칙 | 현재일치/환경조건부 | raw `.kicad_sch` 쓰기 금지는 맞지만 GUI 예외와 읽기 전용 모드가 없다. | 신규/재작성/전기변경/읽기전용을 먼저 분리한다. |
| 17-34 | toolset loading | 구식/불충분 | 후반에 항상 쓰는 validator는 `sch_batch`, ERC는 `sch_export`, orphan은 `sch_analysis`인데 필수 로딩에 없다. | 검증 계획에 맞춰 세 toolset을 명시 로드한다. |
| 38-46 | placement workflow | 현재일치/불충분 | search/get/query-back은 유효하지만 library pin이 actual package 적합성을 증명하지 않는다. | exact MPN/package pin map과 disposable render를 추가한다. |
| 47-68 | common ID 표 | 구식 | `Device:Q_NPN_BCE`, `Q_PNP_BCE`, `Q_NMOS_GDS`, `Q_PMOS_GDS`는 설치본에 없다. | `Transistor_BJT`/`Transistor_FET` current ID를 조회 후 사용한다. |
| 70-77 | rotation | 구식/과잉일반화 | 180도 회전을 horizontal flip과 동일시한다. 비대칭 symbol에서 rotation과 mirror는 다르다. | rotation/mirror를 분리하고 render로 확인한다. |
| 79-84 | spacing | 환경조건부 | schematic 가독성 휴리스틱이지 PCB 거리·전기 성능이 아니다. | page/profile 시각 규칙으로만 둔다. |
| 88-99 | wiring decision | 과잉일반화/환경조건부 | 30mm 경계와 “named signal=label”은 임의이며 실선 가독성을 해칠 수 있다. | 로컬 기능블록은 solid wire 우선, 경계에서만 scope가 명시된 label을 쓴다. |
| 101-111 | `connect_pins` | 구식 | old 예시는 4개 인자다. fresh required는 `schematic/ref1/pin1/ref2/pin2`. | old signature를 write 전 거부한다. |
| 113-124 | `connect_to_net` | 구식/불충분 | old 예시는 `component_reference/pin_number/net_name`. fresh는 `schematic+net`과 ref/pin 또는 좌표다. | stub/direction/label scope와 solid-wire readback을 확인한다. |
| 126-136 | `add_power_symbol` | 구식/과잉일반화 | old 예시는 component/pin 기반 자동 배치다. fresh required는 `schematic/power_net/x/y`. | pin endpoint 좌표와 global scope를 검증한다. |
| 140-163 | batch | 현재일치/불충분 | 도구는 존재하지만 fresh `batch_connect_to_net` 기본 `stub_length=0`은 wire 없는 label이다. | quality mode에서 명시 stub 또는 waiver, partial result와 junction count를 판독한다. |
| 167-185 | common patterns | 과잉일반화/환경조건부 | topology는 참고 가능하지만 100nF/5mm, I2C, LED, crystal 값은 환경 의존이다. | parameterized profile과 원문 계산으로 이동한다. |
| 189-219 | post-placement | 구식/불충분 | wire validator는 floating endpoint만 보며 overlap을 검사하지 않는다. component validator도 의도된 연결을 모른다. ERC/short/render가 없고 `save_project`는 live PCB save다. | annotate dry-run, validators, short/orphan, root ERC, render/PDF, current SHA를 분리한다. |
| 223-234 | rules | 과잉일반화/구식 | power symbol/label/save/batch를 절대화한다. pin 조회도 physical package map을 대체하지 않는다. | scope·solid line·physical pin map·실제 저장 semantics를 명시한다. |

### `kicad-schematic/references/common-lib-ids.md` 전체 1-84

| 줄 | 절 | 분류 | 주요 주장과 판정 근거 | 필요한 교정 |
|---:|---|---|---|---|
| 1-2 | 문서 범위 | 불충분 | 목록이 quick-start일 뿐 allowlist/MPN 증거가 아님을 밝히지 않는다. | active library 조회와 physical pin map 우선 규칙을 앞에 둔다. |
| 3-27 | passive/semiconductor | 구식/불충분 | Device transistor 4종과 `Device:Ferrite_Bead`가 설치본에 없다. | `Transistor_BJT/FET`, `Device:FerriteBead` 존재를 확인하고 polarity/package map을 요구한다. |
| 29-39 | connectors | 현재일치/환경조건부 | generic header ID는 존재하지만 실제 mating view/numbering을 증명하지 않는다. | exact connector datasheet map으로 교체·검증한다. |
| 41-55 | power/PWR_FLAG | 과잉일반화/불충분 | PWR_FLAG를 ERC 해결 일반 수단으로 보인다. 실제 symbol은 power source를 알리는 `power_out`이다. | 실제 source 근거가 있을 때만 사용하고 경고 숨김을 금지한다. |
| 57-63 | regulators | 구식/환경조건부 | 구 `MCP1700-3302E_SOT23` ID는 없고 current는 `MCP1700x-330xxTT`다. 정격도 thermal 조건부다. | current ID와 exact MPN datasheet를 분리 확인한다. |
| 65-70 | interface IC | 구식 | 구 `CP2102N-A02-GQFN24`는 없고 current generic ID는 `CP2102N-Axx-xQFN24`다. | exact suffix와 library ID를 함께 확인한다. |
| 72-76 | MCU | 현재일치/과잉일반화 | STM32 ID는 존재하지만 F103 symbol 자체가 특정 Blue Pill board를 뜻하지 않는다. | MCU symbol과 module/board를 구분한다. |
| 78-84 | usage | 현재일치/과잉일반화 | search/value 지침은 유효하다. power symbol은 endpoint attachment가 필요하고 PWR_FLAG 문구는 너무 강하다. | ID·endpoint·scope·ERC 전후를 각각 검증한다. |

### `kicad-schematic/references/wiring-patterns.md` 전체 1-88

| 줄 | 절 | 분류 | 주요 주장과 판정 근거 | 필요한 교정 |
|---:|---|---|---|---|
| 1-15 | decoupling | 불충분/환경조건부 | power symbol은 좌표 기반이며 exact endpoint가 필요하다. schematic 근접은 PCB 근접 증거가 아니다. | connectivity와 PCB placement를 별도 검사한다. |
| 16-27 | pull-up | 환경조건부 | topology는 유효하나 4.7k와 direction은 bus/layout 조건부다. | bus 계산과 render를 우선한다. |
| 28-35 | divider | 불충분 | ratio/load/tolerance/power/ADC acquisition 조건과 solid-wire readback이 없다. | calculation profile과 net/wire query를 요구한다. |
| 36-40 | LED | 구식 | 문서는 pin1=A, pin2=K로 쓴다. 설치 `Device:D`/`Device:LED`는 1=K, 2=A다. | polarity mutation과 pin-map gate를 필수화한다. |
| 42-50 | crystal | 환경조건부/불충분 | topology는 일반적이나 CL/Cstray/drive/pin은 exact 원문 의존이다. | exact crystal/MCU 원문과 계산을 입력으로 받는다. |
| 52-61 | USB-C sink | 환경조건부/과잉일반화 | template ID는 pinned source에 있고 query가 ID에도 매칭된다. 그러나 template은 compliance/제조 검증이 아니다. | 요구·USB revision·connector pin map·ESD profile과 대조한다. |
| 63-72 | decision guide | 현재일치/불충분 | 도구는 존재하지만 batch 기본은 wire 없는 endpoint label이고 power symbol은 global이다. | solid stub/wire 또는 waiver와 intended scope를 요구한다. |
| 74-81 | label types | 현재일치/불충분 | 기본 scope는 맞지만 repeated instance 분리와 hierarchical pin sync가 없다. | instance scope와 sheet pin/label sync를 검증한다. |
| 83-88 | spacing/junction | 환경조건부 | spacing은 visual profile이며 자동 junction이 전체 배선 품질을 보증하지 않는다. | render/layout/net readback으로 검증한다. |

### `kicad-review/SKILL.md` 전체 1-306

| 줄 | 절 | 분류 | 주요 주장과 판정 근거 | 필요한 교정 |
|---:|---|---|---|---|
| 1-14 | scope | 과잉일반화/환경조건부 | MCP 우선은 안전하지만 export/native CLI/read-only source inspection까지 금지할 이유는 없다. | read authority와 write prohibition을 분리한다. |
| 17-37 | toolset loading | 현재일치/불충분 | 주요 mapping은 맞지만 target/source/coverage 조건이 없다. | 대상에 맞는 subset과 fresh schema/source를 기록한다. |
| 41-53 | orphan | 과잉일반화 | “거의 항상 버그”가 아니다. pinned판도 heuristic candidate로 교정했다. | ERC/direct connectivity로 corroborate한다. |
| 54-66 | short | 과잉일반화 | 검출 candidate가 requirement상 intentional tie/alias인지 확인 전 항상 critical이라 할 수 없다. | confirmed unintended short만 critical로 분류한다. |
| 67-77 | single-pin | 과잉일반화 | hierarchy/global/testpoint/intentional stub가 file-local one-pin처럼 보일 수 있다. | scope flag와 hierarchy/ERC를 대조한다. |
| 80-95 | ERC | 불충분/환경조건부 | fresh schema는 root `schematic` 필수다. source상 child sheet는 owning root를 명명해 거부하며 hierarchy 전체를 검사한다. | 원 report/rc/severity/exclusion/sheet coverage를 기록한다. |
| 97-112 | DRC | 현재일치/불충분 | direct DRC 권위는 맞지만 source/owner/category/rc가 없고 clean DRC는 제조 승인과 다르다. | native 항목·owner·missing category·saved/live source를 보존한다. |
| 115-130 | decoupling audit | 과잉일반화 | handler는 schematic 같은-net capacitor만 본다. `pcb_distance_checked=false`; 값·bulk·high-current·PCB 거리는 미검사다. | connectivity heuristic로만 쓰고 value/PCB를 별도 검사한다. |
| 131-142 | connection audit | 과잉일반화 | handler는 I2C와 reset pull-up만 검사한다. expected fanout/SI/enable/LED/floating/output-short는 미검사다. | 실제 handler coverage만 보고하고 나머지는 요구 기반 net contract로 검사한다. |
| 143-155 | power audit | 과잉일반화 | handler는 cap/bulk>=10uF heuristic과 testpoint만 본다. source/current/voltage/sequence/PWR_FLAG는 미검사다. | rating/profile/ERC evidence를 별도 사용한다. |
| 156-169 | manufacturing audit | 과잉일반화 | handler는 Edge.Cuts 문자열 존재, 양면 조립, 제한 silk overlap, min trace 일부만 본다. spacing/via/acid/closed-outline 등도 전부 검사하지 않는다. | 제한 heuristic로 표시하고 DRC·closed outline·drill/pad·artifact를 별도 검사한다. |
| 172-191 | full review shortcut | 구식 | global은 9개 검사를 모두 실행한다고 한다. 실제 handler는 hierarchy 4 audits, board가 있으면 manufacturing+DRC다. ERC/find 3종은 없다. | aggregate를 direct check 대체로 쓰지 않는다. |
| 194-207 | critical 표 | 과잉일반화/환경조건부 | 위험 예시는 타당하나 tool이 polarity/absolute max를 자동 입증하지 않는다. | native severity+requirements+datasheet로 결정한다. |
| 208-218 | warning 표 | 과잉일반화/환경조건부 | ESD/testpoint/redundancy/near-limit는 제품과 fab profile에 따라 달라진다. | applicability 근거를 남긴다. |
| 219-229 | suggestion 표 | 환경조건부 | 유용한 후보지만 모든 unnamed net label화·closer placement는 다른 품질과 충돌할 수 있다. | tradeoff와 visual review를 거친 후보로만 둔다. |
| 232-264 | report format | 구식/불충분 | PASS/FAIL count만으로 coverage·not-run·contradiction을 표현하지 못한다. | source/coverage/diagnostics와 `INCOMPLETE`를 추가한다. |
| 268-275 | quick review | 불충분 | direct checks는 유용하지만 exact target/source/result coverage가 없다. | root schematic/board와 original result를 결속한다. |
| 277-284 | full review | 구식 | `run_design_review` 단독은 comprehensive가 아니다. 읽기 전용인데 즉시 fix 제안도 충돌할 수 있다. | direct+aggregate를 대조하고 review mode에서는 쓰지 않는다. |
| 285-292 | pre-manufacturing | 불충분/과잉일반화 | `validate_for_manufacturing`는 board 기반 제한 preflight다. BOM/CPL/artifact/order preview 없이 제조 ready를 확정할 수 없다. | 제한 verdict와 실제 제조/발주 승인을 분리한다. |
| 295-306 | review rules | 현재일치/불충분 | 재검증/waiver 기록은 좋다. `save_project`는 schematic 저장이 아니고 read-only fix 금지가 빠졌다. | saved/live identity와 review mode를 보존한다. |

### `kicad-review/references/design-checklist.md` 전체 1-80

| 줄 | 절 | 분류 | 주요 주장과 판정 근거 | 필요한 교정 |
|---:|---|---|---|---|
| 1-12 | schematic power | 과잉일반화/환경조건부 | 100nF, 10-100uF, reverse protection, indicator, PWR_FLAG를 일반 필수처럼 둔다. | applicability와 datasheet/profile source를 둔다. |
| 13-20 | signal integrity | 과잉일반화/환경조건부 | I2C/SPI/reset/crystal/ADC 규칙은 bus/MCU/device 의존이다. | exact device/bus 계산으로 검증한다. |
| 21-26 | protection | 환경조건부 | 유용한 hazard prompt지만 voltage/domain/environment/topology에 따라 부품이 달라진다. | interface threat/rating profile을 근거로 적용한다. |
| 27-32 | connectivity | 과잉일반화 | 모든 pin 연결·모든 net 2개 이상은 NC, off-sheet, testpoint 사례를 오판한다. | intentional NC와 hierarchy scope를 구분한다. |
| 33-40 | PCB mechanical | 환경조건부/불충분 | 기구/antenna/enclosure 입력과 native geometry 없이는 자동 판정할 수 없다. | mechanical profile과 closed geometry를 대조한다. |
| 42-49 | PCB routing | 과잉일반화/환경조건부 | current sizing, diff pair, acid trap, ground pour를 보편화한다. | stackup/thermal/SI/fab profile별로 적용한다. |
| 50-58 | DFM | 환경조건부 | 항목은 유용하지만 fab capability와 assembly process가 정본이다. fiducial 수/thermal도 조건부다. | selected fab profile과 native DRC/preview로 검증한다. |
| 59-65 | assembly | 환경조건부/불충분 | footprint/polarity는 physical pin map이 필요하고 silk value/testpoint는 전략 의존이다. | BOM/CPL/assembly preview와 pin map을 연결한다. |
| 66-80 | tool mapping | 구식/과잉일반화 | `audit_esd_protection`은 없다. 나머지 audit도 checklist 전체를 구현하지 않으며 full review도 direct checks를 포함하지 않는다. | tool existence와 handler coverage를 확인하고 미지원은 manual evidence로 남긴다. |

### `kicad-review/references/error-taxonomy.md` 전체 1-72

| 줄 | 절 | 분류 | 주요 주장과 판정 근거 | 필요한 교정 |
|---:|---|---|---|---|
| 1-13 | ERC critical | 과잉일반화/환경조건부 | native severity/intent 없이 일괄 critical이며 diode/resistor 추가 같은 generic fix는 임의 전기변경이다. | native rule/item과 exact requirement로 원인을 확인한다. |
| 14-22 | ERC warning | 과잉일반화 | bidirectional conflict를 보통 괜찮다고 하고 power warning에 PWR_FLAG를 자동 처방한다. | driver/source topology를 확인하고 waiver/PWR_FLAG 근거를 기록한다. |
| 23-30 | ERC info | 과잉일반화/환경조건부 | final duplicate reference는 BOM/netlist blocker일 수 있어 일괄 benign이 아니다. | pre-annotation과 final 상태를 구분한다. |
| 31-42 | DRC critical | 과잉일반화/환경조건부 | generic “width 감소”는 min-width/정격을 위반할 수 있다. severity도 fab/net class 조건부다. | owner/location/rule/net class를 근거로 고친다. |
| 43-52 | DRC warning | 환경조건부 | native severity/fab capability가 우선하고 courtyard는 ownership/assembly intent가 필요하다. | native 결과를 보존하고 project severity는 별도 표기한다. |
| 53-60 | DRC info | 환경조건부/과잉일반화 | missing courtyard/duplicate footprint는 assembly/identity blocker가 될 수 있다. | product/assembly profile로 분류한다. |
| 61-72 | interpreting | 현재일치/불충분 | triage와 re-run은 유효하지만 source/coverage/owner/exclusion/original rc/INCOMPLETE가 없다. | evidence hierarchy와 coverage gate를 추가한다. |

## 새 표준 reference용 교정 규칙

1. **현재 build/schema가 먼저다.** `get_installation_info`와 fresh schema 없이는 고정 도구 수와 서명을 `unknown`으로 둔다.
2. **모드와 권한을 분리한다.** 신규/재작성/전기변경/읽기전용을 구분하며 읽기전용은 CAD를 쓰지 않는다.
3. **실선과 label을 분리한다.** local functional flow는 solid wire 우선이다. `batch_connect_to_net`의 wire 없는 기본은 명시 stub 또는 waiver 없이는 품질 완료로 인정하지 않는다.
4. **physical pin map이 필수다.** exact MPN/package datasheet lead, symbol pin, footprint pad, drawing view를 결속하고 query-back/render로 확인한다.
5. **PWR_FLAG는 source 증거가 있을 때만 쓴다.** 단순 warning 억제에는 사용하지 않는다.
6. **ERC는 owning root에서 hierarchy 전체를 검사한다.** child sheet 결과를 전체 ERC로 승격하지 않는다.
7. **aggregate는 direct check의 대체가 아니다.** `run_design_review`와 `audit_*`는 ERC·short·net·saved/exported connectivity를 대신하지 않는다.
8. **schematic과 PCB 거리를 분리한다.** `audit_decoupling` 또는 schematic 위치로 PCB proximity를 주장하지 않는다.
9. **정격·전류는 profile 계산 대상이다.** `audit_power_rails`는 current capacity, voltage, sequencing을 검사하지 않는다.
10. **저장 의미를 정확히 쓴다.** offline schematic MCP edit는 atomic file commit/readback이고 `save_project`는 live PCB 전용이다.
11. **coverage gap은 `INCOMPLETE`다.** required check 미실행, partial/failed, impossible zero, source 불일치, unresolved contradiction은 PASS가 아니다.
12. **제조·발주 승인을 분리한다.** ERC/DRC/limited audit/`READY`를 artifact, BOM/CPL, order preview, safety, explicit order approval로 확대하지 않는다.
13. **symbol query 성공과 pin 완전성을 분리한다.** `isError=false`여도 `pin_count=0`, 빈 pins, unit/상속 누락, exact package 불일치면 `INCOMPLETE`다.

## 후속 실제 거부·변이 시험 아이디어

모두 아직 실행하지 않은 제안이다. 각 시험은 대상 SHA 불변 또는 명시된 적용분 readback을 증거로 남겨야 한다.

| ID | 종류 | 변이/입력 | 기대 결과 |
|---|---|---|---|
| T01 | schema refusal | old `connect_pins(from_component,from_pin,to_component,to_pin)` | required field 거부, schematic SHA 불변 |
| T02 | schema refusal | old `connect_to_net(component_reference,pin_number,net_name)` | `schematic/net` 누락 거부, SHA 불변 |
| T03 | schema refusal | old `add_power_symbol(component_reference,pin_number,power_net)` | `schematic/x/y` 누락 거부, SHA 불변 |
| T04 | library refusal | 없는 Device transistor/Ferrite/구 IC ID | search/get/add에서 not found, CAD write 0 |
| T05 | polarity mutation | `Device:LED`를 1=A,2=K로 뒤집은 plan | installed pin map과 불일치해 G0 거부; 1=K,2=A만 통과 |
| T06 | phantom tool | `audit_esd_protection` 호출 | unknown tool로 명시 실패; 다른 audit 성공으로 대체 금지 |
| T07 | solid-line mutation | `batch_connect_to_net` 기본 `stub_length=0` | quality gate가 wire 없는 label을 거부; 명시 stub 후 render/net readback 통과 |
| T08 | PWR_FLAG policy | source 증거 없이 warning 제거 목적 PWR_FLAG | MCP 쓰기 전에 policy gate 거부, warning 보존 |
| T09 | ERC scope | hierarchy child에 `run_erc` | owning root를 명명한 `invalid_argument`; child 결과 채택 금지 |
| T10 | aggregate omission | `run_design_review`만 남기고 ERC/find evidence 삭제 | completion gate `INCOMPLETE` |
| T11 | decoupling limitation | same-net cap을 PCB에서 멀리 배치 | audit의 `pcb_distance_checked=false`; PCB 검사 없이 proximity PASS 금지 |
| T12 | power limitation | current/voltage mismatch지만 cap/testpoint는 존재 | power audit clean을 정격 PASS로 쓰지 않고 profile 누락 `INCOMPLETE` |
| T13 | DFM claim mutation | via-in-pad 또는 acid-trap만 가진 fixture | audit가 놓칠 수 있음을 관측하고 limitation gate가 제조 PASS 거부 |
| T14 | save semantics | offline schematic 증거로 `save_project`만 호출 | schematic atomic readback/SHA 없으면 완료 거부 |
| T15 | manufacturing boundary | validate가 `READY`, BOM/CPL/Gerber/drill/preview 없음 | 제한 verdict 보존, 제조·발주 승인 거부 |
| T16 | symbol false-green | `get_symbol_info(Amplifier_Operational:LM358)`가 성공하지만 pin 0개 | expected pin coverage gate가 `INCOMPLETE`로 거부; source inheritance 원인 규명 전 pin map 승인 금지 |

## 핵심 source 근거

- `router/registry.rs`: `run_erc`는 `sch_export`, `run_design_review`는 `design_review`이며 registry는 runtime schema와 함께 읽어야 한다.
- fresh `response-0005.json`: current required fields, `batch_connect_to_net.stub_length=0`, audit scopes를 직접 확인했다.
- `sch_export.rs`: ERC는 owning root에서 hierarchy 전체를 검사하고 child sheet 호출을 거부한다.
- `project.rs`: `save_project`는 현재 open PCB의 live IPC save다.
- `design_review.rs`: aggregate 실제 audit 구성과 각 audit handler의 제한 coverage를 확인했다.
- `manufacturing.rs`: 제한 preflight/DRC verdict이며 제조·발주 승인과 동일하지 않다.
- 설치 KiCad 10.0.6 library: `Device:D`/`Device:LED`는 pin 1=K, pin 2=A다.
- `symbol-queries/response-0003..0014.json`: 7개 기초 symbol 정상, 구 ID 4개 명시 실패, LM358 성공+0 pins 반례. 명시 실패 4건은 의도한 negative evidence이며 미해결 오류 합계로 세지 않는다.

구조화된 completeness, source SHA, section records, test 목록은 `audit.json`이 정본이다.
