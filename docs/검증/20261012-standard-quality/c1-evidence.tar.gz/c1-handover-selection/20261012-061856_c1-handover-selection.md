# C1 최종 인계용 증거 선별

작성 시각: 2026-10-12T06:18:56.820344+09:00
상태: **선별 완료, 복사·stage·commit·push 미실행**.

## 사용자에게 설명할 제한

C1은 Claude `claude-opus-5-5`가 원 b274 패키지로 작성했고, Root의 GUI 왕복과 독립 읽기 검토를 거쳤다. 이후 발견된 JSON boolean 타입 false-green은 현재 c77에서 수정·실제 native 재수집·변이/독립 감사로 검증했다. **현재 c77로 Claude/Codex가 처음부터 다시 작성한 성공은 아직 없다.** 원 전체 FAIL과 후속 정규 전체 PASS는 둘 다 보존하며, 후속 PASS가 원 fixture 경합 취약성을 고쳤다는 뜻은 아니다. PCB·동적·정격·실물·제조·통전·인증 완료로 확대하지 않는다.

## 두 package와 실제 모델별 역할

```text
id      | model             | package | execution                       | verdict
--------+-------------------+---------+---------------------------------+------------------------------------
C1-W    | claude-opus-5-5   | b274    | actual_CAD_author               | PASS_LIMITED_WITH_KNOWN_TYPE_BUG
C1-G    | gpt-6-astra       | b274    | GUI_roundtrip                   | PASS_LIMITED_GUI_ROUNDTRIP
C1-I    | gpt-6.1-sol       | b274    | independent_read_only_review    | PASS_READ_ONLY_REVIEW
C1-V    | gpt-6-astra       | c77     | existing_CAD_native_validation  | PASS_EXISTING_CAD_NATIVE_VALIDATION
C1-T    | UNKNOWN           | c77     | deterministic_type_regression  | PASS_CAUSAL_TYPE_REGRESSION
C1-COLD | NONE              | c77     | cold_authoring                  | NOT_RUN
```

b274 = `b274e7d851c129bb62402d1d71f18b43a772d29326ba612ce4cd2954233f4fbf`
c77 = `c77ca8ed6783532aaad86496f868f9d22af376c5756c9464c35938bdaf3ce3ca`

원 C1 CLI init의 모델과 assistant 모델 182개 기록 및 result modelUsage key가 `claude-opus-5-5`로 일치했다. CLI 버전2.1.296·76turn·result success·local 품질 스킬 발견을 최소필드로 추출했다. Root 모델은 실제 turn_context 등록값이며 독립 검토 모델은 실제 spawn model argument에서 확인했다. model routing 서버 내부를 직접 관측한 것이 아니다. 타입 감사 실행자의 exact 모델은 별도 미확인으로 두고 모델별 작성 지원 증거로 만들지 않았다.

원 CLI 1.68MB 전체·Root rollout 전체·인증값은 복사하지 않는다. 정확 source 행 SHA와 최소 모델 필드는 `model-evidence.json`에 보존했다. 지원 상세는 `support-matrix.json`의 SHA별 역할/제한을 정본으로 한다.

## 전기·GUI·native 증거 경계

초기 saved CAD SHA: `25503f5d765522f8191a92996779fdbf9a092da848adfbe52e8eb7f1da910b70`.
GUI 이후/current CAD SHA: `e6c1430b85bf357815b15eabce639948911566ddf489c416673a73e600170672`.
registry SHA: `c1669c3beba5f2e0b491f2d82ddcc6d7c248f63168f13390a186db40b72ebc25`.
semantic SHA: `39d1677c2d18ace6b273adbb56d72178f6723cc38837ef76284fb5324cd77382`.

초기 CAD 실제 bytes는 `gui-evidence/before/rc-filter.kicad_sch`에서 확인했다. 현재 live source를 되돌리지 않고 이 역사 사본도 후보로 선별했다. PCB는 원 `create_project`가 만든 기본 빈 PCB이며 PCB 배치/배선 성공 증거가 아니다.

```text
b274 author/native source25503f
    -> Root GUI saved/reopened sourcee6c1430b
       -> b274 root-post-gui native + independent GUI/PDF review
       -> b274 registry.schema_version=true survivor rc0
          -> c77 strict type fix
             -> root-type-fixed fresh native same_sourcee6c1430b
                -> 12 causal rejects + 1 bool reject + 4 probes + GREEN2
                -> original fullFAIL rc2 -> later default fullPASS rc0
```

서로 다른 native leaf 세 개(`20261012-045534-native`, `root-post-gui`, `root-type-fixed`)의 package/source/생성 argv/원 rc/producer identity는 각각 따로 보존한다. b274 자체 검토와 독립 검토, c77 deterministic 정적 검사도 별도다. c77 native leaf PDF의 독립 시각 판독을 이 선별 단계에서 새로 수행한 것은 아니다. 기존 b274 GUI/PDF 검토와 같은 saved CAD임은 current hash로 결속하며 cold author 성공이나 새 c77 PDF 시각 완료로 승계하지 않는다.

낮은 항목은 유지한다: Title/Date/Rev 공백, 비극성 R/C pin번호 GUI/PDF 비표시(정확 번호는 native XML/endpoint로 결속), footprint4개 미할당. ERC 오류0/경고0/개별 제외0이며 기본 비활성4종은 공개 상태다. native environment 보충은 caller argv/상속코드/설정사본 범위이며 native proc환경/AppImage 내부직접관측이 아니다.

## 원 결함과 후속 수정/검증

원 b274는 `registry.schema_version`을 integer1에서 boolean true로 바꾸고 caller copy SHA를 맞췄는데도 rc0/PASS survivor를 냈다. 이를 원 result/report/registry bytes와 summary로 선별했다. 원 subset PASS를 오류0로 세지 않는다.

c77는 actual native를 재수집한 뒤 12개 기존 인과 변이·boolean1개를 모두 각각 기대 원인으로 거부했다. 추가 runtime schema float/layout schema bool/producer plan schema bool/package size float probe4도 각각 rc1/FAIL, 오염되지 않은 control/GREEN2는 rc0/PASS다. 공개 단위 gate92tests/rc0 로그도 별도로 보존한다. 원 PIN 조회 unit 누락 INCOMPLETE와 검토자 초기 rc2 경계거부/보조 코드 rc1도 원 로그와 함께 선별했다.

원 fullFAIL은 make rc2/cargo101, Rust core1770통과·1실패·23무시, `mock listen: AddressInUse`다. 이후 source 무수정의 **정규 기본 `PYTHONDONTWRITEBYTECODE=1 make test` 1회**는 make rc0, Rust2513통과·0실패·50무시/Python175통과다. 이 둘은 합산하거나 원 FAIL을 삭제하지 않는다. 좁은 반복/경합 주입 증거를 default full executable의 재현으로 바꾸지 않는다. 원 fixture 예약 공백은 미수정이며 과거 충돌자 정체는 미확인이다.

## exact allowlist와 향후 git 후보

현재 선택된 기존/새 구조화 증거는 259개·3,008,659bytes이다. 이 안내/HTML/README 세 파일을 더한 최종 후보 수·총bytes·각 파일의 SHA/size/git mode/역할/source/destination은 **`allowlist.json`**을 정본으로 한다. glob나 디렉터리 전체 허용이 아니라 개별 exact path만 나열한다.

예정 destination root는 `docs/검증/20261012-standard-quality/c1/`이며 이 단계에서는 그 폴더를 만들거나 파일을 복사하지 않았다. `.artifacts/`를 `git add -f`로 넓게 추적하는 방식은 제안하지 않는다. 별도 승인 후 allowlist의 exact source→destination만 옮길 수 있으며 SHA/size/mode readback을 다시 검사해야 한다. commit/push는 이 작업에 포함되지 않는다.

현 package의 정본 코드 배포 경로는 기존 `skills/kicad-schematic-quality/`이며 증거 snapshot의 옛 package와 이름을 혼동하지 않는다. symlink 두 개는 link-target bytes SHA/size/git mode120000을 기록했고 실제 두 alias 모두 같은 격리 b274 정본을 가리킨다.

큰 raw CLI, native binary, 고객 원문, 원 인증·계정 자료는 제외한다. 원 make fullFAIL 약196KB/fullPASS stdout 약241KB만 제한된 원 gate 로그로 남겨 실패 삭제나 성공 과장을 방지한다. 중복 렌더 PNG·HTML 사본·대용량 전체 schema/response tree는 줄이고 실제 GUI 캡처5개/native PDF/필요한 요청·dispatch·영수증을 선별했다. 토큰 패턴 점검은 선택한 텍스트에만 적용했으며 임의의 완전한 비밀정보 검출을 보장하지 않는다. 계정/credential 파일은 검사하려고 열지도 않았다.

## 명시 제외와 별도 범위

- `.credentials.json`, auth-status raw, 계정 config/DB/sqlite/lease, keyring, token 및 전체 CLI/Root session raw본.
- native `codex`, `codex-code-mode-host`, Konnect/KiCad binary/AppImage, compiled `.so`/cache/bytecode, live HOME 설정 전부.
- 제품 고객 원문·배터리 생산 프로젝트/기존 글로벌 스킬 본문.
- `CURRENT.md` 및 account preflight/X1/polarity 과제 전체: 계정 운영 맥락이 있고 C1 한정 범위 밖이다.
- `source-audit` T01~T16: 별도 작업자 진행 중이므로 이 allowlist의 증거와 완료 판정에 흡수하지 않는다.
- 제작/통전 artifact, 결론 미열람 원칙을 유지한 `AUTHOR-RESULT.md`와 `self-review.md`, 원 WIP/preexisting 파일 자체.

## 재현 명령과 한계

`reproduction-commands.json`의 R1~R7는 현재 원 host/경로를 기준으로 한 **실행하지 않은 명령 템플릿**이다. verifier 재실행은 project-root 안의 새 report path를 사용해야 하며 원 evidence를 덮어쓰지 않는다. package identity/92tests/current c77 native 정상/원 b274 post-GUI 정상/원 bool survivor/c77 bool 거부/default full gate를 각각 구분했다.

다른 host/root로 증거를 옮겨도 원 native XML `design/source` absolute path와 library 경로가 자동으로 portable해지는 것은 아니다. 새로운 승인 root에서 동일 source·계약·계획/정식 library binding과 fresh native provenance를 확보해야 한다. archived source를 live에 되돌리거나 runtime/source hash를 임의 재봉인해 과거 PASS를 현재 실행으로 꾸미지 않는다. 계정·모델 cold 재실행 명령이나 토큰 이전 방법은 포함하지 않는다.

## 보존·다음 단계

선별 전후 current CAD/pro/PCB/sym-lib-table, registry/semantic, 계획9파일 SHA가 동일한지 확인한다. b274 전체17파일·c77 snapshot17파일·현재 root c77 정본17파일도 동일 expected identity로 읽었다. 원 source/원 package/다른 작업자 파일은 수정하지 않았다.

다음 결정은 Root의 최종 source audit/지원표·범위 통합 후 **선별 후보의 실제 인계 승인**이다. 이 문서는 어떤 다른 과제의 완료 승인이나 commit 승인도 아니다. 목록 자체와 summary metadata는 제어 파일이며 최종 allowlist JSON의 자체해시를 그 안에 재귀 삽입하지 않는다. 최종 목록 bytes SHA는 `selection-receipt.json`에 별도로 결속한다.
