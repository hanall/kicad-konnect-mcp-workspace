# C1 인계 증거 선별

[범위와 지원표](20261012-061856_c1-handover-selection.md), `support-matrix.json`, `model-evidence.json`, `reproduction-commands.json`, exact `allowlist.json` 및 `selection-receipt.json`을 함께 읽는다. 이 단계는 복사·stage·commit·push 0이며 c77 cold 작성 성공을 주장하지 않는다.
