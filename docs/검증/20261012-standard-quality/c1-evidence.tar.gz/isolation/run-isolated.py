#!/usr/bin/env python3
"""이 과제의 실제 CLI/native 시험만 원 프로젝트·글로벌 스킬과 분리한다."""
import json
import os
from pathlib import Path
import subprocess
import sys

BASE = Path(__file__).resolve().parent
REPO = BASE.parents[2]
EMPTY = BASE / 'empty'
CONFIG = BASE / 'claude-runtime'
CASE = BASE / 'case'
RUNTIME = BASE / 'runtime'


def build(command):
    args = ['bwrap','--die-with-parent','--unshare-pid','--new-session',
            '--ro-bind','/','/','--proc','/proc','--dev','/dev','--tmpfs','/tmp',
            '--bind',str(CONFIG),str(CONFIG),
            '--ro-bind','/home/hanol/.claude/.credentials.json',str(CONFIG/'.credentials.json'),
            '--bind',str(CASE),str(CASE), '--bind',str(RUNTIME),str(RUNTIME)]
    for path in ['/home/hanol/battery-module-cycler','/home/hanol/.codex','/home/hanol/.claude',
                 '/home/hanol/.agents','/home/hanol/.claude-codex-accounts','/home/hanol/.ssh',
                 '/home/hanol/agent-os','/home/hanol/mattpocock-skills']:
        if Path(path).exists():
            args += ['--ro-bind',str(EMPTY),path]
    # 부모 checkout의 진입점/원 패키지로 몰래 로딩하지 못하게 분리한다.
    for relative in ['.claude','.agents','skills']:
        path = REPO/relative
        if path.exists():
            args += ['--ro-bind',str(EMPTY),str(path)]
    for relative in ['AGENTS.md','CLAUDE.md']:
        path = REPO/relative
        if path.exists():
            args += ['--ro-bind','/dev/null',str(path)]
    for path in ['/home/hanol/.claude.json','/home/hanol/.env']:
        if Path(path).exists():
            args += ['--ro-bind','/dev/null',path]
    # 계약·원문·패키지는 후보 작성자가 수정하지 못한다.
    for relative in ['skills','.claude','.agents','CLAUDE.md','AGENTS.md','TASK.md',
                     'project/registry.json','project/contracts','project/sources','oracle-refinement-before-cad.json','unit-refinement-before-cad.json','package.identity.json']:
        path = CASE/relative
        if path.exists():
            args += ['--ro-bind',str(path),str(path)]
    args += ['--chdir',str(CASE),'--',*command]
    env = {'HOME':'/home/hanol','PATH':'/home/hanol/.local/bin:/usr/local/bin:/usr/bin:/bin',
           'LANG':'ko_KR.UTF-8','TERM':'xterm-256color','CLAUDE_CONFIG_DIR':str(CONFIG),
           'CLAUDE_CODE_DISABLE_AUTO_MEMORY':'1','CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC':'1',
           'DISABLE_AUTOUPDATER':'1','PYTHONDONTWRITEBYTECODE':'1','KONNECT_GUI_SYNC':'0',
           'KONNECT_RUNTIME_HOME':str(RUNTIME),'KICAD_API_SOCKET':'ipc:///tmp/no-shared-kicad.sock',
           'KICAD10_SYMBOL_DIR':'/opt/kicad/10.0.6/share/kicad/symbols',
           'KICAD10_FOOTPRINT_DIR':'/opt/kicad/10.0.6/share/kicad/footprints',
           'KICAD10_3DMODEL_DIR':'/opt/kicad/10.0.6/share/kicad/3dmodels'}
    return args,env


def main():
    if len(sys.argv)<2:
        raise SystemExit('실행 명령이 필요합니다')
    args,env=build(sys.argv[1:])
    return subprocess.run(args,env=env).returncode


if __name__=='__main__':
    raise SystemExit(main())
