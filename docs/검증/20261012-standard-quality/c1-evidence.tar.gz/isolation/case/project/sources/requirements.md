# C1 독립 요구 원문 정규화 - rc-filter

## 권위와 상태

이 문서는 표준 스킬 검증 담당 Root가 선정한 합성 RC 학습 예제의 독립 oracle 원문이다. 사용자 제품의 전기 요구나 실물 안전 설계가 아니다. 2026-10-12 후보 CAD를 만들기 전에 고정했다. 현재 `rc-filter.kicad_sch`와 native XML/PDF/ERC/layout은 존재하지 않으며, 후보 산출물에서 기대값을 추출하지 않는다. 회로도 생성 전 이 원문과 semantic JSON의 bytes SHA를 고정한다.

## 부품 계약

- J1: value `VIN`, `Connector_Generic:Conn_01x02`, unit 1, pin 1/2 모두 passive, footprint 미할당 빈 문자열.
- J2: value `VOUT`, `Connector_Generic:Conn_01x02`, unit 1, pin 1/2 모두 passive, footprint 미할당 빈 문자열.
- R1: value `1k`, `Device:R`, unit 1, pin 1/2 모두 passive, footprint 미할당 빈 문자열.
- C1: value `100n`, `Device:C`, unit 1, pin 1/2 모두 passive, footprint 미할당 빈 문자열.

## 전기 net과 실선 계약

- `VIN` = `J1.1`, `R1.1`.
- `VOUT` = `R1.2`, `C1.1`, `J2.1`.
- `GND` = `J1.2`, `C1.2`, `J2.2`.
- 세 net 모두 각 pin 묶음 전체가 한 개의 실제 solid-wire root로 전도되어야 한다. local label은 이름을 부여할 수 있지만 빠진 wire를 대신하지 않는다. 전원 symbol과 `PWR_FLAG`는 두지 않는다. global port도 없다.

## 페이지와 판정 경계

project stem, root schematic 파일명, 표제 이름은 `rc-filter`로 통일한다. 1 page A4를 사용한다. semantic의 ordered page size는 host KiCad A4 native 관측에 근거해 landscape `297 x 210 mm`로 선택했으며, orientation을 바꾸려면 CAD 작성 전에 별도 승인과 oracle 재봉인이 필요하다. passive 회로의 native ERC 기대는 error 0, warning 0, exclusion 0이지만 아직 실행하지 않았으므로 관측 사실이 아니다. 정적 합격은 PCB, footprint 적합성, 동적 RC 응답, 제조, 통전, 안전 합격이 아니다.
