# C1 실제 독립 작성 과제

표준 회로도 품질 스킬을 사용하여 `project/rc-filter.kicad_sch`를 작성하고 정적 native 검증까지 수행하세요. 사전 기대 계약은 `project/registry.json` SHA `c1669c3beba5f2e0b491f2d82ddcc6d7c248f63168f13390a186db40b72ebc25`입니다. 이를 수정하지 마세요. 같은 폴더의 README·sources·semantic을 읽고 모드 design과 plan-index를 완성하세요. proposed plan은 설계 초안이므로 현재 환경·배치·검증 순서를 반영해 정식 계획으로 만든 뒤 첫 CAD 쓰기 전에 SHA를 기록하세요.

## 확정 환경
- workspace-root: `/home/hanol/kicad-konnect-mcp-workspace/.artifacts/20261012-040121-standard-quality/isolation/case`
- project-dir/project-root: `/home/hanol/kicad-konnect-mcp-workspace/.artifacts/20261012-040121-standard-quality/isolation/case/project`
- SKILL_DIR: `/home/hanol/kicad-konnect-mcp-workspace/.artifacts/20261012-040121-standard-quality/isolation/case/skills/kicad-schematic-quality`
- launcher: `/home/hanol/kicad-konnect-mcp-workspace/scripts/run-konnect.sh`
- config: `/home/hanol/kicad-konnect-mcp-workspace/config/konnect.toml`
- server-cwd: `/home/hanol/kicad-konnect-mcp-workspace`
- expected-version: `0.13.0+hanall.1`
- expected-commit: `94f80350cf67db27b179a06a8f6dbebfe4717927`
- kicad-cli: `/usr/local/bin/kicad-cli`
- pdftotext: `/usr/bin/pdftotext`
- 설치 읽기전용 symbol library: `/opt/kicad/10.0.6/share/kicad/symbols/Device.kicad_symdir`, `/opt/kicad/10.0.6/share/kicad/symbols/Connector_Generic.kicad_symdir`

실제 schema·핀 조회는 guarded_mcp.py에서 하고, 현재 MCP 응답/배치 endpoint를 우선하세요. 고정된 오래된 도구 인자로 추정하지 마세요. 일반 CLI stdout 및 source code는 read-only로 조사할 수 있지만 원본제품이나 글로벌기존스킬에 의존하지 마세요. 코드 변경과 어댑터 우회는 금지입니다.

## 작성과 검증

1. 먼저 패키지·원문·registry·프로젝트 비대상·lock 확인, plans와 plan-index.json의 exact allowed_files를 확정합니다. 새project이므로 `.kicad_pro`, `.kicad_sch`, 기본 `.kicad_pcb`, `sym-lib-table` 생성만 허용합니다. PCB파일은 기본생성 외 편집금지입니다. `read_only_library_refs`에 두 설치 라이브러리를 exact mapping으로 선언하고 project scope로만 등록합니다.
2. 계획 후 현재 runtime identity와 도구 schema를 확인합니다. 정식 schema가 필요한 경우 어댑터가 만든 evidence의 목록을 읽으세요.
3. A4 landscape 1쪽 RC회로: 입력 J1은 왼쪽, R1은 수평 직렬, C1은 아래방향 shunt, J2는 오른쪽입니다. pin/unit/type/망·값·footprint는 semantic과 같아야합니다. 모든 망을 실선으로 연결하고 local label은 이름을 표시하는 보조입니다. 전원symbol과 PWR_FLAG는 추가하지 마세요. 제목은 `rc-filter`입니다. 좌표는 과밀을 피하고 텍스트가 선이나 심볼을 침범하지 않게 정하세요.
4. 작은 batch로 배치하고 endpoint readback 뒤 배선합니다. partial/error/timeout이면 실제 대상과 SHA를 확인하기 전 재시도하지마세요. 없는 도구로 fallback하거나 CAD파일을 직접 고치지 마세요.
5. 저장본의 모든 부품/pin/실선 조회 뒤 새 evidence 디렉터리에 collect_evidence.py를 실행하세요. expected 계약 변경금지. FAIL이면 원인과 원rc를 보존하고 작성범위에서 고치되 unknown을삭제하거나assertion을완화하지마세요.
6. 전페이지 PDF를 렌더해 볼수있으면 자신의 시각검토를남기되 GUI왕복/독립검토로확대하지않습니다. 불가능하면미실행이라고보고합니다.
7. 최종 한국어 보고와 `project/AUTHOR-RESULT.md`에 실제 model(관측가능한경우만), package SHA, CAD SHA, native 결과, 남은 unknown을적습니다. Root는별도로재검증합니다.

요청JSONL은 임시파일->flush/fsync->atomic rename->부모fsync->전체readback후사용하고 매실행새 evidence 디렉터리를만듭니다. 전체pipeline은외부제품원문을읽지않는현재격리환경에서수행해야합니다. 원문자료를이메일·외부서비스로보내지마세요.

## 현재 조회 도구 한계

현재 `get_symbol_info`는 pin unit을 제공하지 않아 어댑터가 INCOMPLETE로 분류합니다. 조회 자체의 제한은 오류 0으로 숨기지 마세요. `project/sources/unit-source-observation.json`은 설치 symbol 원문에서 R/C/Conn_01x02가 extends 없이 단일 unit 1인 것을 읽기 전용으로 확인한 보완 증거입니다. 이 원문·이미 봉인한 local pin 정의와 실제 배치 endpoint readback을 함께 사용하고, 불완전 조회를 write batch에 넣어 억지로 PASS시키지 마세요. 원문은 조회가 부족한 unit 질문에 한해서만 읽을 수 있고 수정은 금지입니다.
