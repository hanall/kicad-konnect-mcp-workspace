# 격리 표준 스킬 검증 과제

한국어로 응답하고 `.claude/skills/kicad-schematic-quality/SKILL.md`를 먼저 읽는다. 해당 패키지는 `.agents/skills/`에서도 같은 정본을 가리킨다.

- 현재 폴더의 TASK.md, project/sources와 project/registry.json이 과제 정본이다. 이 과제는 Root가 정한 합성 RC 학습 예제이며 제품 설계가 아니다.
- CAD 직접 텍스트/스크립트 생성·수정·복구 금지. 오직 패키지의 guarded_mcp.py를 통한 정식 Konnect 요청으로 작성한다. GUI는 아직 열지 않는다.
- 단일 작성자이며 기존 프로젝트·글로벌 스킬·계정·설정·인증 파일을 읽거나 수정하지 않는다. 패키지와 oracle은 OS 읽기 전용이다.
- shell은 실제 격리 환경이다. 배터리 원문·글로벌 스킬은 마운트에서 가려져 있다. 접근 실패를 우회하지 않는다.
- JSON/Markdown 계획·요청·증거만 직접 쓸 수 있다. 원문 registry/semantic을 후보 CAD에서 재생성하거나 expected 값을 바꾸지 않는다.
- API 키·외부 API·새 의존성 설치·commit/push·PCB 작성·제조·통전은 금지다. create_project가 기본 empty PCB를 만드는 것만 새프로젝트 기본파일로 허용한다.
- GUI 저장·재열기와 전페이지 독립 시각 검토는 Root의 후속 역할이다. 이 실행에서 자동으로 완료했다고 쓰지 않는다.
