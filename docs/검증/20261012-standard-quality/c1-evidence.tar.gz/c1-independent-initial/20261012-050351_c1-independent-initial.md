# C1 초기 독립 읽기 전용 검토

작성 시각: 2026-10-12T05:03:51.238427+09:00
검토자: `/root/standard_c1_independent`

## 결론

**지정 초기 저장본의 전기 정적 계약과 PDF 전페이지/확대 읽기 과제를 통과했다.** 현저 전기·시각 차단 결함은 관측하지 않았다. 이는 초기 CAD SHA와 기존 native PDF에 한정하며 GUI 검토·저장·닫기·재열기 완료나 전체 G0~G5 완료, 동적·PCB·제조·통전·정격·실물 안전 완료가 아니다. GUI 이후 새 SHA는 별도 재검증 대상이다.

명시 요구: C1 합성 RC 예제 독립 대조, 작성자 결론 선행 열람 금지, 저장본·native XML/실선/핀·PDF/PNG 판독, CAD 및 GUI/MCP 쓰기 0.
사용한 가정: 원문 요구/선행 고정 semantic이 정답이며 후보 CAD로 oracle을 재생성하지 않는다. 이 결과는 제품 설계나 성능 검증이 아닌 격리 예제의 정적 관측이다.
확인된 사실: 부품 4, 물리 핀 8, 망 3, 실선 11, junction 2, 단위 모두 1, footprint 빈 값 4개. 원 native ERC 오류·경고·개별 제외 0, 기본 비활성 규칙 4종은 보존한다.

## 범위와 독립성

대상은 `/home/hanol/kicad-konnect-mcp-workspace/.artifacts/20261012-040121-standard-quality/isolation/case/project`의 `rc-filter.kicad_sch`, A4 가로 1쪽이다. 프로젝트 AGENTS/품질 스킬과 공통·전기·시각·검증·호환성·교정 참조 및 general profile을 적용했다. 기존 공통/페이지 계획을 수신했고 사후 작성 계획은 만들지 않았다.

`AUTHOR-RESULT.md` 및 `self-review.md`와 작성자 결론/점수는 끝까지 읽지 않았다. 지정 원전기계약·semantic·작성계획과 runtime/native 기계 증거는 읽었다. 작성자 PNG 자체는 보았지만 설명·의도된 결함 위치·평가는 보지 않았다. 따라서 작성자 결론과 분리된 검토이나 oracle·계획을 전혀 보지 않은 무맥락 blind 시험은 아니다.

검토자는 GUI를 열지 않았고 MCP 서버를 호출하지 않았다. CAD mutation/save/lock 변경, 계정 접촉, commit/push 모두 0. 일반 산출물은 지정 자기폴더에만 작성했다. Root의 별도 승인 이후 `project/evidence/c1-independent-pre-gui/` 새폴더와 그 안 `report.json`만 추가 작성했다. 타 작업자 변경은 되돌리거나 흡수하지 않았다. HTML 일반 출력 위치 규칙보다 이 명시 쓰기 경계를 우선했다. MCP 시간 도구가 노출되지 않아 셸 실측 시각을 사용했다.

## 정적 대조

아래 망 집합은 원 semantic과 native XML의 root-local `/` 제거 정책을 적용해 exact 일치했다. 값·symbol·footprint·unit·passive type도 전수 대조했다.

```text
net   | native_members             | wire_ids
------+----------------------------+--------------------
VIN   | J1.1 R1.1                  | 1
VOUT  | R1.2 C1.1 J2.1             | 2 3 4
GND   | J1.2 C1.2 J2.2             | 5 6 7 8 9 10 11
```

별도 독립 코드가 native XML 집합, layout의 모든 wire endpoint·물리 핀·label anchor·junction으로 그래프를 만들었다. 3개 pin 묶음은 각각 단일 실제 실선 root이며 root 간 공유 0, 추가 wire root 0, 세 label은 각 올바른 실선에 붙어 있다. 두 T 접점은 `(139.70,88.90)` 및 `(139.70,109.22)`이고 모두 명시 junction이다. 11개 wire는 모두 축평행이며 커넥터 반환 수직선은 상단 VIN/VOUT에 닿지 않는다. native XML과 layout 부품/핀/망 대응이 일치하며 source·semantic 원문·설치 symbol SHA도 현재 대조했다.

원 native 생성 명령은 `commands.json`에 `kicadxml` 명시 XML, PDF, root ERC `--severity-all --exit-code-violations`와 각각 원 rc=0으로 보존돼 있다. 기존 deterministic 보고 `static-report.json`의 PASS를 그대로 독립 증명으로 삼지 않고 공개 검증기를 재실행했다.

```text
run                                   | rc | status
--------------------------------------+----+-------------------------
verify_quality initial report-outside |  2 | guard rejection
verify_quality approved report-inside |  0 | PASS
independent XML/wire/hash initial      |  1 | reviewer-script KeyError
independent XML/wire/hash corrected    |  0 | PASS
```

첫 공개 검증 재실행은 자기 보고 경로가 project-root 밖이어서 경계검사가 거부했다. CAD 실패가 아니며 원 `independent-verifier.log`/`.rc`를 보존했다. Root의 추가 출력 승인 뒤 같은 입력과 같은 package로 새 경로에서 rc0를 받았고 guard·assertion·oracle·allowlist는 변경하지 않았다.

독립 보조 코드 첫 실행은 label 좌표를 그래프 점 집합에 넣지 않아 `KeyError (93.98, 88.9)`가 났다. 원 코드 `independent-check-initial.py`, 원 traceback과 rc1을 보존한 뒤 자기 코드에 label anchor를 추가해 대조했다. 이는 검토자 보조 코드 결함이며 후보 전기 FAIL이 아니다. 이 단일 수정/재실행을 패키지의 RED-GREEN-mutation-GREEN2 완료로 주장하지 않는다. 패키지나 생산 CAD는 수정하지 않았다.

## 시각 판독과 읽기 과제

native PDF 전체 1쪽과 회로 영역 확대를 `pdftoppm`으로 자기폴더에 새 렌더해 직접 보았다. 작성자의 `page-1.png` 및 `zoom-circuit-1.png`도 직접 확인했다. 두 매체의 표현은 일치한다. 전체페이지에서 프레임/표제란/회로 영역의 잘림이나 겹침이 없고, 회로 확대에서 ref/value/net/커넥터 핀번호와 양쪽 T 접점·반환 레일을 읽을 수 있었다. 실제 GUI 전체 페이지는 미검토이며 PDF로 대신 완료 처리하지 않는다.

```text
J1.1 -- VIN -- R1(1k) --+-- VOUT -- J2.1
                       |
                     C1(100n)
                       |
J1.2 ------ GND -------+---------- J2.2
```

- 입력 전류 흐름 읽기: 왼쪽 J1.1 입력에서 VIN 실선으로 R1 왼쪽 단자에 들어가며 R1 오른쪽 단자 뒤가 VOUT다. 출력은 오른쪽 J2.1이다. R1 pin1/2는 layout endpoint 및 native XML로 특정했다. 실제 전류 크기·방향·동적 파형은 이 그림만으로 시험한 것이 아니다.
- RC 반환 읽기: VOUT 상단 접점에서 아래 C1로 분기하고 C1 하단은 GND 실선 레일에 닫힌다. GND는 왼쪽 J1.2와 오른쪽 J2.2에 함께 연결된다. 입력원·부하·충방전 동작을 실제 연결/시험하지 않았다.
- 분기 해석: R1 뒤의 상단 실선은 C1 상단과 J2.1을 잇는 하나의 T junction이다. C1 하단의 T junction은 두 커넥터 반환을 잇는 GND 레일이다. 양 커넥터의 pin2 반환 수직선은 pin1 신호선과 만나는 교차선이 아니다. label-only 연결은 없다.
- 부유·Kelvin·PE 및 off-page: 이 단일 비절연 소회로에는 해당 항목이 없으며 semantic에서도 port 목록이 빈 값으로 선행 선언됐다. GND를 보호접지 PE로 해석하지 않았다. feedback/보상 loop와 반복 channel도 해당 없음이다.

외부 field 문자획 관통·잘림을 직접 판독한 범위에서 발견하지 않았다. R1 값 `1k`는 resistor body 안에 있으나 읽히며 원 정상 symbol 표현과 일치한다. 이 관측을 모든 glyph 탐지기의 완전성 보증으로 올리지 않는다.

## 낮은 경고와 미확인

- 낮은 문서 품질 항목: 우하단 Title/Date/Rev는 공백이다. 본문 제목 `rc-filter`, 파일명 및 `Id: 1/1`은 표시돼 있다. 페이지 사전계획의 title-block 도구 부재 예외와 일치하며 원 요구의 예제 범위에서는 현저 차단 결함이 아니다. 향후 정식 인계본에서는 승인 채널에서 표제란 보완 여부를 Root가 결정한다.
- 판독 한계: PDF에는 R1/C1 물리 핀번호가 보이지 않는다. 비극성 수동소자의 기능 경로는 읽히지만 exact pin번호는 PDF 단독으로 단정하지 않고 XML과 배치 endpoint를 결속했다. 무도움 PDF에서 모든 ref.pin 번호를 직접 읽는 것이 별도 요구라면 아직 충족하지 않는다.
- 범위 제한: footprint 4개 모두 계약대로 미할당이다. 제조사 MPN/package/실물 connector mating view·PCB pad/배치·정격·전압/전류·공차는 미검증이며 이 계약은 그 합격을 요구하지 않는다.
- GUI 저장·정상 닫기·재열기·GUI/native 렌더 차이 및 saved/live 일치는 미확인이다. Root가 후속 GUI 왕복을 수행한 뒤 fresh source와 native 증거로 다시 대조해야 한다.
- native 생성 provenance는 기존 명령/rc/source 해시 receipt를 대조했다. 검토자가 native CLI export를 새로 실행하거나 살아 있는 MCP process/GUI 상태를 직접 조사하지는 않았다.
- 대상 checkout의 설치·공급망·전체 upstream gate와 전프로젝트 `make verify`는 이 읽기 검토의 완료 판정에 포함하지 않는다. 새 의존성은 설치하지 않았다.

## ERC 비활성 공개

오류·경고·개별 제외는 각각 0이며 sheet `/`가 전체 1쪽이다. 기본 비활성은 다음 4종으로 선행 semantic과 현재 native JSON이 exact 일치한다.

```text
ignored_check
----------------------
footprint_filter
four_way_junction
simulation_model_issue
single_global_label
```

각각 footprint filter 불일치, 4방향 junction, SPICE 모델, 단독 global label 검사다. 검사 비활성 4종을 모두 활성 검사 통과로 쓰지 않는다. 개별 warning/exclusion identity 목록은 비어 있고 경고 은폐용 pin type 변경·NC·PWR_FLAG는 이 계약과 후보 인벤토리에 없다.

## 정확한 증거 식별

```text
artifact                       | sha256
-------------------------------+-----------------------------------------------------------------
package                        | b274e7d851c129bb62402d1d71f18b43a772d29326ba612ce4cd2954233f4fbf
registry.json                  | c1669c3beba5f2e0b491f2d82ddcc6d7c248f63168f13390a186db40b72ebc25
c1-rc-filter.semantic.json     | 39d1677c2d18ace6b273adbb56d72178f6723cc38837ef76284fb5324cd77382
rc-filter.kicad_sch             | 25503f5d765522f8191a92996779fdbf9a092da848adfbe52e8eb7f1da910b70
rc-filter.kicad_pro             | a3b8289a4101439ffbd8b97954cb8e9d8052fcf83ac670cdc32cf32a9209ed6f
rc-filter.kicad_pcb             | d339432e9703afe9d86e25ef344078522aa166b4c78db6f36e6141cb87bb7690
sym-lib-table                  | 4e7e16efd5579f30621fbc683f068d6cb91a3792021a73006efb52ae498322f5
netlist.xml                    | 520305a6a30d6cc6c12f9b4e8eef1eeb99204f5471228442bb291950c5d6a1ef
schematic.pdf                  | aba2e1a8ecf1ea5cbc87d5ee7342a31fb7a67f3c95ec271283584705958a1f27
erc.json                       | d44e2dfd48c6959bb398a84a4b946591fc300177da68ef147584720749cc5ed3
layout.json                    | 2dfd9fc60622ad41d68f4f6c45b83fada4c5da90a1fc44fb155fa78eb274bfd6
runtime.json                   | 3195a9db18169452f0df3374830b203eedfc6d846594f3a0c17ffd6c63a1ad41
```

패키지 identity는 검토 당시 root 정본과 기존 native producer 모두 동결값과 일치했다. 설치 심볼 3종의 실제 bytes SHA도 선행 source-observation과 일치했다. 검증기 원본은 격리 snapshot의 `verify_quality.py`이며 기대 build는 기존 receipt의 KiCad 10.0.6, Konnect 0.13.0+hanall.1/94f80350cf67db27b179a06a8f6dbebfe4717927이다. 검토 모델의 exact 식별값은 입력되지 않아 미확인으로 남긴다.

## 다음 단계

Root가 GUI를 통한 저장/닫기/재열기 후 새 CAD SHA 및 fresh native 증거를 제공하면 이 초기 판정과 분리한 후속 재검토를 수행한다. 최초 보고는 GUI 이전 CAD에만 결속한다. read-only 검토라 되돌릴 CAD 변경은 없으며 보고/렌더 산출물만 별도 보존했다.
