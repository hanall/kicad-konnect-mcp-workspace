import hashlib,json,sys,xml.etree.ElementTree as ET
from pathlib import Path
from datetime import datetime
p=Path(sys.argv[1]).resolve(); o=Path(__file__).resolve().parent;n=p/'evidence/20261012-045534-native'
h=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
s=json.loads((p/'contracts/c1-rc-filter.semantic.json').read_text());r=json.loads((n/'runtime.json').read_text());l=json.loads((n/'layout.json').read_text());e=json.loads((n/'erc.json').read_text());x=ET.parse(n/'netlist.xml').getroot()
assert h(p/'registry.json')=='c1669c3beba5f2e0b491f2d82ddcc6d7c248f63168f13390a186db40b72ebc25'
assert h(p/'contracts/c1-rc-filter.semantic.json')=='39d1677c2d18ace6b273adbb56d72178f6723cc38837ef76284fb5324cd77382'
for k,v in r['candidate']['source_files'].items():assert h(p/k)==v
for k,f in {'netlist':'netlist.xml','layout':'layout.json','erc':'erc.json','pdf':'schematic.pdf'}.items():assert h(n/f)==r['candidate']['inputs_sha256'][k]
components={}
for c in x.findall('components/comp'):
 lib=c.find('libsource');components[c.attrib['ref']]={'value':c.findtext('value'),'lib_id':lib.attrib['lib']+':'+lib.attrib['part'],'footprint':c.findtext('fields/field[@name="Footprint"]') or ''}
assert components==s['components']
nets={z.attrib['name'].lstrip('/'):sorted(v.attrib['ref']+'.'+v.attrib['pin'] for v in z.findall('node')) for z in x.findall('nets/net')}
assert nets=={k:sorted(v) for k,v in s['nets'].items()}
for z in x.findall('nets/net/node'): assert z.attrib['pintype']==s['pin_types'][z.attrib['ref']+'.'+z.attrib['pin']]
sh=l['sheets']['rc-filter.kicad_sch']; wires=sh['layout']['wires'];pt=lambda x,y:(round(x,6),round(y,6))
ends=[(pt(w['x1'],w['y1']),pt(w['x2'],w['y2'])) for w in wires]
pins={c['reference']+'.'+v['number']:pt(v['x'],v['y']) for c in sh['pins']['components'] for v in c['pins']}
assert len(pins)==8
for c in sh['pins']['components']:
 assert c['unit_count']==1 and len(c['units'])==1 and c['units'][0]['unit']==1
 assert len(c['pins'])==2
points=set(pins.values())|{z for a,b in ends for z in (a,b)}|{pt(*z) for z in sh['junctions']}
parent={z:z for z in points}
def root(z):
 while parent[z]!=z:parent[z]=parent[parent[z]];z=parent[z]
 return z
def union(a,b):parent[root(a)]=root(b)
def on(z,a,b):
 return abs((z[0]-a[0])*(b[1]-a[1])-(z[1]-a[1])*(b[0]-a[0]))<1e-5 and min(a[0],b[0])-1e-6<=z[0]<=max(a[0],b[0])+1e-6 and min(a[1],b[1])-1e-6<=z[1]<=max(a[1],b[1])+1e-6
for a,b in ends:
 assert a[0]==b[0] or a[1]==b[1]
 for z in points:
  if on(z,a,b):union(a,z)
roots={}
for net,refs in nets.items():
 group={root(pins[ref]) for ref in refs};assert len(group)==1;roots[net]=next(iter(group))
assert len(set(roots.values()))==3
wire_ownership={net:[] for net in roots}
for i,(a,b) in enumerate(ends,1):
 owners=[net for net,rp in roots.items() if root(a)==rp];assert len(owners)==1;wire_ownership[owners[0]].append(i)
assert set(sh['layout']['labels'][i]['net'] for i in range(3))==set(nets)
for label in sh['layout']['labels']:assert root(pt(label['x'],label['y']))==roots[label['net']]
assert set(pt(*z) for z in sh['junctions'])=={pt(139.70,88.90),pt(139.70,109.22)}
assert len(e['sheets'])==1 and e['sheets'][0]['path']=='/' and not e['sheets'][0]['violations']
assert sorted(e['ignored_checks'],key=lambda z:z['key'])==sorted(s['erc']['policy']['ignored_checks'],key=lambda z:z['key'])
for rel,v in s['semantic_sources'].items():assert h(p/rel)==v
u=json.loads((p/'sources/unit-source-observation.json').read_text())
for z in u['symbols'].values():assert h(z['path'])==z['sha256']
report={'at':datetime.now().astimezone().isoformat(),'status':'PASS','scope':'독립 XML 집합 및 축평행 wire graph와 기존 증거 해시 대조. GUI·native 재생성·동적/제조 검사는 미실행.','components':components,'nets':nets,'placed_pin_endpoints':pins,'solid_wire_ownership':wire_ownership,'junctions':sh['junctions'],'erc_violations':[],'ignored_checks':e['ignored_checks'],'source_files':r['candidate']['source_files'],'native_hashes':r['candidate']['inputs_sha256'],'library_sources_hash_match':True,'semantic_sources_hash_match':True,'standard_verifier_initial_rc':2,'standard_verifier_approved_report_rc':0,'package_sha256':r['producer_package_identity']['sha256']}
(o/'independent-crosscheck.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('독립 집합/실선/해시 대조 PASS: 부품4/핀8/망3/실선11/junction2')
