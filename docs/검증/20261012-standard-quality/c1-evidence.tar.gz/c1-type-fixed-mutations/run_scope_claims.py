#!/usr/bin/env python3
"""실제 review raw evidence와 결속한 금지된 scope 승격 주장 사본을 검증한다."""
from __future__ import annotations
import hashlib,json
from pathlib import Path
import shutil,subprocess,sys

REPO=Path(__file__).resolve().parents[3]
ROOT=REPO/'.artifacts/20261012-040121-standard-quality'
CASE=ROOT/'isolation/case';PROJECT=CASE/'project'
SOURCE=PROJECT/'evidence/root-type-fixed';REVIEW=PROJECT/'evidence/root-actual-review/responses'
OUT=PROJECT/'evidence/c1-type-fixed-mutations/scope-01'
ART=ROOT/'c1-type-fixed-mutations'
VERIFIER=CASE/'skills-type-fixed/kicad-schematic-quality/scripts/verify_quality.py'
ORIGINAL_REGISTRY=PROJECT/'registry.json';ORIGINAL_SEMANTIC=PROJECT/'contracts/c1-rc-filter.semantic.json'
INPUTS=['netlist.xml','layout.json','erc.json','schematic.pdf','runtime.json']

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
def source_hashes():
 l=load(SOURCE/'layout.json');return {name:sha(PROJECT/name) for name in l['files']}

def copy_inputs(path):
 path.mkdir(parents=True,exist_ok=False)
 for name in INPUTS:shutil.copyfile(SOURCE/name,path/name)

def invoke(case,registry,registry_sha):
 report=case/'report.json'
 argv=[sys.executable,str(VERIFIER),'--project-root',str(PROJECT),'--registry',str(registry),'--registry-sha256',registry_sha,
       '--contract',str(case/'runtime.json'),'--netlist',str(case/'netlist.xml'),'--layout',str(case/'layout.json'),
       '--erc',str(case/'erc.json'),'--pdf',str(case/'schematic.pdf'),'--report',str(report),'--pdf-text-tool','/usr/bin/pdftotext']
 c=subprocess.run(argv,cwd=ART,text=True,capture_output=True)
 (case/'stdout.txt').write_text(c.stdout,encoding='utf-8');(case/'stderr.txt').write_text(c.stderr,encoding='utf-8')
 return argv,c,load(report)

def scope_case(name,key,review_refs,claim):
 case=OUT/name;copy_inputs(case)
 semantic=load(ORIGINAL_SEMANTIC);semantic['scope_limits'][key]='checked'
 sem=case/'semantic-scope-claim.json';dump(sem,semantic)
 registry=load(ORIGINAL_REGISTRY);profile=semantic['profile_id']
 registry['profiles'][profile]['semantic_contract']=str(sem.relative_to(PROJECT))
 registry['profiles'][profile]['sha256']=sha(sem)
 reg=case/'registry-scope-claim.json';dump(reg,registry);regsha=sha(reg)
 argv,c,report=invoke(case,reg,regsha)
 expected=f'scope_limits가 검증기 예약 scope를 확장할 수 없음: {key}=checked'
 errors=report.get('errors',[])
 result={'case':name,'claim':claim,'mutated_scope_key':key,'mutated_scope_value':'checked','rc':c.returncode,'status':report.get('status'),
         'expected_error':expected,'first_error':errors[0] if errors else '',
         'assertion_passed':c.returncode!=0 and report.get('status')=='FAIL' and any(expected in e for e in errors),
         'semantic_copy_sha256':sha(sem),'registry_copy_sha256':regsha,'original_semantic_sha256':sha(ORIGINAL_SEMANTIC),
         'original_registry_sha256':sha(ORIGINAL_REGISTRY),'caller_sha_update_class':'검증 전용 사본 registry bytes 고정; 원 oracle 변경 아님',
         'actual_review_receipts':[{'path':str((REVIEW/r).relative_to(PROJECT)),'sha256':sha(REVIEW/r)} for r in review_refs],
         'boundary':'검사 결과를 checked 주장으로 승격하지 못하게 하는 검증; PCB 거리/정격/DFM/제조 알고리즘 실증 아님',
         'argv':argv,'report_sha256':sha(case/'report.json')}
 dump(case/'result.json',result);return result

def main():
 if OUT.exists():raise SystemExit(f'기존 결과 덮어쓰기 거부: {OUT}')
 OUT.mkdir(parents=True,exist_ok=False);before=source_hashes()
 results=[
  scope_case('14-t11-pcb-distance','schematic_position_as_pcb_distance',['response-0007.json'],
             'decoupling result의 pcb_distance_checked=false를 PCB 거리 checked로 승격'),
  scope_case('15-t12-ratings','voltage_current_rating_and_sequencing',['response-0008.json'],
             'power rail 0 findings를 전압/전류 정격·sequencing checked로 승격'),
  scope_case('16-t13-t15-manufacturing-ready','pcb_manufacturing_energization_physical_safety',['response-0005.json'],
             'run_design_review 결과를 DFM·제조·발주 READY로 승격'),
 ]
 green=OUT/'99-green2';copy_inputs(green)
 argv,c,report=invoke(green,ORIGINAL_REGISTRY,sha(ORIGINAL_REGISTRY))
 green_result={'case':'99-green2','rc':c.returncode,'status':report.get('status'),'assertion_passed':c.returncode==0 and report.get('status')=='PASS',
               'registry_sha256':sha(ORIGINAL_REGISTRY),'semantic_sha256':sha(ORIGINAL_SEMANTIC),'argv':argv,'report_sha256':sha(green/'report.json')}
 dump(green/'result.json',green_result);results.append(green_result)
 after=source_hashes();summary={'schema_version':1,'status':'PASS' if all(x['assertion_passed'] for x in results) and before==after else 'FAIL',
  'results':results,'source_files_before':before,'source_files_after':after,'source_files_unchanged':before==after,
  'actual_review_interpretation':{'run_design_review':'footprint 4 errors and NOT_READY; no manufacturing approval',
   'audit_decoupling':'pcb_distance_checked=false and 0 power pins; not PCB proximity evidence',
   'audit_power_rails':'0 findings; not voltage/current/rating/sequencing evidence'},
  'cad_mcp_gui_writes':0}
 dump(OUT/'suite-summary.json',summary);dump(ART/'scope-claim-results.json',summary)
 return 0 if summary['status']=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())
