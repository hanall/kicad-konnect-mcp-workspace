#!/usr/bin/env python3
"""전용 공유 화면에서만 저장본을 열며 제품 원문과 전역 스킬을 가린다."""
import os,subprocess
from pathlib import Path
base=Path(__file__).resolve().parent
repo=base.parents[1]
project=base/'isolation/case/project'
gui_home=base/'gui-home'
empty=base/'isolation/empty'
display=os.environ.get('DISPLAY')
if display!=':188':raise SystemExit('검증한 전용 DISPLAY가 아니므로 GUI 실행 거부')
args=['bwrap','--die-with-parent','--unshare-pid','--new-session','--ro-bind','/','/','--proc','/proc','--dev','/dev','--tmpfs','/tmp','--ro-bind','/tmp/.X11-unix','/tmp/.X11-unix','--bind',str(project),str(project),'--bind',str(gui_home),str(gui_home)]
for p in [Path('/home/hanol/battery-module-cycler'),Path('/home/hanol/.claude'),Path('/home/hanol/.agents'),Path('/home/hanol/.codex'),Path('/home/hanol/.claude-codex-accounts'),repo/'skills',repo/'.claude',repo/'.agents']:
 if p.exists():args += ['--ro-bind',str(empty),str(p)]
for name in ['registry.json','contracts','sources','plan-index.json','plans']:
 p=project/name;args += ['--ro-bind',str(p),str(p)]
args += ['--chdir',str(project),'--','/usr/local/bin/eeschema',str(project/'rc-filter.kicad_sch')]
env={'HOME':str(gui_home),'XDG_CONFIG_HOME':str(gui_home/'.config'),'XDG_CACHE_HOME':str(gui_home/'.cache'),'XDG_DATA_HOME':str(gui_home/'.local/share'),'XDG_STATE_HOME':str(gui_home/'.local/state'),'XDG_RUNTIME_DIR':str(gui_home/'run'),'PATH':'/usr/local/bin:/usr/bin:/bin','LANG':'ko_KR.UTF-8','DISPLAY':display,'APPIMAGE_EXTRACT_AND_RUN':'1','KICAD10_SYMBOL_DIR':'/opt/kicad/10.0.6/share/kicad/symbols','KICAD10_FOOTPRINT_DIR':'/opt/kicad/10.0.6/share/kicad/footprints','KICAD10_3DMODEL_DIR':'/opt/kicad/10.0.6/share/kicad/3dmodels','LIBGL_ALWAYS_SOFTWARE':'1'}
if os.environ.get('XAUTHORITY'):env['XAUTHORITY']=os.environ['XAUTHORITY']
raise SystemExit(subprocess.run(args,env=env).returncode)
