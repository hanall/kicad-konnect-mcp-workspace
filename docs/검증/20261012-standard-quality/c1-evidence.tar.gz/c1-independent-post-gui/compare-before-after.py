import json,sys,hashlib,xml.etree.ElementTree as ET
from pathlib import Path
from datetime import datetime
b=Path(sys.argv[1]).resolve();p=b/'isolation/case/project';out=Path(__file__).resolve().parent;h=lambda z:hashlib.sha256(z.read_bytes()).hexdigest();g=b/'gui-evidence';rt=json.loads((g/'roundtrip.json').read_text())
assert h(g/'roundtrip.json')=='94415f6985ae0b277aaea00d3173ccfbc2604548cfed29610d33fd5dc5b0a529'
assert h(p/'rc-filter.kicad_sch')=='e6c1430b85bf357815b15eabce639948911566ddf489c416673a73e600170672'
assert h(p/'rc-filter.kicad_pro')=='98c5755db6d6a73e4bcecfcc39e280c97bb6d3a51904b05f5a142e50d81a221c'
for rel,v in rt['after_sha256'].items():assert h(p/rel)==v
for name,z in rt['screenshots'].items():assert h(Path('/home/hanol/kicad-konnect-mcp-workspace')/z['path'])==z['sha256']
assert rt['locks_after']==[] and rt['gui_mcp_concurrent_writes']==0 and rt['cad_text_edits']==0
old=p/'evidence/20261012-045534-native';new=p/'evidence/root-post-gui'
def xn(f):
 x=ET.parse(f).getroot();cs={}
 for c in x.findall('components/comp'):
  lib=c.find('libsource');cs[c.attrib['ref']]={'value':c.findtext('value'),'footprint':c.findtext('fields/field[@name="Footprint"]') or '', 'lib':lib.attrib['lib'],'part':lib.attrib['part'],'sheetpath':c.find('sheetpath').attrib,'units':{z.attrib['name']:sorted(a.attrib['num'] for a in z.findall('pins/pin')) for z in c.findall('units/unit')}}
 ns={z.attrib['name']:sorted(tuple(sorted(a.attrib.items())) for a in z.findall('node')) for z in x.findall('nets/net')}
 lp={z.attrib['lib']+':'+z.attrib['part']:sorted(tuple(sorted(a.attrib.items())) for a in z.findall('pins/pin')) for z in x.findall('libparts/libpart')}
 return {'components':cs,'nets':ns,'library_pins':lp}
a=xn(old/'netlist.xml');c=xn(new/'netlist.xml');assert a==c
la=json.loads((old/'layout.json').read_text())['sheets']['rc-filter.kicad_sch'];lb=json.loads((new/'layout.json').read_text())['sheets']['rc-filter.kicad_sch']
def canonical(z):
 if isinstance(z,float):return round(z,6)
 if isinstance(z,list):return [canonical(a) for a in z]
 if isinstance(z,dict):return {k:canonical(v) for k,v in sorted(z.items()) if k!='uuid'}
 return z
def sorted_records(z):return sorted([canonical(a) for a in z],key=lambda a:json.dumps(a,sort_keys=True))
geometry={}
for k in ['components','labels','wires']:
 assert sorted_records(la['layout'][k])==sorted_records(lb['layout'][k]);geometry[k]='exact_normalized_equal'
assert sorted_records(la['pins']['components'])==sorted_records(lb['pins']['components']);geometry['pins']='exact_normalized_equal'
assert sorted_records(la['junctions'])==sorted_records(lb['junctions']);geometry['junctions']='exact_normalized_equal'
assert sorted_records(la['texts'])==sorted_records(lb['texts']);geometry['texts']='exact_normalized_equal'
ea=json.loads((old/'erc.json').read_text());eb=json.loads((new/'erc.json').read_text());assert sorted_records(ea['ignored_checks'])==sorted_records(eb['ignored_checks']);assert ea['included_severities']==eb['included_severities'];assert all(not s['violations'] for s in ea['sheets']+eb['sheets'])
render={}
for f in ['pdf-full-1.png','pdf-circuit-1.png']:
 before=b/'c1-independent-initial'/f;after=out/f;assert h(before)==h(after);render[f]=h(after)
report={'at':datetime.now().astimezone().isoformat(),'status':'PASS','roundtrip_receipt_sha256':h(g/'roundtrip.json'),'before_cad_sha256':rt['before_sha256']['rc-filter.kicad_sch'],'after_cad_sha256':h(p/'rc-filter.kicad_sch'),'xml_electrical_inventory_equal':True,'layout_geometry_equal':geometry,'erc_policy_equal':True,'pdf_render_equal':render,'screenshots_hashes_match':True,'receipt_after_source_hashes_match':True,'gui_actions_evidence':'Root 왕복 receipt와 해시결속 캡처를 독립 확인. 검토자가 GUI 동작을 직접 수행한 것은 아님.','runtime_companion_binding':'native runtime의 companion_receipts가 빈 값이므로 공개검증기는 GUI receipt를 검증하지 않음; 이 보고의 별도 독립 검사가 GUI receipt를 결속.'}
(out/'before-after-comparison.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print('전후 전기집합·기하·정책·렌더·GUI증거 해시 대조 PASS')
