# C1 GUI 왕복 이후 독립 읽기 재검토

작성 시각: 2026-10-12T05:15:41.940101+09:00
검토자: `/root/standard_c1_independent`

## 결론

**새 저장본 SHA의 정적 계약·GUI 캡처 전페이지/확대·새 native PDF 전페이지/확대·전후 전기 불변 대조를 통과했다.** 현저 차단 결함은 관측하지 않았다. 최초 정적 PASS를 승계하지 않고 후속 SHA에서 공개 검증기를 다시 실행했고 원 rc=0을 얻었다. 제목 공백 등 기존 낮은 문서 항목과 footprint 미할당/실물 비검증 범위는 그대로 남긴다.

GUI 왕복은 Root가 수행한 실제 GUI 캡처와 왕복 영수증을 받아 독립 검토한 사실이다. 검토자가 GUI 저장·닫기·재열기를 직접 수행했다고 말하지 않는다. 제조·통전·PCB·정격·동적 성능·실물 안전·인증 완료가 아니다.

## 범위·독립성

명시 요구: GUI 변환 후 새 SHA·GUI 캡처 5개·새 native PDF/전기계약/실선·전후 전기 불변을 독립 확인하고 기존 낮은 항목을 유지한다.
사용한 가정: 같은 동결 package/registry/semantic/계획이 계속 정답이며 GUI 저장은 전기·제목 변경 요청이 아니라 형식 왕복이다. 이 가정은 새 XML/layout 전수 대조로 검증했다.

`AUTHOR-RESULT.md`, `self-review.md` 및 작성자 결론/자체 점수는 여전히 미열람이다. 원 요구·semantic·사전 계획·GUI 동작 영수증·기계 증거는 읽었다. 완전 무맥락 blind 검토는 아니나 작성자 결론과 분리된 독립 판독이다.

CAD/plan/registry/semantic mutation·저장, GUI 조작, MCP 서버 호출, lock 변경, 계정 접촉, commit/push는 검토자 기준 모두 0. 자기 후속 산출물 폴더와 명시 허용받은 `project/evidence/c1-independent-post-gui/report.json`만 작성했다. 초기 원 실패·원 보고는 덮어쓰지 않았다. MCP 시간 도구가 노출되지 않아 셸 실측 시각을 사용했다.

## 새 SHA와 전후 변화

```text
artifact            | before                                                           | after
--------------------+------------------------------------------------------------------+-----------------------------------------------------------------
rc-filter.kicad_sch | 25503f5d765522f8191a92996779fdbf9a092da848adfbe52e8eb7f1da910b70 | e6c1430b85bf357815b15eabce639948911566ddf489c416673a73e600170672
rc-filter.kicad_pro | a3b8289a4101439ffbd8b97954cb8e9d8052fcf83ac670cdc32cf32a9209ed6f | 98c5755db6d6a73e4bcecfcc39e280c97bb6d3a51904b05f5a142e50d81a221c
```

GUI 영수증의 after SHA는 현재 실제 bytes와 exact 일치한다. PCB·project symbol library table·plan-index·공통/페이지 계획은 영수증의 전후 SHA가 동일하며 현재도 일치한다. schematic/project bytes가 바뀌었으므로 초기 source SHA의 증거를 새 source의 검증으로 재사용하지 않았다.

전후 전기 불변은 새 native XML의 부품/ref/value/footprint/symbol/unit/물리핀번호·type·망 membership을 초기 native XML과 대조했다. layout의 부품 배치/회전/mirror, 핀 endpoint/길이/방향/unit, 모든 wire, label, junction, 본문 text도 순서와 UUID를 제외하고 소수점 6자리 정규화로 exact 일치했다. ERC included severities·기본 비활성 정책과 위반 목록도 동일했다. 이를 `before-after-comparison.json`에 보존했다.

## 후속 정적 검증

```text
check                                | rc | status
-------------------------------------+----+--------
verify_quality post-GUI               |  0 | PASS
independent XML / wire / hash         |  0 | PASS
before-after XML / geometry / policy  |  0 | PASS
```

검증 입력은 새 `project/evidence/root-post-gui/`의 runtime/XML/layout/ERC/PDF이며 기대 registry SHA는 caller 고정값이다. 공개 검증기의 report는 새 허용 경로에 작성했고 자기폴더에는 원 로그·rc 및 동일 보고 사본을 보존했다. 초기 outside-root 경계거부 rc2는 초기 기록으로 유지하며 후속 PASS와 합치거나 삭제하지 않는다.

새 native 생성 명령도 `commands.json`에 root source의 `kicadxml` 명시 XML, PDF, ERC `--severity-all --exit-code-violations`, 각각 rc0로 기록돼 있다. 검토자가 native를 새로 생성한 것은 아니며 Root collector의 새 증거를 독립 검증했다.

```text
net   | exact_pin_members        | solid_wire_ids
------+--------------------------+--------------------
VIN   | J1.1 R1.1                | 1
VOUT  | R1.2 C1.1 J2.1           | 2 3 4
GND   | J1.2 C1.2 J2.2           | 5 6 7 8 9 10 11
```

부품 4·물리 핀 8·망 3·실선 11·junction 2. 부품 모두 unit1/passive pin이며 R1=1k, C1=100n, J1=VIN, J2=VOUT이다. 가까운 3망 각각 단일 wire-only root이고 cross-net root·orphan·short는 대조 범위에서 0이다. T junction 두 곳은 `(139.70,88.90)`, `(139.70,109.22)`이며 label-only 연결이나 wire 누락은 없다.

## GUI 캡처와 새 PDF 실제 판독

Root 영수증에는 전용 `DISPLAY=:188`, loopback port6170, memory 16GiB, 전용 GUI HOME, bwrap 가림, 기존 saved 열기→Ctrl+S 변환저장→정상종료→재열기→정상종료·최종 lock 빈 목록이 기록됐다. 영수증 SHA와 캡처 5개 SHA를 실제 bytes로 확인했다.

```text
capture           | direct_visual_review | observed_state
------------------+----------------------+-------------------------
before-page       | checked              | full_page / old_format
before-circuit    | checked              | complete_circuit
saved-circuit     | checked              | save_status / same_shape
reopened-page     | checked              | full_page / no_banner
reopened-circuit  | checked              | complete_circuit
native-PDF-page1  | checked              | full_page
native-PDF-zoom1  | checked              | complete_circuit
```

초기 GUI에는 이전 KiCad 형식·저장 시 변환 안내가 보인다. 저장 후 안내가 사라지고 상태줄에 저장됐다는 문구가 보인다. 재열기 전페이지와 회로 확대에서 같은 RC 경로·값·접점·반환 레일을 읽었다. title block 공백과 R/C 물리핀번호 비표시는 보존됐다. 프레임·표제란·회로가 페이지 안에 있으며 ref/value/net/커넥터 pin1/2 문자획이 실제 배선에 관통되거나 잘린 현저 결함을 발견하지 않았다.

새 PDF를 동일 `pdftoppm` 설정으로 새로 렌더했다. PDF bytes SHA는 바뀌었지만 전체페이지 PNG와 회로 확대 PNG는 각각 초기 렌더와 **bytes SHA까지 동일**했다. 이미지 동일성은 PDF 표면의 표현 보존 보조 증거이며 전기 집합/핀/실선 검사는 별도로 수행했다.

```text
render             | before_after_sha256
-------------------+-----------------------------------------------------------------
pdf-full-1.png     | cf821ca4f2eca587af12f194070a172d542963bee21f5d9327b6af188b5be08b
pdf-circuit-1.png  | df8ae0a79d7620aceea74275eb0bde5d027cfa3a7ad826b69344e46713bbbf0c
```

## 후속 읽기 과제

```text
J1.1 -- VIN -- R1(1k) --+-- VOUT -- J2.1
                       |
                     C1(100n)
                       |
J1.2 ------ GND -------+---------- J2.2
```

입력흐름: J1.1→R1.1→R1.2 뒤 VOUT→J2.1을 새 GUI/PDF에서 따라 읽었다. R1 pin1/2 번호 자체는 export/endpoint로 결속한다.

RC 반환: VOUT T 접점에서 아래 C1.1으로 내려가고 C1.2는 하단 GND T 접점으로 닫힌다. 하단 실선 레일은 J1.2와 J2.2를 잇는다.

분기해석: 상단 VOUT junction은 출력 J2.1과 C1.1 분기이며 하단 junction은 C1.2와 두 커넥터 반환을 연결한다. 왼쪽/오른쪽 반환 수직선은 상단 신호선에 닿지 않는다. GND는 이 예제의 공통 반환이며 PE·chassis·Kelvin이나 절연 반환으로 확대하지 않는다. 실제 전류량/동적 파형을 계산 또는 시험한 것이 아니다.

feedback/보상, off-page port, 반복 channel, 부유/Kelvin/PE 항목은 선행 계약의 빈 목록에 따라 해당 없음이다.

## ERC·낮은 항목·남은 경계

ERC root sheet `/` 전체의 오류0·경고0·개별 제외0, 포함 severity는 error/warning/exclusion이다. 기본 비활성4종은 선행 semantic 및 전후 native JSON에 exact 일치한다.

```text
ignored_check
----------------------
footprint_filter
four_way_junction
simulation_model_issue
single_global_label
```

기본 비활성을 모든 규칙 통과로 바꾸지 않는다. PWR_FLAG·NC·pin type 변경 등으로 경고를 숨긴 인벤토리는 없다.

- 낮은 문서 항목: Title/Date/Rev 공백은 계속 남는다. 본문 제목과 파일명/페이지 번호는 표시된다. 원 예제의 사전계획 예외와 일치하며 정식 인계본 표제란 보완 여부는 Root가 결정한다.
- 판독 한계: 비극성 R1/C1의 물리핀번호는 GUI/PDF에서 보이지 않는다. 기능 경로는 읽히며 exact 번호는 XML 및 endpoint 증거로 닫았다. 모든 ref.pin을 PDF만 보고 판독하는 별도 과제는 완료 선언하지 않는다.
- footprint 4개 미할당은 계약값 그대로다. MPN/package·실물 커넥터 mating view·PCB pad/배치·정격·전압/전류·공차·동적·제조·통전·실물 안전·인증은 미검증이다.
- GUI 동작/정상종료·lock0은 Root 영수증에서 받은 사실이며 캡처 자체가 전 과정을 증명하는 것은 아니다. 검토자는 살아 있는 GUI process를 조작하거나 lock을 재검사하지 않았다.
- 새 runtime의 `companion_receipts`는 빈 값이다. 그러므로 공개 검증기가 GUI 왕복 영수증을 검증했다고 쓰지 않는다. 별도 독립 대조 코드가 GUI receipt hash와 전후 source hash·캡처 5개를 결속했다.
- CLI `/usr/local/bin/kicad-cli` launcher가 `/opt/kicad/10.0.6/kicad-10.0.6-x86_64.AppImage`를 호출하는 것은 직접 조회했다. GUI 설정 snapshot의 상대파일 SHA도 받았다. 실제 native HOME 경로·환경값/`APPIMAGE_EXTRACT_AND_RUN=1` 결속 receipt는 이 보고 작성 시 추가 확인을 요청했으며, 확인 전까지 launcher 경로 일치와 실제 실행환경 일치를 혼동하지 않는다.
- 패키지 검증기 수정이나 mutation 시험을 수행하지 않았으므로 이 후속 검토를 패키지 전체 RED-GREEN-mutation-GREEN2, 모든 모델/회로 유형 지원 완료로 올리지 않는다.

## 증거 SHA

```text
artifact                          | sha256
----------------------------------+-----------------------------------------------------------------
package                           | b274e7d851c129bb62402d1d71f18b43a772d29326ba612ce4cd2954233f4fbf
registry.json                     | c1669c3beba5f2e0b491f2d82ddcc6d7c248f63168f13390a186db40b72ebc25
semantic                          | 39d1677c2d18ace6b273adbb56d72178f6723cc38837ef76284fb5324cd77382
roundtrip.json                    | 94415f6985ae0b277aaea00d3173ccfbc2604548cfed29610d33fd5dc5b0a529
post-GUI netlist.xml               | 12a96be6d8dafac67941322d5ecb6b3b8e7564f159b3312d31a56db000142fe4
post-GUI schematic.pdf             | 0796e26a594b9c924db82d0a0b59571adbf38b02d029f1afdac8920fda2bf788
post-GUI erc.json                  | 43de7947abe29da5a68977eea53827c382408d9bfd3af83a1e4fd19ab3c54074
post-GUI layout.json               | ef99d2fb9ec3a9cd2b629e2b0c9b0e68085b2cfec1514c4811c9bda6cc3b0eb9
post-GUI runtime.json              | a5f0beb338c17ffade568c20939ca21b3fe3ae42b4655956d160583de7d9520c
independent verifier report        | 58ab64b849e83976b9734f1b230f837d47749a39e5333b17f35c49a8441eea92
```

## 다음 판단

C1의 이 실제 실행 조합에서는 같은 동결 package와 선행 계약에 대해 GUI 왕복 후 정적·시각·읽기·전기 불변의 제한적 증거가 생겼다. 지원표를 갱신할지는 Root가 실제 host/model/tool/과제 receipt 및 남은 provenance 제한을 함께 보고 판단한다. 새 변경이나 새 package SHA에는 이 결과를 자동 승계하지 않는다.
