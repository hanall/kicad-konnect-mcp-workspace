# C1 후속 독립 검토: native 실행환경 증거 보충

작성 시각: 2026-10-12T05:18:29.049837+09:00
대상 CAD SHA: `e6c1430b85bf357815b15eabce639948911566ddf489c416673a73e600170672`

## 결론과 제한

**초기 후속 보고의 native HOME/env 결속 대기는 실제 호출·코드 경로·설정 사본 증거 범위에서 해소됐다.** Root의 현재 rollout 정확 행, 발췌 파일, 환경 영수증, runner, 수집 명령과 실제 설정 사본을 대조했다. 이것은 실제 native process의 `/proc/.../environ` 직접 관측이나 AppImage 내부 runtime 환경 확인이 아니다. 정적·GUI/PDF 독립 판독과 전후 전기 불변 결과는 그대로 유지하며 제조·통전·실물 안전 범위로 확대하지 않는다.

원 후속 보고 `20261012-051541_c1-independent-post-gui.md/.html`은 수정하지 않고 이 보충으로 환경 항목만 갱신했다. CAD·project·registry·semantic·계획·GUI/MCP는 쓰지 않았다. 작성자결론/자체검토MD도 계속 미열람이다.

## 실제 호출과 증거 해시

환경 영수증의 SHA 및 그 안의 tool-call 발췌/runner/config-snapshot/collector-commands SHA를 실제 bytes로 대조했다. Root session JSONL의 **정확 41841행만** 읽어 발췌의 timestamp/type/payload가 원 행과 exact 일치함을 확인했다. 실행 시각 원문은 `2026-10-11T20:09:43.516Z`이며 추출 파일이 과거 다른 호출을 대신 가리키지 않는다.

원 함수 입력 안의 같은 셸 호출은 GUI HOME을 native 전용 HOME으로 `copytree`한 뒤 복사 당시 파일 bytes SHA snapshot을 기록하고, 격리 runner 안의 명시 `env` 명령으로 아래 값을 collector에 전달한다. collector 출력 경로는 새 `project/evidence/root-post-gui`이며 그 명령 기록과 원 rc0는 기존 후속 증거에 exact 결속된다.

```text
env_key                 | explicit_value
------------------------+-----------------------------------------------------------------------------------
APPIMAGE_EXTRACT_AND_RUN | 1
HOME                    | .../isolation/case/work/post-gui-native-home
XDG_CONFIG_HOME         | .../isolation/case/work/post-gui-native-home/.config
XDG_DATA_HOME           | .../isolation/case/work/post-gui-native-home/.local/share
XDG_CACHE_HOME          | .../isolation/case/work/post-gui-native-home/.cache
XDG_STATE_HOME          | .../isolation/case/work/post-gui-native-home/.local/state
```

전체 절대경로는 `native-environment-independent.json`의 `caller_environment`에 생략 없이 기록했다.

## 환경 상속 코드 대조

```text
Root exec_command
  -> run-isolated.py
     -> bwrap + runner_env(HOME=/home/hanol)
        -> env(HOME=post-gui-native-home, XDG_*, APPIMAGE_EXTRACT_AND_RUN=1)
           -> collect_evidence.py
              -> subprocess.run(native_argv)
                 -> /usr/local/bin/kicad-cli
                    -> KiCad-10.0.6.AppImage + kicad-cli
```

runner는 자체 child 환경의 HOME을 `/home/hanol`로 정하지만, 실제 command 위치의 `env HOME=... XDG_*=... APPIMAGE_EXTRACT_AND_RUN=1`이 bwrap 안에서 이를 다시 명시값으로 덮어쓴다. runner가 command 배열 뒤에 HOME을 다시 덮어쓰는 코드는 없다.

수집기 `run_command`는 `subprocess.run(argv, ..., check=False)`를 호출하며 `env` override나 `os.environ` 변경이 없다. CLI shell wrapper도 `set -eu` 뒤 같은 AppImage에 `exec ... kicad-cli "$@"`만 호출하며 HOME/XDG/APPIMAGE 값을 재설정하지 않는다. 따라서 **caller가 명시한 환경이 wrapper까지 상속되는 호출 코드 경로**를 확인했다. AppImage binary 내부가 최종 process 환경을 어떻게 처리했는지는 직접 관측하지 않았으며 이 코드 대조를 그 증명으로 쓰지 않는다.

## GUI 설정 사본 전후 상태

snapshot의 KiCad `.config` 8개 파일은 현재 GUI HOME의 bytes와 모두 일치했다. 현재 native HOME의 같은 파일은 7개 bytes 동일이고 1개가 다르다. 이 차이를 지우거나 전부 동일이라고 합성하지 않았다.

```text
config_file                   | GUI_snapshot_vs_current_GUI | native_current_vs_snapshot
------------------------------+-----------------------------+----------------------------
kicad_common.json             | exact                       | changed
other_KiCad_config_files(7)    | exact                       | exact
```

현재 native `kicad_common.json` SHA는 `89b8dd622cda766defe2e5cb51a672ef706cff86afe7a61c9c7a04bb981e59c3`이며 snapshot/현재GUI의 SHA는 `382ea95d3a79d12e782035a7729ab2975869be4685c00dc14711a50ed8222911`이다. JSON을 독립 비교한 유일한 차이는 `/system/working_dir`이다.

```text
state | system.working_dir
------+------------------------------------------------------------------
GUI   | .../isolation/case/project
native| .../isolation/case
```

이는 runner의 `--chdir`에 대응하는 실행 후 작업디렉터리 메타값 변화로 해석한다. 그 인과 자체를 process 관측으로 증명한 것은 아니다. pin/library/ERC 정책·symbol table 변경은 이 JSON 대조에서 없고, 별도 post-GUI native contract 및 전후 전기 집합 대조는 이미 rc0이다. 각 파일의 전체 SHA와 경로는 JSON 보충 영수증에 기록했다.

## 주요 정확 SHA

```text
artifact                         | sha256
---------------------------------+-----------------------------------------------------------------
native-environment-receipt.json  | 5722eaa69a19d39d91ff0f2a529c4a306dfb5d62998bfb78269f0c747d30fa2e
native-execution-tool-call.json  | 5c60d6d151e317ae2a983f8f67f100a784b0d54f6da96a24cf3cfac470c567bb
run-isolated.py                  | f787ded9ad763847ae681fa678eb053a7449ead9e58a13445fe26a115576d523
native-config-snapshot.json      | 947c58ccf04bdb9dfcb20ed517555d433e3176dcbe3814ba5a951649c6b9a6c2
root-post-gui/commands.json      | f7df1e07c3f79efa14a5f8f49e1e8f8bf8cb9dd822a0f3b22e1d1cf415a9637d
/usr/local/bin/kicad-cli         | 73f48ac6e9ee2b4ebfdcdc6fdf1c826cee61335f87e6fbecfe866bdb0e8b8794
```

최종 선언은 **caller 실행환경 provenance 보충 확인**이다. 원 native process 환경 직접확인, 모든 runtime 삼각 대조, AppImage 내부 동작, 전체 공급망 또는 제품 안전 완료로 과장하지 않는다.
