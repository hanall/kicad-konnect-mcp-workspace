# C1 실제 native 산출물 사본 변이 검증

상태: `MUTATIONS-REJECTED / GREEN2-PASS / ONE-SCHEMA-TYPE-SURVIVOR`

## 실행 경계

- 원본 후보 CAD와 원 registry·semantic·plan은 읽기만 했으며 변경하지 않았다.
- 실제 MCP·GUI·CAD 쓰기는 0회다.
- 원 native XML/layout/ERC/PDF/runtime을 `project/evidence/c1-actual-mutations/run-02/`와 `run-03/` 아래 새 디렉터리로 복사한 뒤 사본만 변이했다.
- XML/layout/ERC/PDF 변이는 runtime `candidate.inputs_sha256`을 변이 bytes에 맞춰 다시 봉인했다. 따라서 단순 입력 hash 불일치가 아니라 각 구조·전기·실선·정책 검사가 거부했는지 확인했다.
- producer package·plan은 actual runtime에서 복사했고 새로 합성하지 않았다.

## 결과

- 실제 native 입력의 무변이 control과 최종 GREEN2: rc0/PASS.
- value, net-pin, pintype, unit, wire gap, orphan evidence 누락, ignored ERC 추가, severity 누락, PDF 손상, producer package, producer plan, 필수 ERC 누락: 12/12 rc1/FAIL이며 기대 인과 문구 일치.
- actual review 결과에 결속한 금지 scope 승격 3건: 3/3 rc1/FAIL.
  - `audit_decoupling`의 `pcb_distance_checked=false`를 PCB 거리 확인으로 승격하지 못함.
  - `audit_power_rails` 0 findings를 전압·전류 정격·sequencing 확인으로 승격하지 못함.
  - `run_design_review`의 footprint 4건 error/NOT_READY를 DFM·제조·발주 READY로 승격하지 못함.
- 위 3건은 주장 승격 거부 시험이며 PCB 거리·정격·DFM 알고리즘의 성능 실증이 아니다.

## 공개 결함 survivor

검증 전용 registry 사본에서 `schema_version`을 정수 `1` 대신 boolean `true`로 바꾸고 caller가 그 사본 SHA를 명시했다. 현재 검증기는 Python의 `True == 1` 비교 때문에 rc0/PASS했다. 이는 엄밀 schema 타입 결함이며 원문과 고정 패키지는 수정하지 않았다.

## 무결성

- `rc-filter.kicad_sch`: `e6c1430b85bf357815b15eabce639948911566ddf489c416673a73e600170672`
- 원 registry: `c1669c3beba5f2e0b491f2d82ddcc6d7c248f63168f13390a186db40b72ebc25`
- 원 semantic: `39d1677c2d18ace6b273adbb56d72178f6723cc38837ef76284fb5324cd77382`
- frozen package identity: `b274e7d851c129bb62402d1d71f18b43a772d29326ba612ce4cd2954233f4fbf`

최초 orchestration은 잘못된 repository parent 계산으로 source를 찾기 전에 rc1이었다. mutation은 시작되지 않았고 잘못 만든 `/home/hanol/.artifacts/.../c1-actual-mutations` 빈 leaf는 즉시 제거했다. 원 로그와 cleanup 사실은 보존했다. 유효 결과는 `run-02`와 `run-03`이다.
