#!/usr/bin/env python3
"""실제 C1 native 산출물의 격리 사본만 변이해 공개 검증기의 인과 거부를 기록한다."""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

REPO = Path(__file__).resolve().parents[3]
ROOT = REPO / ".artifacts/20261012-040121-standard-quality"
CASE = ROOT / "isolation/case"
PROJECT = CASE / "project"
SOURCE = PROJECT / "evidence/root-post-gui"
OUT = PROJECT / "evidence/c1-actual-mutations/run-02"
ART = ROOT / "c1-actual-mutations"
SKILL = CASE / "skills/kicad-schematic-quality"
VERIFIER = SKILL / "scripts/verify_quality.py"
REGISTRY = PROJECT / "registry.json"
REGISTRY_SHA = "c1669c3beba5f2e0b491f2d82ddcc6d7c248f63168f13390a186db40b72ebc25"
INPUT_NAMES = {"netlist": "netlist.xml", "layout": "layout.json", "erc": "erc.json", "pdf": "schematic.pdf"}


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def dump(path: Path, value) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def source_hashes() -> dict[str, str]:
    layout = load(SOURCE / "layout.json")
    return {name: sha(PROJECT / name) for name in layout["files"]}


def refresh_runtime(case: Path) -> None:
    runtime = load(case / "runtime.json")
    runtime["candidate"]["inputs_sha256"] = {
        key: sha(case / name) for key, name in INPUT_NAMES.items()
    }
    dump(case / "runtime.json", runtime)


def copy_inputs(case: Path) -> None:
    case.mkdir(parents=True, exist_ok=False)
    for name in [*INPUT_NAMES.values(), "runtime.json"]:
        shutil.copyfile(SOURCE / name, case / name)


def xml_component(tree: ET.ElementTree, ref: str):
    return next(item for item in tree.findall("./components/comp") if item.get("ref") == ref)


def xml_node(tree: ET.ElementTree, ref: str, pin: str):
    for net in tree.findall("./nets/net"):
        for node in net.findall("node"):
            if node.get("ref") == ref and node.get("pin") == pin:
                return net, node
    raise AssertionError((ref, pin))


def mutate_value(case: Path) -> str:
    path = case / "netlist.xml"; tree = ET.parse(path)
    xml_component(tree, "R1").find("value").text = "2k"
    tree.write(path, encoding="utf-8", xml_declaration=True)
    return "R1 value 1k -> 2k"


def mutate_netpin(case: Path) -> str:
    path = case / "netlist.xml"; tree = ET.parse(path)
    source, node = xml_node(tree, "R1", "1")
    target = next(net for net in tree.findall("./nets/net") if net.get("name") == "/VOUT")
    source.remove(node); target.append(node)
    tree.write(path, encoding="utf-8", xml_declaration=True)
    return "R1.1 net VIN -> VOUT"


def mutate_pintype(case: Path) -> str:
    path = case / "netlist.xml"; tree = ET.parse(path)
    _, node = xml_node(tree, "R1", "1"); node.set("pintype", "output")
    tree.write(path, encoding="utf-8", xml_declaration=True)
    return "R1.1 pintype passive -> output"


def mutate_unit(case: Path) -> str:
    path = case / "layout.json"; data = load(path)
    component = next(row for row in data["sheets"]["rc-filter.kicad_sch"]["pins"]["components"]
                     if row["reference"] == "R1")
    next(pin for pin in component["pins"] if pin["number"] == "1")["unit"] = 2
    dump(path, data)
    return "R1.1 top-level unit 1 -> 2"


def mutate_wiregap(case: Path) -> str:
    path = case / "layout.json"; data = load(path)
    wire = next(row for row in data["sheets"]["rc-filter.kicad_sch"]["layout"]["wires"]
                if row["uuid"] == "3e4e595e-8200-4023-8333-1e42dceac500")
    assert wire["x2"] == 110.49 and wire["y2"] == 88.9
    wire["x2"] = 109.22
    dump(path, data)
    return "VIN solid wire endpoint shortened 110.49 -> 109.22 mm before R1.1"


def mutate_missing_orphan(case: Path) -> str:
    path = case / "layout.json"; data = load(path)
    del data["sheets"]["rc-filter.kicad_sch"]["orphans"]
    dump(path, data)
    return "required raw orphan evidence field removed"


def mutate_ignored_erc(case: Path) -> str:
    path = case / "erc.json"; data = load(path)
    data["ignored_checks"].append({"description": "Mutation-only ignored check", "key": "mutation_ignore"})
    dump(path, data)
    return "unexpected ERC ignored_checks entry added"


def mutate_severity(case: Path) -> str:
    path = case / "erc.json"; data = load(path)
    data["included_severities"] = [item for item in data["included_severities"] if item != "warning"]
    dump(path, data)
    return "warning removed from ERC included_severities"


def mutate_pdf(case: Path) -> str:
    path = case / "schematic.pdf"; data = path.read_bytes()
    path.write_bytes(data[: max(64, len(data) // 2)])
    return "native PDF truncated to half bytes"


def mutate_package(case: Path) -> str:
    path = case / "runtime.json"; data = load(path)
    data["producer_package_identity"]["sha256"] = "0" * 64
    dump(path, data)
    return "runtime producer package identity sha256 replaced"


def mutate_plan(case: Path) -> str:
    path = case / "runtime.json"; data = load(path)
    data["producer_plan_binding"]["plan_index"]["sha256"] = "0" * 64
    dump(path, data)
    return "runtime producer plan-index sha256 replaced"


def mutate_missing_erc(case: Path) -> str:
    path = case / "erc.json"; data = load(path)
    del data["sheets"]
    dump(path, data)
    return "required native ERC sheets field removed (T10)"


MUTATIONS = [
    ("01-value", mutate_value, "부품 속성 불일치 R1"),
    ("02-netpin", mutate_netpin, "net-pin 전수 계약 불일치"),
    ("03-pintype", mutate_pintype, "pin type 계약 불일치"),
    ("04-unit", mutate_unit, "top pin-semantic unit 소유 불일치"),
    ("05-wiregap", mutate_wiregap, "실선 그룹 분리"),
    ("06-missing-orphan", mutate_missing_orphan, "layout sheet 필수 필드 누락"),
    ("07-ignored-erc", mutate_ignored_erc, "ERC 비활성/포함 severity policy 불일치"),
    ("08-severity-missing", mutate_severity, "ERC 비활성/포함 severity policy 불일치"),
    ("09-pdf-damaged", mutate_pdf, "PDF text 검사가 unknown 상태로 실패"),
    ("10-producer-package", mutate_package, "producer package identity"),
    ("11-producer-plan", mutate_plan, "producer_plan_binding"),
    ("12-required-erc-missing", mutate_missing_erc, "ERC sheets 구조 불일치"),
]


def run_case(name: str, mutation=None, expected_fragment: str | None = None,
             registry: Path = REGISTRY, registry_sha: str = REGISTRY_SHA,
             expected_pass: bool = False) -> dict:
    case = OUT / name
    copy_inputs(case)
    before = {key: sha(case / value) for key, value in INPUT_NAMES.items()}
    description = "unmodified actual export copy"
    if mutation is not None:
        description = mutation(case)
    refresh_runtime(case)
    after = {key: sha(case / value) for key, value in INPUT_NAMES.items()}
    report = case / "report.json"
    argv = [
        sys.executable, str(VERIFIER),
        "--project-root", str(PROJECT),
        "--registry", str(registry),
        "--registry-sha256", registry_sha,
        "--contract", str(case / "runtime.json"),
        "--netlist", str(case / "netlist.xml"),
        "--layout", str(case / "layout.json"),
        "--erc", str(case / "erc.json"),
        "--pdf", str(case / "schematic.pdf"),
        "--report", str(report),
        "--pdf-text-tool", "/usr/bin/pdftotext",
    ]
    completed = subprocess.run(argv, cwd=ART, text=True, capture_output=True)
    (case / "stdout.txt").write_text(completed.stdout, encoding="utf-8")
    (case / "stderr.txt").write_text(completed.stderr, encoding="utf-8")
    payload = load(report) if report.is_file() else {}
    errors = payload.get("errors", [])
    hash_only = any("runtime-CLI 입력 SHA 불일치" in item for item in errors)
    causal = expected_fragment is None or any(expected_fragment in item for item in errors)
    passed = completed.returncode == 0 and payload.get("status") == "PASS"
    if expected_pass:
        assertion = passed
    else:
        assertion = completed.returncode != 0 and payload.get("status") == "FAIL" and causal and not hash_only
    result = {
        "case": name,
        "description": description,
        "argv": argv,
        "rc": completed.returncode,
        "status": payload.get("status", "NO_REPORT"),
        "expected": "PASS" if expected_pass else "FAIL",
        "expected_error_fragment": expected_fragment if expected_fragment is not None else "not_applicable",
        "first_error": errors[0] if errors else "",
        "causal_assertion_matched": causal,
        "rejected_only_by_input_hash": hash_only,
        "assertion_passed": assertion,
        "input_sha256_before_mutation": before,
        "input_sha256_after_mutation_and_runtime_reseal": after,
        "runtime_sha256": sha(case / "runtime.json"),
        "report_sha256": sha(report) if report.is_file() else "missing",
        "registry": str(registry),
        "registry_expected_sha256": registry_sha,
    }
    dump(case / "result.json", result)
    return result


def main() -> int:
    if OUT.exists():
        raise SystemExit(f"기존 결과 덮어쓰기 거부: {OUT}")
    OUT.mkdir(parents=True, exist_ok=False)
    original_sources = source_hashes()
    original_inputs = {key: sha(SOURCE / value) for key, value in INPUT_NAMES.items()}
    baseline = {
        "project_root": str(PROJECT),
        "frozen_skill": str(SKILL),
        "frozen_package_identity": "b274e7d851c129bb62402d1d71f18b43a772d29326ba612ce4cd2954233f4fbf",
        "registry_sha256": REGISTRY_SHA,
        "semantic_sha256": sha(PROJECT / "contracts/c1-rc-filter.semantic.json"),
        "source_files_before": original_sources,
        "native_inputs": original_inputs,
        "source_runtime_sha256": sha(SOURCE / "runtime.json"),
        "source_static_report_sha256": sha(SOURCE / "static-report.json"),
        "scope": "actual saved native export copies only; no CAD/MCP/GUI mutation",
    }
    dump(ART / "source-baseline.json", baseline)
    results = [run_case("00-control", expected_pass=True)]
    for name, mutation, fragment in MUTATIONS:
        results.append(run_case(name, mutation, fragment))

    # caller가 expected registry SHA도 사본 bytes에 맞춘 검증 전용 oracle mutation이다.
    bool_case = OUT / "13-registry-schema-bool"
    copy_inputs(bool_case)
    registry_copy = copy.deepcopy(load(REGISTRY))
    registry_copy["schema_version"] = True
    bool_registry = bool_case / "registry-schema-bool.json"
    dump(bool_registry, registry_copy)
    # run_case의 새 경로 생성 동작과 충돌하지 않도록 사전 생성 사본을 별도 helper로 실행한다.
    # 위에서 만든 디렉터리를 지우거나 덮지 않고, 공통 실행을 이 case에 직접 적용한다.
    refresh_runtime(bool_case)
    before = {key: sha(bool_case / value) for key, value in INPUT_NAMES.items()}
    report = bool_case / "report.json"
    bool_sha = sha(bool_registry)
    argv = [sys.executable, str(VERIFIER), "--project-root", str(PROJECT),
            "--registry", str(bool_registry), "--registry-sha256", bool_sha,
            "--contract", str(bool_case / "runtime.json"),
            "--netlist", str(bool_case / "netlist.xml"),
            "--layout", str(bool_case / "layout.json"),
            "--erc", str(bool_case / "erc.json"), "--pdf", str(bool_case / "schematic.pdf"),
            "--report", str(report), "--pdf-text-tool", "/usr/bin/pdftotext"]
    completed = subprocess.run(argv, cwd=ART, text=True, capture_output=True)
    (bool_case / "stdout.txt").write_text(completed.stdout, encoding="utf-8")
    (bool_case / "stderr.txt").write_text(completed.stderr, encoding="utf-8")
    payload = load(report) if report.is_file() else {}
    bool_result = {
        "case": "13-registry-schema-bool", "description": "registry schema_version 1 -> true in copy; caller expected SHA updated to copy",
        "argv": argv, "rc": completed.returncode, "status": payload.get("status", "NO_REPORT"),
        "expected": "FAIL_STRICT_TYPE", "actual_survivor": completed.returncode == 0 and payload.get("status") == "PASS",
        "assertion_passed": completed.returncode != 0 and payload.get("status") == "FAIL",
        "defect_only_no_source_fix_authorized": True,
        "input_sha256": before, "registry_copy_sha256": bool_sha,
        "original_registry_sha256": REGISTRY_SHA,
        "first_error": (payload.get("errors") or [""])[0],
        "report_sha256": sha(report) if report.is_file() else "missing",
    }
    dump(bool_case / "result.json", bool_result)
    results.append(bool_result)

    results.append(run_case("99-green2", expected_pass=True))
    after_sources = source_hashes()
    source_unchanged = original_sources == after_sources
    summary = {
        "schema_version": 1,
        "status": "PASS" if all(item["assertion_passed"] for item in results if item["case"] != "13-registry-schema-bool") and source_unchanged else "FAIL",
        "results": results,
        "counts": {
            "control_pass": sum(item["case"] in {"00-control", "99-green2"} and item["assertion_passed"] for item in results),
            "causal_mutations_rejected": sum(item["case"].startswith(tuple(f"{i:02d}" for i in range(1,13))) and item["assertion_passed"] for item in results),
            "schema_bool_survivors": int(bool_result["actual_survivor"]),
        },
        "source_files_before": original_sources,
        "source_files_after": after_sources,
        "source_files_unchanged": source_unchanged,
        "boundaries": {
            "actual_native_inputs": str(SOURCE),
            "mutations": "copies under owned evidence directory",
            "cad_mcp_gui_writes": 0,
            "producer_identity": "copied from actual runtime; not synthesized",
            "registry_bool": "oracle mutation copy with caller-pinned copy SHA; original registry unchanged",
        },
    }
    dump(ART / "results.json", summary)
    dump(OUT / "suite-summary.json", summary)
    if summary["status"] != "PASS":
        return 1
    if not bool_result["actual_survivor"]:
        # 엄밀 타입 거부가 이미 구현된 경우도 suite 자체는 성공이다.
        return 0
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
