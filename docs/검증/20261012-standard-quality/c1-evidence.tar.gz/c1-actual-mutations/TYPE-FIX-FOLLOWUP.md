# registry schema type survivor 후속

실제 frozen package `b274e7...`에서 보존한 `registry.schema_version=true` 사본은 rc0/PASS survivor다. 이 과거 증거와 원 C1 package/runtime은 수정하지 않았다.

현재 표준 source는 schema version을 `type(value) is int`와 exact 값으로 검사하고, companion 원 rc와 collector MCP logical rc도 boolean `false`를 정수 0으로 받지 않는다. runtime producer package identity는 `package_identity.strict_equal`로 JSON 타입까지 exact 비교한다.

- 실제 survivor: `project/evidence/c1-actual-mutations/run-02/13-registry-schema-bool/`
- 단위 RED: `verify-dev/red-json-types.txt`
- 정상 GREEN: `verify-dev/green-json-types.txt`
- 검사 완화 mutation: `verify-dev/mutation-json-types.txt`
- GREEN2: `verify-dev/green2-json-types-run2.txt` — 43/43 통과

현재 source 수정 성공을 frozen actual native 성공으로 소급하지 않는다. 새 package identity와 current runtime/native leaf 재수집은 root 후속 범위다.
