# 원 upstream 실패의 읽기 전용 포트 경합 진단

## 결론

**fixture의 실제 source 경합 취약성 확인, 역사적 실패의 실제 점유자는 미확인.** 공유 Unix 소켓 충돌이 아니다. 원 fixture는 loopback TCP ephemeral port를 선정한 후 보유 listener를 닫고 NNG로 같은 포트에 재bind한다. 이 예약 공백에 자기 소유 모의 listener만 삽입한 두 번 모두 원 named test의 원행1321에서 `mock listen: AddressInUse`와 원 cargo rc101이 재현됐다. 주입을 제거한 대조는 통과한다. 이로써 실제 원 test의 포트 TOCTOU 취약성을 검증했지만, 원 전체 make 실패 당시 어떤 프로세스가 점유했는지는 원로그에 포트/PID가 없어 확정할 수 없다.

현재 source 수정, 원 WIP 수정, commit, 새 의존성, release binary 교체, 실 GUI/실장비/라이브 MCP 접촉, 타세션 socket 삭제는 모두0. 원 전체 make 실패를 이번 좁은 통과로 무효화하지 않는다.

## 요구와 경계

- 명시 요구: 원 실패 named test의 최대20회 빠른 loop와 소켓 소유자 읽기 전용 대조.
- 사용한 가정: 소스가 같은 원 실패와 같은 binding seam의 재현은 fixture 경합 가능성의 검증이지만 과거 충돌자의 증명이 아니다.
- 확인된 사실: upstream HEAD `94f80350cf67db27b179a06a8f6dbebfe4717927`, 전후 status 깨끗함.
- 남은 unknown: 원 실패 port, 역사적 owner/PID, 내부 suite와 외부 프로세스 중 누가 공백을 이용했는지.
- 출력 예외: 한정된 작업 소유권을 우선하여 보고서를 docs/보고서 대신 승인된 artifact 하위에만 기록했다.

## 원 실패와 재현

| 범위 | 실제 결과 | 원 rc | 비고 |
|---|---|---:|---|
| 원 root-full-test-type-fixed.txt | Rust core 1770 통과 /1 실패 /23 무시 | make2 / cargo101 | 원 실패 보존 |
| 이전 root-full-test.txt | Rust2513 통과 /0 실패 /50 무시, Python168 통과 | 부모 관측 통과 | 이번 gate의 대체 증거 아님 |
| 계측 없는 exact test | 10/10 통과 | 각각0 | 최초 cache 빌드10.94초, actual test0.01초 |
| 주입 없는 계측 observation/control | 2/2 통과 | 각각0 | port close 후 NNG bind 성공 |
| 자기 모의 경합 collision/collision-repeat | 2/2 원 실패 재현 | 각각101 | 원 assertion 도달 전에 원 fixture bind 실패 |
| 총 named test 실행 | 14회 | 혼합 | 최대20회 이하 |

## 우선순위 가설과 판정

| 순위 | 가설 | 예측 | 관측/판정 |
|---:|---|---|---|
|1|선정→drop→재bind의 포트 예약 공백|공백에서 다른 listener가 잡으면 같은 원행 실패|자기 모의 listener로2/2 확인. 역사적 다른 listener 정체는 미확인|
|2|외부 cargo/test 환경 경합|동시 TCP listener owner가 확인되면 외부 원인 연결 가능|최초 cargo/core test0. 후행 타프로젝트 cargo1, 해당 cargo TCP FD0. 과거 연결 근거 없음|
|3|TIME_WAIT/NNG 재bind 정책|살아있는 listener 없이 잔존 TCP상태에서 실패|현재 자연 실패0, 입증 안 됨. 전체 TIME_WAIT snapshot 보존|

## 실제 binding 순서

```text
TCP_PROBE(127.0.0.1:0) -> PORT=P -> DROP(fd=A)
                                  |
                                  +-> MOCK_COLLIDER(P,fd=B,inode=J)
                                  |
                                  +-> NNG_BIND(P,fd=C) -> errno=98
                                                       -> AddressInUse
```

`crates/konnect-core/src/tools/project.rs:1309~1347`에만 해당한다. test_ctx의 CLI/binary/IPC 값은 처음엔 빈 문자열이다. named test가 모의 TCP주소로 덮어쓰고 handle_open_project({})를 호출한다. handler(project.rs:303~379)는 이 주소에 IPC ping을 보낼 뿐 GUI를 실행하지 않는다. AS_NOT_READY 모의 응답과 기존 response assertion은 변경하지 않았다.

| 계측 | PID | 포트 | 선정 fd/inode | 자기 경합 fd/inode | NNG fd/원 bind 결과 |
|---|---:|---:|---|---|---|
|observation|3785596|39535|9/3551674092|없음|11/0|
|collision|3786035|46175|9/3551682497|9/3551682499|12/-1,errno98|
|collision-repeat|3786489|37405|9/3551688539|9/3551688541|12/-1,errno98|
|control|3786891|46349|9/3551738815|없음|11/0|

fd9의 재사용을 동일 소켓으로 오해하지 않는다. 선정 socket과 자기경합 socket의 inode는 서로 다르다.

## 프로세스·소켓 읽기 전용 대조

- 최초 pgrep -x cargo/core test0. socket-process-before.txt는 TCP LISTEN/TIME_WAIT 전체 관측과 실제 KiCad Unix 소켓 별도 관측을 보존한다.
- 후행2026-10-12 05:48:55 KST: cargo PID3681538, cwd `/home/hanol/hp-nutrient-wt/r54-bv`. argv는 다른 프로젝트의 edge-control-bff exact restore-guard test. 해당 cargo FD는 unnamed Unix socket4개만 있었고 TCP 소켓 없음(other-cargo-fds.txt). 자식/다른 프로세스까지 무경합을 전면 증명하는 것은 아니다.
- 실제 `/tmp/kicad/api.sock`는 eeschema PID2632729 소유로 관측됐지만 모의 TCP fixture와 다른 endpoint다. 접속/종료/삭제하지 않았다.
- 계측한 네 모의 TCP listener는 후행 LISTEN 잔존0. 임시 모의 소켓은 자기 test 프로세스 종료로 OS가 해제했다. socket파일 삭제0, 타 fixture cleanup 변경0, fixture timeout 및 assertion 완화0.

## 재현 명령

계측 없는 원 명령(작업 위치 upstream/konnect):

```bash
cargo test --offline --locked -p konnect-core --lib tools::project::tests::open_project_says_kicad_answered_when_it_answered_with_an_error -- --exact --nocapture
```

임시 harness는 기존 시스템 cc/libc/libdl만 사용하며 test executable basename `konnect_core-`만 대상으로 한다. bind/close seam을 관측하고, collision 모드일 때만 선정 listener close 직후 자기 소유 loopback listener를 보유한다. Cargo.lock 변경·새 다운로드 없다. 인위적 주입은 실제 자연 재현율과 분리한다.

```bash
OUT=/home/hanol/kicad-konnect-mcp-workspace/.artifacts/20261012-040121-standard-quality/upstream-flake-probe
cc -shared -fPIC -Wall -Wextra -Werror -o "$OUT/port_gap_probe.so" "$OUT/port_gap_probe.c" -ldl
bash "$OUT/reproduce.sh" collision
# 원 cargo rc101, 같은 mock listen: AddressInUse 예상
bash "$OUT/reproduce.sh" control
# 원 cargo rc0 예상
```

## 수정 제안만

동일 source의 `crates/konnect-core/src/test_support.rs:9~32`에는 이미 MockIpcServer guard가 있다. PID+AtomicU64의 고유 inproc:// endpoint를 보유하고 Drop에서 socket close 및 worker join한다. project fixture도 기존 guard를 재사용하면 포트 선정/반납/재bind와 detached worker를 제거할 수 있다. AS_NOT_READY 응답, 원 response assertion, 공개 계약, timeout은 그대로 유지하는 방향을 제안한다. **이 작업에서는 source 수정 및 수정 검증하지 않았다.** 전체 make 재검증은 부모 작업이며 좁은 PASS로 전체 gate를 대신하지 않는다.

## 무변경 식별값

전후 동일:

- project.rs SHA256: f5403b00413d5b4dbfd7e2bb5470f9ebabb03fcf274fafd4d3ab8a70634d28bd
- Cargo.lock SHA256: 7696cce09720a38b0021b6598e2cd3cad5dcedda9bba347f9eb3a0e699f00b7e
- release/konnect SHA256: cbb5b9785d376ab55a57bbf5723f8e1d79805c5eeeca8d5b1d58b84f7c3d909a

재현 원로그: repeat-1.txt~repeat-10.txt, observation.txt, collision.txt, collision-repeat.txt, control.txt. 원 rc대장 repeat-rc.tsv/probe-rc.tsv. 상태 socket-process-before.txt/socket-process-after.txt/other-cargo-fds.txt. 임시 harness port_gap_probe.c/.so/reproduce.sh/repeat.sh. 재현만 종료했으며 instrumentation을 원 source에 삽입한 적이 없다. LD_PRELOAD와 PORT_GAP_COLLIDE는 각 명령에만 설정되어 현재 환경에 export되지 않는다.
