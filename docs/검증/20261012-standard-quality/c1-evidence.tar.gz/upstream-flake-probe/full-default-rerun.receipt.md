# 정규 기본 전체 재실행 판정

정규 기본 `PYTHONDONTWRITEBYTECODE=1 make test`를 source 무수정 상태에서 정확히1회 재실행했고 원 make rc0으로 전체 gate를 통과했다. 기존 원FAIL 및 포트 예약 공백 진단은 모두 보존한다. **원 fixture 취약성을 수정한 것이 아니며 이번 자연 실행에서는 발생하지 않은 것이다.**

| 범위 | 결과 | 원 rc |
|---|---|---:|
| make test | 통과 |0|
| Rust workspace/doc/별도 viewer 합계 |2513 통과 /0 실패 /50 무시, 결과행45개|성공|
| Python root |175 통과 /0 실패,9.167초|성공|
| 원 실패 namedtest |open_project_says_kicad_answered_when_it_answered_with_an_error 이번ok|성공|
| root source96파일 aggregate identity 전후 |동일|해당없음|
| package17파일 aggregate identity 전후 |동일|해당없음|
| upstream HEAD/dirty 전후 |94f80350cf67db27b179a06a8f6dbebfe4717927 /빈값|해당없음|
| release/konnect SHA256 전후 |cbb5b9785d376ab55a57bbf5723f8e1d79805c5eeeca8d5b1d58b84f7c3d909a /동일|해당없음|

계측 없음, LD_PRELOAD 없음, Cargo 기본 병렬 설정 유지. 직렬화, timeout 변경, assertion 완화, 원source수정, 소켓파일삭제, 다른프로세스종료 모두0. Cargo.lock과 upstream 소스 무변경.

시작2026-10-12 05:58:20 KST, 종료05:58:48 KST.

이 root source identity와 package identity는 capture_identity.py의 git tracked+untracked source 목록 및 content SHA의 aggregate이다. 제품의 별도 정식 package SHA를 대신하는 정의가 아니며, before/after.json 원records로 재계산 가능하다.

원 전체 실패와 이번 기본 재실행은 target/debug/deps/konnect_core-8565397bbcce44c7 경로다. 앞선 좁은 -p konnect-core --lib 반복은 feature-unification 범위가 다른 konnect_core-31163e1ef155a45d를 사용했다. 따라서 앞선 결정적 경합 주입은 같은 원source fixture binding seam의 입증이고 동일 full-suite executable의 주입 재현이라고 주장하지 않는다. 이번 재실행은 원 정규 기본 gate 자체의 통과 증거다.

재현 명령(레포 root):

```bash
PYTHONDONTWRITEBYTECODE=1 make test
```

신규 원로그: full-default-rerun.stdout.txt / full-default-rerun.stderr.txt / full-default-rerun.rawrc.txt / full-default-rerun.command.txt. 전후 상태: full-default-rerun.before.json·txt / full-default-rerun.after.json·txt. 원FAIL root-full-test-type-fixed.txt와 기존 진단로그·SHA256SUMS.txt는 덮어쓰지 않았다.

전후 root source identity: `a742340a9be938ba7634588791672b01ceee1c5e2a88f91d39f244637f60183a`

전후 package identity: `7763957ac0a865972c6aca74637d50c8f2562a2a03b13c80cf91b4620397751d`
