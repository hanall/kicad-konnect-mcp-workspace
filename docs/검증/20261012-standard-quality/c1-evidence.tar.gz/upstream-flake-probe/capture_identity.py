from pathlib import Path
import hashlib,subprocess,json
root=Path('/home/hanol/kicad-konnect-mcp-workspace')
paths=subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'],cwd=root).decode().split('\0')
records=[]
for name in sorted(set(paths)):
    if not name: continue
    p=root/name
    if p.is_symlink(): value='symlink:'+p.readlink().as_posix()
    elif p.is_file(): value=hashlib.sha256(p.read_bytes()).hexdigest()
    else: continue
    records.append((name,value))
data=''.join(name+'\t'+value+'\n' for name,value in records)
package=[record for record in records if record[0].startswith('skills/kicad-schematic-quality/')]
print(json.dumps({'root_source_identity':hashlib.sha256(data.encode()).hexdigest(),'root_source_files':len(records),'package_identity':hashlib.sha256(json.dumps(package,ensure_ascii=False).encode()).hexdigest(),'package_files':len(package),'root_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip(),'upstream_head':subprocess.check_output(['git','-C','upstream/konnect','rev-parse','HEAD'],cwd=root).decode().strip(),'upstream_dirty':subprocess.check_output(['git','-C','upstream/konnect','status','--porcelain'],cwd=root).decode(),'records':records},ensure_ascii=False,indent=2))
