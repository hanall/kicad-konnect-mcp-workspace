# rc-filter root 페이지 사전 계획 (rc-filter.kicad_sch)

> 판본 v1. 제안본 `plans/root.proposed.md`(SHA 282a9fbe…)를 실제 좌표·배치·검증 순서로 승격했다. 좌표 단위 mm, KiCad 회로도 좌표(Y 아래 방향).

## 1. 식별·범위·근거

| 항목 | 내용 |
|---|---|
| 계획 판본·상태 | v1, 첫 CAD 쓰기 전 확정 |
| 파일·제목 | `rc-filter.kicad_sch`, 제목 `rc-filter`, A4 landscape 1쪽 |
| 모드 | `design` |
| 독자·목적 | Root 재검증자가 J1→R1→C1→J2 RC 저역통과 구조를 도움 없이 따라 읽음 |
| 대상 SHA | CAD 미존재. semantic 39d1677c…, registry c1669c3b… |
| 원문 SHA 집합 | requirements 211aa892…, symbol-endpoints 19a4cc4b…, unit-source a4fe2ed7…, native-assumptions e64c5a9e… (전체 값은 공통 계획 2절) |
| 공통 계획 | `plans/common.md` (SHA는 seal 파일) |
| 쓰기 allowlist | `.kicad_pro`, `.kicad_sch`, `.kicad_pcb`(create_project 기본 생성만), `sym-lib-table` |
| 작성자·채널·lock | 단일 작성자 Claude, guarded_mcp.py, GUI 미사용, lock 없음 |
| 해당 CAD 첫 쓰기 시각 | 미착수 (seal 이후 실제 시각을 AUTHOR-RESULT에 기록) |

## 2. 실제 pin·부품 소유

| ref·unit | symbol | 배치 (x, y, rot, mirror) | pin | type | net | 예상 배치 endpoint | 근거 |
|---|---|---|---:|---|---|---|---|
| J1 u1 | Connector_Generic:Conn_01x02, value VIN, fp "" | (73.66, 88.90, 0, mirror `y`) | 1 | passive | VIN | (78.74, 88.90) | local (-5.08,0) + mirror y |
| J1 u1 | 〃 | 〃 | 2 | passive | GND | (78.74, 91.44) | local (-5.08,-2.54) |
| R1 u1 | Device:R, value 1k, fp "" | (114.30, 88.90, 90) | 1 | passive | VIN | (110.49, 88.90) | local (0,3.81), 90° CCW |
| R1 u1 | 〃 | 〃 | 2 | passive | VOUT | (118.11, 88.90) | local (0,-3.81) |
| C1 u1 | Device:C, value 100n, fp "" | (139.70, 99.06, 0) | 1 | passive | VOUT | (139.70, 95.25) | local (0,3.81) |
| C1 u1 | 〃 | 〃 | 2 | passive | GND | (139.70, 102.87) | local (0,-3.81) |
| J2 u1 | Connector_Generic:Conn_01x02, value VOUT, fp "" | (172.72, 88.90, 0) | 1 | passive | VOUT | (167.64, 88.90) | local (-5.08,0) |
| J2 u1 | 〃 | 〃 | 2 | passive | GND | (167.64, 91.44) | local (-5.08,-2.54) |

예상 endpoint는 계획값일 뿐이다. 배치 직후 `batch_get_schematic_pin_locations` readback이 정본이며, 다르면 배선 전에 멈춘다. 특히 R1 pin1이 오른쪽이면(U1) VIN/VOUT가 뒤바뀌므로 배선하지 않고 계획 개정(회전 270) 후 진행한다. 각 ref는 unit 1만 소유하며 모든 물리 pin(2개)이 정확히 한 번 소유된다.

## 3. 읽는 순서와 기능 구역

- 시작점: 왼쪽 J1(VIN 입력 커넥터). 종점: 오른쪽 J2(VOUT 출력 커넥터).
- 주요 단계: J1.1 → VIN 실선 → R1(수평 직렬) → VOUT 노드 → C1(아래로 shunt) / J2.1.
- 주 흐름: 좌→우 (입력→출력이 자연스러운 2-port 필터). feedback 없음. 앞뒤 페이지 없음.

| 기능 구역 | 좌표 범위 | 포함 | 읽는 방향 | 문자 정책 |
|---|---|---|---|---|
| 제목 | (73.66, 71.12) 텍스트 `rc-filter` 2.54 mm bold | 텍스트 | — | 회로 위 17 mm 여백 |
| 입력 | x 66–86 | J1 | 좌→우 | 필드는 심볼 기본 위치, 배선과 겹치면 readback 후 보고 |
| 직렬 | x 110–119, y 88.90 | R1 | 좌→우 | |
| shunt | x 139.70, y 95–103 | C1 | 위→아래 | |
| 출력 | x 160–180 | J2 | 좌→우 | |
| 반환 레일 | y 109.22, x 83.82–160.02 | GND 실선 | 좌→우 | |

모든 요소는 PDF 텍스트 경계 [10,10,287,200] mm 안이며, 우하단 title block(대략 x>177, y>175)과 겹치지 않는다.

## 4. 반드시 실선으로 닫을 로컬 망

| net | pin 묶음 | 실선 경로 (x1,y1)-(x2,y2) | 분기·junction | 금지 shortcut | 검사 |
|---|---|---|---|---|---|
| VIN | J1.1, R1.1 | W1 (78.74,88.90)-(110.49,88.90) | 없음 | label-only 연결 | wire root 1개 |
| VOUT | R1.2, C1.1, J2.1 | W2 (118.11,88.90)-(139.70,88.90); W3 (139.70,88.90)-(167.64,88.90); W4 (139.70,88.90)-(139.70,95.25) | T 접점 (139.70,88.90) junction | label-only 연결 | wire root 1개 |
| GND | J1.2, C1.2, J2.2 | W5 (78.74,91.44)-(83.82,91.44); W6 (83.82,91.44)-(83.82,109.22); W7 (83.82,109.22)-(139.70,109.22); W8 (139.70,102.87)-(139.70,109.22); W9 (139.70,109.22)-(160.02,109.22); W10 (160.02,109.22)-(160.02,91.44); W11 (160.02,91.44)-(167.64,91.44) | T 접점 (139.70,109.22) junction | power symbol, PWR_FLAG | wire root 1개 |

교차 검토: VIN W1(y 88.90)과 GND W6(x 83.82, y 91.44↓)은 닿지 않는다. VOUT W3(y 88.90)과 GND W10(x 160.02, y 91.44↓)도 닿지 않는다. mid-mid 교차 0, 사선 0. T 접점 junction이 자동 생성되지 않으면(U3) `batch_add_junction`으로 해당 두 점에만 추가한다.

이름 label(local `net_label`, rot 0, 실선 위 anchor): VIN (93.98, 88.90) on W1, VOUT (152.40, 88.90) on W3, GND (111.76, 109.22) on W7. label은 이름 부여 보조이며 빠진 실선을 대신하지 않는다.

## 5. 공급·반환·절연 계약

| node | source | 소비 | 영역 | power 반환 | signal 반환 | 합치면 안 되는 기준점 |
|---|---|---|---|---|---|---|
| VIN | J1.1 (외부 입력) | R1.1 | 단일 비절연 | GND via J1.2 | GND | 해당 없음 |
| VOUT | R1.2 | C1.1, J2.1 | 동일 | GND via C1.2/J2.2 | GND | 해당 없음 |

GND 반환은 J1.2–C1.2–J2.2를 잇는 실선 레일 하나다. 전원 symbol, `PWR_FLAG`, no-connect, pin type 변경은 하지 않는다. GND 이름을 PE·chassis로 확대하지 않는다.

## 6. 페이지 포트 계약

| port·net | 이 페이지 ref.pin | 방향 | 영역 | 상대 페이지 | 확인 |
|---|---|---|---|---|---|
| (없음) | — | — | — | — | layout label 중 GlobalLabel 0 확인 |

외부 경계는 J1/J2 커넥터 pin으로만 표현한다. hierarchical/global 포트 0.

## 7. 보존·승인 변경·예외

- 보존 집합: 신규 설계이므로 semantic 계약 전체가 기대 집합(부품 4, pin 8, net 3, footprint 빈 값).
- 승인 변경: 없음.
- 허용 예외: 없음. wire_coverage exceptions 0, duplicate pin 예외 0, ERC warning/exclusion allowlist 0.
- 제목: 현재 runtime에 회로도 title_block 편집 도구가 없으면(U4) 페이지 텍스트 `rc-filter`로 제목을 표시하고 title_block Title 필드는 미설정 unknown으로 보고한다. 파일 직접 편집으로 채우지 않는다.

## 8. 도구와 검증 계획 (작성 순서)

각 단계는 새 요청 JSONL과 새 evidence 디렉터리를 쓰는 별도 guarded 세션이며, mutation 1종 뒤에 같은 세션 readback 조회를 둔다. partial/error/timeout이면 즉시 재시도하지 않고 파일 SHA와 대상 readback으로 적용 여부를 판정한다.

| 단계 | mutation | readback |
|---|---|---|
| S0 (쓰기 전) | 없음: `list_toolboxes`, `get_symbol_info` ×3(각 별도 세션, INCOMPLETE 예상) | runtime identity, tools/list |
| S1 | `create_project` path=project, name=rc-filter | `list_schematic_components`, `get_schematic_layout` |
| S2/S3 | `register_symbol_library` Device / Connector_Generic, scope project | 응답 state, sym-lib-table SHA |
| S4 | `batch_place_components` J1, R1 (value·footprint `""` 명시, unit 1) | `batch_get_schematic_pin_locations` [J1,R1] |
| S5 | `batch_place_components` C1, J2 | pin readback [C1,J2] |
| S6 | `batch_add_wire` VIN W1 | `list_schematic_wires` |
| S7 | `batch_add_wire` VOUT W2–W4 | wires·layout junction |
| S8 | `batch_add_wire` GND W5–W11 | wires·layout junction |
| S9 | 필요 시 `batch_add_junction` | layout junction |
| S10 | `add_schematic_net_label` ×3 | `list_schematic_labels`, `list_schematic_nets` |
| S11 | `add_schematic_text` 제목 | layout |
| S12 | 없음: 전수 조회(부품·pin·wire·label·net·orphan·short·overlap) | — |
| S13 | `collect_evidence.py` 새 디렉터리 | native XML/PDF/ERC, standard verifier |

검증 관문: G1 pin·전기(XML 부품·값·footprint·pin type·net 전수), G2 실선(3 net 단일 root, cross-net 0, orphan 0, short 0), G3 저장·ERC(native ERC severity-all 원 rc·ignored_checks 보존; GUI 저장·재열기는 미실행으로 보고), G4 시각(native PDF를 pdftoppm으로 렌더해 작성자 자체 판독만, 독립 검토 아님), G5 증거(SHA·argv·rc·package identity).

## 9. unknown과 차단 조건

| 내용 | 근거 | 사용자 결정 | 틀릴 때 영향 | 상태 |
|---|---|---|---|---|
| U1 R 90° pin 방향 | 배치 readback | 아니오 | VIN/VOUT 역전 | 미확인 |
| U2 Conn mirror y 방향 | 배치 readback | 아니오 | J1 pin이 왼쪽을 향함 | 미확인 |
| U3 T 접점 자동 junction | layout readback | 아니오 | 분기 미연결 | 미확인 |
| U4 title_block 도구 | tools/list | 아니오 | 제목 표시 방식 | 미확인 |
| U5 native ERC policy | native ERC | Root | verifier FAIL | 미확인 |
| get_symbol_info unit 누락 | 조회 응답 | 아니오 | INCOMPLETE 유지 | 원문·readback으로 보완 |

차단: 근거 없는 pin, cross-net root, 계약 밖 부품, 설명 없는 ERC 경고, stale 증거.

## 10. 계획 변경과 다음 동작

| 시각 | 발견 | 영향 | 개정 | 범위 | 재검증 |
|---|---|---|---|---|---|
| 2026-10-12T04:49+09:00 | 정식본 v1 | 첫 쓰기 전 | seal | 전체 | — |
| 2026-10-12T04:52+09:00 | S0 읽기 세션: runtime 0.13.0+hanall.1/94f80350 일치, get_symbol_info R/C/Conn pin·type·local 좌표가 symbol-endpoints와 일치하나 unit 필드 없음(INCOMPLETE, rc=1 보존). 20개 toolset 중 회로도 title_block 편집 도구 없음(U4 확정) | 제목은 7절대로 텍스트 표시, title_block Title 미설정 unknown | 첫 쓰기 전 seal | 전체 | 배치 readback에서 unit 확인 |

- 마지막 정상 saved CAD SHA: 없음(미생성). live editor·lock: 없음.
- 다음 안전한 동작: S0 읽기 세션 → seal 기록 → S1.
