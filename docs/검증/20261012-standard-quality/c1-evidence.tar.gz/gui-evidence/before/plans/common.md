# rc-filter 공통 사전 계획 (C1 격리 작성)

> 판본 v1. 상태: 첫 CAD 쓰기 전 확정 대상. 제안본 `plans/common.proposed.md`(SHA c6dce3a5…)를 현재 환경·배치·검증 순서로 승격한 정식본이다. 제안본은 수정하지 않고 보존한다.

## 1. 권위·범위·모드

| 항목 | 내용 |
|---|---|
| 프로젝트·판본 | `rc-filter`, Root가 정한 합성 RC 학습 예제(제품 설계 아님) |
| 모드 | `design` (신규 설계, 기존 CAD 없음) |
| 요청·독자·납품 형태 | TASK.md C1: 1쪽 A4 landscape 회로도 + native 정적 검증 증거. 독자는 Root 재검증자 |
| 프로젝트 지침·승인 출처 | case `AGENTS.md`(=CLAUDE.md), `TASK.md`, `project/registry.json`, `project/sources/*` |
| 대상 | `rc-filter.kicad_sch`(유일한 회로도·root), create_project 기본 산출물 `.kicad_pro`/`.kicad_pcb`, project-scope `sym-lib-table` |
| 비대상 | PCB 편집(기본 empty PCB 생성 외 금지), footprint 할당, 제조, 통전, GUI 저장·재열기, 독립 전페이지 검토, registry/semantic 수정 |
| workspace root | `/home/hanol/kicad-konnect-mcp-workspace/.artifacts/20261012-040121-standard-quality/isolation/case` |
| project dir | `…/isolation/case/project` |
| 루트 회로도·허용 파일 | `rc-filter.kicad_sch`; allowlist exact = `rc-filter.kicad_pro`, `rc-filter.kicad_sch`, `rc-filter.kicad_pcb`, `sym-lib-table` |
| 단일 CAD 작성자·검토자 | 작성자: 이 세션의 Claude 에이전트 단독. 검토자·재검증: Root |
| 승인된 채널 | 패키지 `scripts/guarded_mcp.py` 경유 Konnect STDIO MCP만. GUI 미사용(열지 않음) |
| saved/live·lock | CAD 미존재. KiCad 프로세스 없음, `KICAD_API_SOCKET=ipc:///tmp/no-shared-kicad.sock`(socket 부재) → live editor 없음. `*.lck` 없음 |

## 2. 요구·원문·profile

| 요구 ID | 기능·수치 | 원문 | 원 bytes SHA-256 | 상태 | 검토자 |
|---|---|---|---|---|---|
| R-PART | J1 VIN/J2 VOUT `Connector_Generic:Conn_01x02`, R1 `1k` `Device:R`, C1 `100n` `Device:C`, 모두 unit 1·pin 1/2 passive·footprint `""` | `sources/requirements.md` | 211aa89205b387f95da33bbe65e27b4131523285721fdb6a5a4a9165c6630eaf | 채택 | Root |
| R-NET | VIN={J1.1,R1.1}, VOUT={R1.2,C1.1,J2.1}, GND={J1.2,C1.2,J2.2}; 각 net 단일 solid-wire root | 동일 | 동일 | 채택 | Root |
| R-PAGE | 1쪽 A4 landscape 297×210, 제목 `rc-filter`, 전원 symbol·PWR_FLAG·global port 없음 | 동일 + TASK.md | 동일 | 채택 | Root |
| R-SEM | 기대 계약 | `contracts/c1-rc-filter.semantic.json` | 39d1677c2d18ace6b273adbb56d72178f6723cc38837ef76284fb5324cd77382 | 봉인(수정 금지) | Root |
| R-REG | registry | `registry.json` | c1669c3beba5f2e0b491f2d82ddcc6d7c248f63168f13390a186db40b72ebc25 | 봉인 | Root |
| R-PIN | 설치 symbol local endpoint | `sources/symbol-endpoints.json` | 19a4cc4b68cd72abd518a831178cd6af53a35f16b944e2b2ed72858395cd6172 | 채택 | Root |
| R-UNIT | 단일 unit 1, extends 없음 | `sources/unit-source-observation.json` | a4fe2ed7e7b02e520ef62243a3c3023db8f0cd01ba5d175e9ed72847e2cbd5e6 | 채택(조회 한계 보완) | Root |
| R-NATIVE | ERC 기대 0/0/0, ignored_checks 4종, A4 landscape | `sources/native-assumptions.json` | e64c5a9ec91669e8b7b8657b9c7b64a70a69514fa132a18d0e793fb87dc3b726 | 사전 기대(미관측) | Root |

- profile: `profiles/general.md` (패키지 b274e7d851c129bb62402d1d71f18b43a772d29326ba612ce4cd2954233f4fbf). semantic profile id `independent-c1-rc-filter-v1`.
- 용지·방향·page·grid·font: A4 landscape 1쪽, 연결점은 1.27 mm 격자, net label·field 기본 1.27 mm, 제목 텍스트 2.54 mm bold.
- 전압·절연 영역: 단일 비절연 영역. VIN/VOUT/GND는 이름일 뿐 전압·전류 정격, chassis/PE 의미 없음.
- 프로젝트별 수치: 값 `1k`, `100n`은 원문 그대로이며 동적 RC 응답은 범위 밖.
- 틀리면 결과가 달라지는 unknown: (U1) R 회전 90°의 실제 pin1 방향, (U2) Conn mirror `y`의 실제 pin 방향, (U3) wire T 접점의 자동 junction 여부, (U4) 회로도 title_block 설정 도구 부재 여부, (U5) native ERC ignored_checks 실제값. 모두 결정 주체는 실제 readback/native 출력이며 추정으로 닫지 않는다.

## 3. 전체 구조와 읽는 순서

| 순서 | 회로도 | 기능 시작·끝 | 소유 부품·unit | 입력·출력 포트 | 영역·반환 |
|---:|---|---|---|---|---|
| 1 | `rc-filter.kicad_sch` / 제목 `rc-filter` | J1(입력, 왼쪽) → R1(수평 직렬) → C1(아래 shunt) → J2(출력, 오른쪽) | J1/R1/C1/J2 각 unit 1 | 없음(커넥터 pin만 외부 경계) | GND 단일 반환 |

- 루트 전체 흐름: 좌→우 신호 흐름(VIN→VOUT), GND 반환선은 아래쪽 수평 레일.
- feedback 없음. 페이지 간 이동 없음(단일 페이지, hierarchy 없음).
- 로컬 실선 원칙: 세 net 모두 모든 pin을 실선으로 닫는다. local label은 net 이름 부여 보조로 실선 위에만 둔다.
- 장거리 label·port: 사용하지 않음. global label 0.
- 반복 channel 없음.

## 4. 보존·변경·전기 경계

| 집합 | 기준 | 근거 | 차단 조건 |
|---|---|---|---|
| ref/unit/물리 pin | J1,J2,R1,C1 × unit 1 × pin 1,2 = 8 pin | semantic `pin_units`·`pin_types` | 누락·중복·다른 unit |
| net·junction·port | VIN/VOUT/GND, T 접점 2곳(VOUT 분기, GND 분기) junction | semantic `nets`·`wire_coverage` | 단일 root 아님, cross-net root, port 존재 |
| value·footprint | 1k/100n/VIN/VOUT, footprint `""` | semantic `components` | 다른 값, footprint 비어 있지 않음 |
| supply·return | 전원 symbol·PWR_FLAG 0, GND는 실선 레일 | requirements | 전원/flag symbol 추가 |
| 승인 전기 변경 | 해당 없음(신규) | — | 계약 밖 부품·net |

설치 symbol 조회(`get_symbol_info`)는 unit 필드를 주지 않아 guard가 INCOMPLETE로 분류한다. 이 한계를 오류 0으로 숨기지 않고, unit은 `unit-source-observation.json`과 배치 후 `batch_get_schematic_pin_locations` readback으로만 닫는다.

## 5. 도구·계획·검증

| 항목 | 값 | 확인 방법 | 미지원 시 |
|---|---|---|---|
| launcher/config/server cwd | `/home/hanol/kicad-konnect-mcp-workspace/scripts/run-konnect.sh` / `…/config/konnect.toml` / `/home/hanol/kicad-konnect-mcp-workspace` | guarded `session-start.json` backend identity | 쓰기 중단 |
| 기대 version·commit | `0.13.0+hanall.1` / `94f80350cf67db27b179a06a8f6dbebfe4717927` | guarded `runtime-identity.json` | session 거부 |
| current tool schema | 각 세션 `runtime-tool-schemas.json`; sch_wiring은 쓰기 전용 toolset이라 동일 commit 소스로 사전 확인 후 첫 배선 세션 기록과 사후 대조 | evidence 비교 | 불일치 시 중단 |
| plan-index·계획 | `plan-index.json`, `plans/common.md`, `plans/root.md` | SHA를 첫 쓰기 전 `evidence/plan-seal-before-first-write.json`에 기록 | 쓰기 금지 |
| registry·semantic | 위 2절 SHA | `sha256sum` 재확인 | 검증 PASS 금지 |
| 새 evidence 경로 | `project/evidence/<시각>-<단계>/` (매 실행 새 디렉터리), 요청은 `project/requests/<시각>-<단계>.jsonl` (임시→fsync→rename→부모 fsync→readback) | 디렉터리 존재 시 guard 거부 | 새 경로 생성 |
| native XML/PDF/ERC | `collect_evidence.py` → `project/evidence/<시각>-native/` | 원 rc·log 보존 | 결과 FAIL은 보존 후 원인 분석 |

환경 편차(사전 기록): 격리 셸에 `/dev/fuse`가 없어 `/usr/local/bin/kicad-cli`(AppImage wrapper)가 FUSE 마운트에 실패한다. native 단계에서만 AppImage runtime 공식 옵션 `APPIMAGE_EXTRACT_AND_RUN=1`로 같은 서명 AppImage(SHA256SUMS 검증 성공)를 추출 실행한다. 또한 사용자 KiCad 설정을 읽지 않도록 native 단계의 `HOME`/`XDG_*`를 증거 옆 새 빈 디렉터리로 지정한다. 이 env는 argv에 드러나지 않으므로 별도 receipt에 기록한다.

첫 CAD 쓰기 전 확인: 루트 회로도 계획 존재·구체 본문·원문 SHA·계획 SHA 고정, `require_all_plans_before_write=true`, 설치 library는 `read_only_library_refs` exact mapping으로만 project scope 등록.

## 6. 계획 변경 원장

| 시각 | 발견 | 영향 | 새 계획 SHA | 재개 조건 | 재검증 |
|---|---|---|---|---|---|
| 2026-10-12T04:49+09:00 | 제안본 승격, 정식본 v1 작성 | 첫 쓰기 전 | seal 파일에 기록 | seal 기록 후 | — |
| 2026-10-12T04:52+09:00 | S0 evidence `evidence/20261012-045111-S0a-schema-symR`, `…-045153-S0b-symC`, `…-045155-S0c-symConn`: identity 일치, symbol unit 조회 INCOMPLETE, title_block 도구 부재 | 제목 텍스트 표시 방식 확정 | seal 파일에 기록 | seal 기록 후 | 배치 readback |

과거 SHA를 덮어쓰지 않고 append-only로 남긴다. 첫 쓰기 이후 변경은 새 판본으로만 추가한다.
