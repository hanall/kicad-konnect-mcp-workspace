from __future__ import annotations
import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
REPO=Path('/home/hanol/kicad-konnect-mcp-workspace')
D=REPO/'.artifacts/20261012-040121-standard-quality'
PROJECT=D/'isolation/case/project';SOURCE=PROJECT/'evidence/root-type-fixed'
OUT=PROJECT/'evidence/strict-type-independent/type-probes'
VERIFIER=REPO/'skills/kicad-schematic-quality/scripts/verify_quality.py'
REG=PROJECT/'registry.json';REGSHA='c1669c3beba5f2e0b491f2d82ddcc6d7c248f63168f13390a186db40b72ebc25'
NAMES={'netlist':'netlist.xml','layout':'layout.json','erc':'erc.json','pdf':'schematic.pdf'}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def dump(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
def copy(name):
 p=OUT/name;p.mkdir(parents=True,exist_ok=False)
 for f in [*NAMES.values(),'runtime.json']:shutil.copyfile(SOURCE/f,p/f)
 return p
def refresh(p):
 r=load(p/'runtime.json');r['candidate']['inputs_sha256']={k:sha(p/f) for k,f in NAMES.items()};dump(p/'runtime.json',r)
def run(name,mut,fragment):
 p=copy(name);mut(p);refresh(p);report=p/'report.json'
 argv=[sys.executable,'-B',str(VERIFIER),'--project-root',str(PROJECT),'--registry',str(REG),'--registry-sha256',REGSHA,'--contract',str(p/'runtime.json'),'--netlist',str(p/'netlist.xml'),'--layout',str(p/'layout.json'),'--erc',str(p/'erc.json'),'--pdf',str(p/'schematic.pdf'),'--report',str(report),'--pdf-text-tool','/usr/bin/pdftotext']
 c=subprocess.run(argv,text=True,capture_output=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
 (p/'stdout.txt').write_text(c.stdout);(p/'stderr.txt').write_text(c.stderr)
 body=load(report);err='\n'.join(body.get('errors',[]));ok=c.returncode==1 and body.get('status')=='FAIL' and fragment in err
 return {'case':name,'rc':c.returncode,'status':body.get('status'),'first_error':(body.get('errors') or [''])[0],'expected_fragment':fragment,'causal_rejected':ok,'report_sha256':sha(report),'runtime_sha256':sha(p/'runtime.json')}
def runtime_schema_float(p):
 x=load(p/'runtime.json');x['schema_version']=2.0;dump(p/'runtime.json',x)
def layout_schema_bool(p):
 x=load(p/'layout.json');x['schema_version']=True;dump(p/'layout.json',x)
def plan_schema_bool(p):
 x=load(p/'runtime.json');x['producer_plan_binding']['schema_version']=True;dump(p/'runtime.json',x)
def package_size_float(p):
 x=load(p/'runtime.json');x['producer_package_identity']['files'][0]['size']=float(x['producer_package_identity']['files'][0]['size']);dump(p/'runtime.json',x)
if OUT.exists():raise SystemExit(f'exists {OUT}')
OUT.mkdir(parents=True)
rows=[run('runtime-schema-float',runtime_schema_float,'runtime schema_version'),run('layout-schema-bool',layout_schema_bool,'layout schema_version'),run('plan-schema-bool',plan_schema_bool,'producer_plan_binding schema_version'),run('package-size-float',package_size_float,'producer package identity')]
result={'status':'PASS' if all(x['causal_rejected'] for x in rows) else 'FAIL','rows':rows,'source_inputs':{f:sha(SOURCE/f) for f in [*NAMES.values(),'runtime.json']},'source_cad_unchanged':'verified separately by 13-mutation suite','package':'c77ca8ed6783532aaad86496f868f9d22af376c5756c9464c35938bdaf3ce3ca'}
dump(D/'strict-type-independent/actual-type-probes.json',result)
print(json.dumps(result,ensure_ascii=False,indent=2));raise SystemExit(0 if result['status']=='PASS' else 1)
