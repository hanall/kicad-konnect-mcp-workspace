# JSON 엄밀 타입 후행 결함 독립 감사

## 판정

**동결 package `c77ca8ed6783532aaad86496f868f9d22af376c5756c9464c35938bdaf3ce3ca`에서 원 `schema_version: true` survivor와 지정 schema/rc/producer type 경계는 재현 기준으로 닫혔다.**

이 판정은 후행 JSON 타입 결함에 한정한다. X1, host/Codex 검증과 전체 goal closeout은 아직 미완료다.

## 패키지 경계

| 판본 | package SHA-256 | 파일 | 상태 |
|---|---|---:|---|
| C1 원 실행판 | `b274e7d851c129bb62402d1d71f18b43a772d29326ba612ce4cd2954233f4fbf` | 17 | 원 identity·원 evidence 보존 |
| strict type판 | `c77ca8ed6783532aaad86496f868f9d22af376c5756c9464c35938bdaf3ce3ca` | 17 | 현재 source와 CASE `skills-type-fixed` copy가 manifest 17/17 일치 |

두 identity manifest의 차이는 다음 네 script뿐이다.

```text
scripts/collect_evidence.py
scripts/guarded_mcp.py
scripts/package_identity.py
scripts/verify_quality.py
```

문서·asset·profile hash는 변하지 않았다. 과거 b274 receipt를 c77 성공으로 자동 승계하지 않고 c77 native collection/report를 새로 사용했다.

## 원 survivor와 인과 수정

원 b274 verifier는 registry copy의 `schema_version`을 integer `1`에서 JSON boolean `true`로 바꾸고 caller가 그 copy SHA를 정확히 다시 고정했는데도 rc0/PASS를 냈다.

- 원 survivor result SHA: `38bf5b700d11245b70e6c93c3c9dc0fbf71e88e3d9e312535f21e15631c3fd70`
- 원 report SHA: `950867d68079bbfbee44b071001f431553c46f431f682936bd1006a326a7ef81`
- mutated registry SHA: `91a940544d3de6141f5fa1304969046abd20ae4c635b0f85d44d04330a5f38bc`

원인은 Python의 `True == 1` 값 동등성과 old `schema_version == 1` 검사다. 새 판본은 다음을 분리했다.

| 경로 | 엄밀화 |
|---|---|
| `guarded_mcp.py` | plan-index `schema_version`은 `type is int` AND `1` |
| `collect_evidence.py` | registry/semantic schema exact int, MCP `logical_rc` exact int `0` |
| `package_identity.py` | canonical JSON `strict_equal`; bool/int/float 구분, non-JSON 타입 거부 |
| `verify_quality.py` | runtime/registry/semantic/plan/layout/companion schema exact int, companion rc exact int, producer package/plan strict equality |

## actual C1 정상 재검증

현재 source의 public verifier를 실제 `root-type-fixed` native 입력에 다시 실행했다.

- rc: 0
- report: PASS
- package: `c77ca8ed...3ca`
- errors: 0
- report SHA: `c9bce5fac57bbf7bad15320a13bcb591fa8be95ff1ccd854001c9407be686efe`
- 시각·동적·정격·PCB·제조·통전·안전 scope는 계속 `not_checked`/`not_claimed`

이는 C1의 c77 deterministic static contract 통과이며 과거 b274 결과의 이름 변경이 아니다.

## 독립 actual-native mutation 재실행

Root runner와 같은 mutation 본문을 사용하되 다음만 바꿨다.

- verifier: 현재 root c77 source
- 출력: 허용된 `project/evidence/strict-type-independent/mutations/`
- 감사 증거: `strict-type-independent/`
- frozen identity: c77

결과:

| 항목 | 결과 |
|---|---:|
| 정상 control | 1 PASS |
| 기존 causal mutation | 12/12 각각 기대 원인으로 FAIL |
| registry boolean survivor | 0 survivor, rc1/FAIL |
| 오염되지 않은 GREEN2 | 1 PASS |
| 원 C1 CAD·registry·semantic 변경 | 0 |

결과 정본 `results.json` SHA-256: `c1cbfc478c48102448837bd6cb378a77e6401d9408e34271a3206939c966d450`.

13번 bool 변이는 input hash mismatch가 아니라 정확히 다음 문구로 거부됐다.

```text
registry schema_version은 integer 1이어야 함
```

## 추가 actual-input 타입 probe

actual C1 native 입력 사본으로 네 타입 변이를 추가 확인했다.

| 변이 | rc/status | 인과 오류 |
|---|---|---|
| runtime schema `2 -> 2.0` | 1/FAIL | runtime schema_version integer 2 요구 |
| layout schema `1 -> true` | 1/FAIL | layout schema_version integer 1 요구 |
| producer plan schema `1 -> true` | 1/FAIL | producer_plan_binding schema integer 1 요구 |
| producer package file size `int -> float` | 1/FAIL | producer package identity strict 불일치 |

`actual-type-probes.json` SHA-256: `fb46a95c68c4ca426414ca0f1f7c9350b143bb176b5b774a034a9f7e948c0843`.

## 공개 gate

최종 권위 실행은 existing local TMPDIR과 `python3 -B`를 사용했다.

```text
python3 -B -m unittest discover -s tests -p 'test_standard_quality*.py' -v
```

- 92 tests
- rc0
- log SHA: `1bb7d146b6d3da7a93ef996f8df6bb6fce2f4857519dc61fc377b863dd2c59a8`

이 gate는 plan schema bool/float, registry/semantic/runtime/layout/producer plan schema, producer package 숫자 타입, companion schema/rc, collector logical rc, package strict equality를 각각 다룬다.

## 보존·제한

- 원 registry SHA: `c1669c3b...bc25`
- 원 semantic SHA: `39d1677c...382`
- C1 `.pro/.sch/.pcb/sym-lib-table` SHA는 mutation 전후 모두 일치했다.
- mutation은 native export/runtime/registry **사본**에만 적용했다.
- CAD·MCP·GUI write: 0
- source 수정: 0
- 이번 감사가 C1 전기·시각 결론이나 전체 프로젝트 완료 범위를 확대하지 않는다.

경계 기록: 감사 시작 때 허용 상위에 임시 identity JSON 1개를 만들었다가 즉시 삭제하고 Root에 보고했다. 또한 첫 gate 실행은 존재하지 않는 TMPDIR을 지정해 transient system temp 가능성이 있어, 최종 권위 gate를 local TMPDIR+`python3 -B`로 다시 실행했다.

구조화 정본은 `audit.json`이다.
