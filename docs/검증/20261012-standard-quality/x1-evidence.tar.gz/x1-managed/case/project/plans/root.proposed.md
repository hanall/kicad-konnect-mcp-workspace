# X1 v2 root page 계획 제안본

## 식별·부품

대상은 `x1.kicad_sch`, 제목은 `sense-filter`, 1 page A4 landscape다. J1 VIN, J2 SENSE, R1/R2 10k, C1 10n은 모두 unit 1이고 pin 1/2 passive다. footprint는 빈 문자열이다. 실제 좌표·회전·mutation schema는 fresh 조회 전 추정하지 않는다.

## 읽기 흐름과 실선

J1 VIN에서 R1을 거쳐 SENSE node로 진행하고 R2와 C1이 GND로 내려가며 J2 SENSE로 나가는 좌→우 흐름을 제안한다. VIN은 J1.1/R1.1, SENSE는 R1.2/R2.1/C1.1/J2.1, GND는 J1.2/R2.2/C1.2/J2.2 전체를 각 한 실선 root로 닫는다. endpoint gap, 다른 net pin 혼입, 점과 전기망 불일치를 금지한다.

## 포트·반환·library

페이지 간 global 포트는 없다. 두 connector가 외부 경계다. GND는 같은 페이지의 실선 반환이고 power symbol/PWR_FLAG는 없다. installed source unit 1 관측, symbol endpoint 관측, 실제 배치 endpoint를 함께 대조한다. sym-lib-table에는 Device와 Connector_Generic만 project scope로 등록한다.

## 검증·차단

첫 쓰기 전에 최종 common/page plan과 plan-index SHA를 고정한다. 작성 뒤 5 ref/10pin/3net, unit/type/value/lib/빈 footprint, solid-wire groups, orphan0, short0, bounds unresolved0을 검증한다. native ERC 0/0/0과 ignored4종은 fresh 결과로 확인하고 원 rc를 보존한다. 실제 schema, runtime identity, 배치 endpoint, GUI roundtrip, 전페이지 시각 판독이 unknown이면 완료로 승격하지 않는다.
