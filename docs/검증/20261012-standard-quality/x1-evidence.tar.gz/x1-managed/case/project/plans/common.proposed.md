# X1 v2 공통 계획 제안본

## 권위와 범위

모드는 design이며 project `x1.kicad_pro`, root `x1.kicad_sch`, create_project의 빈 기본 `x1.kicad_pcb`, project `sym-lib-table`만 쓰기 허용 대상으로 제안한다. PCB는 기본 생성 외 편집하지 않는다. 기대 semantic SHA는 `3c5adc5d5f80e30b07697a7c8721c0457acb9c2adbb59a90959ad2f985d15f6b`, registry SHA는 `b67c028146ddb06e1c3f5e5510fbfd275d6ab3925d2e5a772bac7ac528e55980`, current package identity는 `c77ca8ed6783532aaad86496f868f9d22af376c5756c9464c35938bdaf3ce3ca`다. 후보 CAD와 native evidence는 아직 없다.

## 전기·실선·반환

5부품 10pin을 VIN, SENSE, GND 세 망으로 전수 분류한다. 각 net의 모든 pin은 하나의 solid-wire root로 연결한다. label은 이름 표시만 하며 연결을 합성하지 않는다. GND라는 이름을 PE·chassis·절연 반환이나 실제 전원 source로 확대하지 않는다. PWR_FLAG와 power symbol은 사용하지 않는다.

## library·도구 unknown

Device와 Connector_Generic 설치 source는 읽기 전용 exact mapping으로만 등록한다. get_symbol_info unit 미제공은 source unit 관측과 실제 배치 endpoint로 보완하되 응답을 조작하지 않는다. fresh launcher/config/server cwd/version/commit과 current schema를 확인하기 전 CAD를 쓰지 않는다. proposed 파일은 정식 plan-index가 아니다.

## 검증·범위

owning root native kicadxml/PDF/severity-all ERC와 layout pin/wire/orphan/short 4조회, source/plan/package SHA를 결속한다. runtime schema 2의 version과 rc는 JSON integer exact여야 한다. PDF bbox는 glyph 육안 검토를 대신하지 않는다. 정적 PASS를 divider 성능, ADC 조건, PCB, 정격, 제조, 발주, 통전 또는 안전으로 승격하지 않는다.
