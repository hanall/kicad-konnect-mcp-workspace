# X1 v2 합성 분압·필터 요구 원문

## 권위와 독립성

이 문서는 Root가 표준 스킬의 이식성·검증성을 평가하기 위해 후보 CAD 작성 전에 선정한 합성 X1 예제다. 사용자 제품 전기 요구나 실제 SMPS 정격 설계가 아니다. 현재 이 oracle 디렉터리에는 `x1.kicad_sch`, `x1.kicad_pro`, `x1.kicad_pcb`, `sym-lib-table`이 없고 native XML/layout/ERC/PDF도 없다. 기대값을 후보 CAD에서 역산하지 않는다.

## 부품·unit·pin 계약

- J1: value `VIN`, symbol `Connector_Generic:Conn_01x02`, unit 1, pin 1/2 passive, footprint 빈 문자열.
- J2: value `SENSE`, symbol `Connector_Generic:Conn_01x02`, unit 1, pin 1/2 passive, footprint 빈 문자열.
- R1: value `10k`, symbol `Device:R`, unit 1, pin 1/2 passive, footprint 빈 문자열.
- R2: value `10k`, symbol `Device:R`, unit 1, pin 1/2 passive, footprint 빈 문자열.
- C1: value `10n`, symbol `Device:C`, unit 1, pin 1/2 passive, footprint 빈 문자열.

총 5부품·10pin이다. `get_symbol_info`의 unit 미제공을 unit 0이나 임의값으로 채우지 않는다. unit 1은 설치된 개별 symbol source의 extends 부재, nonzero unit inventory `[1]`, passive pin 2개를 읽기 전용으로 확인한 `unit-source-observation.json`에 근거하며 실제 배치 endpoint readback과 다시 대조한다.

## net·실선 계약

- `VIN` = `J1.1`, `R1.1`.
- `SENSE` = `R1.2`, `R2.1`, `C1.1`, `J2.1`.
- `GND` = `J1.2`, `R2.2`, `C1.2`, `J2.2`.

세 망의 모든 pin은 각 net마다 하나의 실제 solid-wire root로 전도되어야 한다. local label은 이름 표시만 하며 빠진 wire를 대체하지 않는다. 전원 symbol, `PWR_FLAG`, global port는 추가하지 않는다. 점·좌표 중첩과 native 전기망은 독립 대조한다.

## 프로젝트·페이지·생성 경계

project stem은 `x1`, root schematic은 `x1.kicad_sch`, project는 `x1.kicad_pro`, create_project가 만드는 빈 기본 PCB는 `x1.kicad_pcb`, project symbol table은 `sym-lib-table`이다. PCB는 기본 생성 외 편집하지 않는다. 1 page A4 landscape이며 본문 제목은 `sense-filter`다. native ERC 사전 기대는 error 0, warning 0, exclusion 0과 기본 ignored check 4종이지만 실제 fresh 실행 전 관측 성공이 아니다.

정적 계약 통과는 divider 오차, ADC 입력, PCB 거리, 정격, DFM, 제조, 발주, 통전, 인증 또는 실물 안전 합격이 아니다. footprint가 비어 있으므로 제조 준비가 아니다.
