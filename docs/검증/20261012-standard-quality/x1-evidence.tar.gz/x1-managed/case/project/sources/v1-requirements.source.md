# X1 독립 요구 원문 정규화 - sense-filter

## 권위와 상태

이 문서는 2026-10-12 사용자 후속 과제를 후보 CAD보다 먼저 정규화한 독립 oracle 원문이다. 현재 `sense-filter.kicad_sch`와 native XML/PDF/ERC/layout은 존재하지 않으며, 후보 산출물에서 기대값을 추출하지 않는다. 이 예제는 SMPS 정격 검증이 아니라 분압과 필터의 문법·표현 예제다.

## 부품 계약

- J1: value `VIN`, `Connector_Generic:Conn_01x02`, unit 1, pin 1/2 모두 passive, footprint 미할당 빈 문자열.
- J2: value `SENSE`, `Connector_Generic:Conn_01x02`, unit 1, pin 1/2 모두 passive, footprint 미할당 빈 문자열.
- R1: value `10k`, `Device:R`, unit 1, pin 1/2 모두 passive, footprint 미할당 빈 문자열.
- R2: value `10k`, `Device:R`, unit 1, pin 1/2 모두 passive, footprint 미할당 빈 문자열.
- C1: value `10n`, `Device:C`, unit 1, pin 1/2 모두 passive, footprint 미할당 빈 문자열.

## 전기 net과 실선 계약

- `VIN` = `J1.1`, `R1.1`.
- `SENSE` = `R1.2`, `R2.1`, `C1.1`, `J2.1`.
- `GND` = `J1.2`, `R2.2`, `C1.2`, `J2.2`.
- 세 net 모두 각 pin 묶음 전체가 한 개의 실제 solid-wire root로 전도되어야 한다. local label은 이름을 부여할 수 있지만 빠진 wire를 대신하지 않는다. 전원 symbol과 `PWR_FLAG`는 두지 않는다. global port도 없다.

## 페이지와 판정 경계

project stem, root schematic 파일명, 표제 이름은 `sense-filter`로 통일한다. 1 page A4를 사용한다. semantic의 ordered page size는 host KiCad A4 native 관측에 근거해 landscape `297 x 210 mm`로 선택했으며, orientation을 바꾸려면 CAD 작성 전에 별도 승인과 oracle 재봉인이 필요하다. passive 회로의 native ERC 기대는 error 0, warning 0, exclusion 0이지만 아직 실행하지 않았으므로 관측 사실이 아니다. 이 문법 예제의 정적 합격은 SMPS 정격, divider 허용오차, ADC 입력, PCB, 제조, 통전 또는 안전 합격이 아니다.
