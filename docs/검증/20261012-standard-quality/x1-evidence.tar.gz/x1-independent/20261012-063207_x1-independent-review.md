# X1 독립 읽기 전용 검토 — 범위 제한 수용

## 결론

합성 X1 한 페이지의 **native 전기 정적·GUI/PDF 시각·증거 결속을 각각 제한 범위로 수용**한다. 확인된 범위 안의 차단 결함은 발견하지 못했다. 아래 조건과 미검증 영역을 제거한 전체 성공, 제조·통전·안전 승인으로 읽어서는 안 된다.

| 축 | 판정 | 직접 근거 | 경계 |
|---|---|---|---|
| native 전기 정적 | 제한 통과 | 독립 XML 전단사, wire-only graph, native ERC/원 rc, 정식 verifier 독립 rc0 | 실물 핀·package, 정격·성능 불증명 |
| GUI/PDF 시각 | 1단계 독립 판독 제한 통과 | GUI/native 네 이미지 직접 판독 및 SHA 봉인, 현재 PDF 전체 1쪽 독립 렌더 직접 판독 | 저장/재열기는 제공 receipt 대조이며 검토자가 GUI를 조작하지 않음 |
| 증거·재현성 | 조건·관측차이 공개 후 제한 수용 | 현재 CAD/계획/원문/package/registry/native SHA·rc, 전후 semantic/geometry/raster 대조 | 원작성 첫 mutation 시각·native 자식 env·전후 CAD field bytes 직접검증 아님 |

## 정확한 수용 조건

1. 현재 저장본 x1.kicad_sch fec0092cb81f57ca5e9d700a40978fd12503d161ab4079e5dd5120f9e63b522e 및 c77 package에만 한정한다. CAD/package/계획/registry/semantic 변경 시 이 판정은 승계하지 않는다.
2. 합성 X1의 5부품·10핀·3망 정적 요구, 한 페이지 GUI/PDF 시각과 제공 영수증의 결속 범위로만 수용한다. 실제 제품 설계·정격·동적 성능·PCB·제조·통전·실물 안전·인증을 포함하지 않는다.
3. 기본 비활성 ERC 4종과 빈 footprint 5개, Title/Date/Rev 공백, 자식 native /proc 환경 미관측, 원 first mutation chronology 재구성 미실행을 숨기지 않는다.
4. 1단계 봉인 전 도움 없는 판독만 독립 시각 정본이다. 2단계 roundtrip.json의 visual_root/title_block 노출과 이후 설명은 보충 단계로 분리하고 답안으로 승계하지 않는다.
5. 전후 layout geometry·XML semantic·동일옵션 PDF ink raster는 동일하지만 PDF text-layer bbox 17단어는 exact 불일치다. CAD 표시field 좌표 전후 bytes 직접 비교나 모든 출력 조건의 pixel 동일로 확대하지 않는다.

## 권위·범위·독립성

- 명시 요구: 현재 X1의 읽기 전용 독립 시각→전기·증거 대조. CAD/MCP/GUI/계정/원본 수정0, 새 설치·모델 CLI 실행0.
- 사용한 가정: 후보 독립 합성 semantic을 정적 기대값으로 사용한다. 실제 장비나 SMPS 요구의 충족으로 해석하지 않는다.
- 실제 작업: 네 PNG를 각기 `view_image`로 본 뒤 `BLIND-OBSERVATION.md`를 봉인했다. 이후 허용된 계약·계획·native 생데이터만 대조했다. 추가 허용된 동일 최종본 GUI전 `evidence/22-native-final/`은 변환 전후 비교 용도로만 읽었다.
- 독립성 사건: 2단계 지정 `roundtrip.json` 전체 읽기 중 `visual_root`/`title_block` 자체 설명 필드가 노출됐다(`x1-gui/roundtrip.json:64-65`). **봉인 전 독립판독에 영향 없음**. 해당 필드를 정답·시각 근거로 승계하지 않았으며 그 뒤 판독은 보충으로 분리했다. `AUTHOR-RESULT`, 자체점수, 다른 후보는 읽지 않았다.
- 추가 쓰기: 최초 x1-independent 밖 쓰기0. Root 추가 허용 뒤에만 `project/evidence/x1-independent-verifier/static-report.json`을 신규 작성하는 정식 verifier를 실행했다. 보고서·JSON·독립 렌더 외 쓰기0.
- 저장/정상 닫기/재열기 과정 자체를 이 검토자가 실시간 관측하거나 재실행하지 않았다. 제공 왕복 receipt, 이미지와 저장본/current SHA를 대조한 것이다.

## 1단계 도움 없는 회로 읽기

J1.1에서 VIN 실선이 직렬 R1(10k)을 거쳐 SENSE와 J2.1로 이어진다. R1 뒤의 상단 실선에서 R2(10k), C1(10n)이 각각 아래 GND 실선으로 떨어져 병렬 가지를 만든다. J1.2와 J2.2는 아래 반환 실선으로 함께 연결된다. 각 가지의 상·하단에 점이 보여 junction 4개를 읽었다. GND는 이미지 단독으로 PE/섀시 여부를 알 수 없으며, 사전 요구에서 단일 신호 반환으로 확인했다. 별도 부유/Kelvin/PE/전원 심볼/다른 페이지 포트는 이 예제에 없다.

```text
J1.1 -- VIN -- R1(10k) --+---- SENSE ----+---- J2.1
                         |               |
                       R2(10k)         C1(10n)
                         |               |
J1.2 --------------------+----- GND ------+---- J2.2
```

수동 R/C 물리 핀 번호는 이미지에서 숨겨져 있으므로 1단계에서 추측하지 않았다. 2단계 native XML과 설치 symbol source SHA/배치 endpoint를 대조해 계약상의 1/2를 확인했다. 이것은 실물 package pad 대응의 검증이 아니다.

| 표시 항목 | 실제 판독 |
|---|---|
| reference/value | J1/VIN, J2/SENSE, R1/10k, R2/10k, C1/10n을 분리해서 읽음 |
| connector pin | J1/J2 위쪽 1, 아래쪽 2 |
| net label | VIN, SENSE, GND |
| 문자 침범·잘림 | 네 이미지와 현재 PDF 전체에서 확정 문자획 관통/잘림 미발견 |
| 본문 제목 | sense-filter |
| 표제란 | A4, x1.kicad_sch, Id 1/1, KiCad 10.0.6; Title/Date/Rev 공백 |

본문 제목과 표제란 제목은 별개다. 합성 요구는 본문 sense-filter만 요구하여 표제란 공백을 이 예제의 차단 결함으로 세지 않는다(`contracts/x1-v2.semantic.json`의 required_text). 고객 인도 문서나 실제 제품에서는 별도 결정이 필요하다. 공백의 native 근거는 `evidence/root-post-gui/netlist.xml:9,11-12`다.

## native 전기·실선 독립 대조

| 항목 | 결과 |
|---|---|
| 부품/값/lib/footprint | 5개 exact; R1/R2=10k, C1=10n, J1=VIN, J2=SENSE; footprint 모두 빈 문자열 |
| 물리 pin inventory | 10개 정확히1회; unit1/passive 계약 일치 |
| VIN | J1.1, R1.1 |
| SENSE | R1.2, R2.1, C1.1, J2.1 |
| GND | J1.2, R2.2, C1.2, J2.2 |
| 실선 | 15 wire, 4 junction, label을 join으로 쓰지 않은 실제3연결성분; 서로 다른 net root 합류0 |
| orphan/short/bounds | 원 layout 관측 각각0/0/미해결0; native XML 및 독립 graph와 별도 대조 |
| ERC | owning root x1.kicad_sch, / 한 시트, error/warning/exclusion0; 원 rc0 |

기본 비활성 4종은 **활성 검사 통과로 계산하지 않는다**.

| ERC key | 의미 |
|---|---|
| footprint_filter | 할당 footprint의 filter 불일치 검사 비활성 |
| four_way_junction | 네 접속점 합류 검사 비활성 |
| simulation_model_issue | SPICE model 검사 비활성 |
| single_global_label | 단독 global label 검사 비활성 |

제조 차단 조건은 별도다. 빈 footprint가 5개라 실물 package/제조 준비는 수용하지 않는다. 정확한 위치: `contracts/x1-v2.semantic.json:11,16,21,26,31`. 이 자체가 synthetic 계약과 일치하는 것이지 제조 적합성을 뜻하지 않는다.

## GUI전후 변환과 표시field

```text
CAD0 seal -> saved/native-before -> GUI save/close/reopen
          -> native-after -> current SHA -> blind image seal
          -> semantic/hash/raster supplemental checks
```

| 대상 | GUI전 → GUI후 |
|---|---|
| schematic SHA | b48ec758… → fec0092c… 변경 |
| project SHA | 1aa88ccd… → f9656afb… 변경 |
| PCB / sym-lib-table / 계획 / registry / semantic | bytes SHA 동일 |
| component/pin/unit/net/type/value/lib/footprint/표제 semantic | XML 전단사 동일 |
| layout geometry/pin/junction/text/orphan/short | 반환배열 순서만 정규화 후 exact 동일 |
| 전체 PDF ink raster | 독립 동일옵션 scale1754 및 300dpi 각각 전후 bytes 동일 |
| PDF text-layer bbox | 17 word의 수직 extent exact 불일치; 문자/xMin/xMax 동일 |
| 현재 CAD reference/value | 10field inventory 및 실제 at/effects 기록; GUI전 CAD원field bytes 미열람으로 직접전후 동일은 미확인 |

bbox의 17단어에서 yMin은 +0.325714 pt, yMax는 -0.120000 pt였다. 최대 경계 이동은 약0.115 mm, bbox 높이 감소는 약0.157 mm다. **문자 metric 변화의 원인은 확정하지 않는다.** exact 불일치 기록을 삭제하거나 tolerance로 PASS로 바꾸지 않았다. 서로 다른 검사의 범위를 구분하여 비차단 관측차이로 공개한다. `INDEPENDENT-CHECKS.json`에 word별 before/after/delta를 보존했다. glyph 판독은 bbox 검사와 별개로 수행했고 실제 동일옵션 ink raster가 같은 것을 별도로 확인했다.

현재 field at 좌표, 원본 XML/netlist, wire/pin graph, 전후 geometry, 현재 PDF 전체 판독은 별도 사실이다. 이들을 합쳐 CAD원field 전후 bytes가 완전히 동일했다고 쓰지 않는다.

## 실행·증거·거부 보존

| 기존 fresh 단계 | 원 rc | 근거 파일행 |
|---|---|---|
| native XML | 0 | commands.json:238-256 |
| native PDF | 0 | commands.json:259-272 |
| native ERC | 0 | commands.json:275-293 |
| guarded MCP readback | 0 | commands.json:296-322 |
| standard verifier | 0 | commands.json:324-353 |
| 검토자의 첫 official 재호출 | 2 | independent-verifier-run.json; 허용 출력이 project root 밖이라 사전guard 거부 |
| 추가 허용 경로 official 재호출 | 0 | independent-verifier-authorized-run.json 및 추가 허용 project/evidence/x1-independent-verifier/static-report.json |

원 rc2를 숨기지 않았고 guard/allowlist를 완화하지 않았다. 정확한 추가 출력 허용을 받고 동일 verifier를 실행해 새 rc0을 얻었다. 이는 앞선 거부를 처음부터 성공으로 바꾸는 것이 아니다.

현재 정본과 외부 실행본 전체 17파일 package identity는 동일 c77다. 기존/독립 verifier와 runtime producer의 전체 identity, registry pin, 4source, 현재 plan3개, required semantic source4개, native 출력4개와 명령log SHA를 각각 직접 재대조했다. Konnect recorded version 0.13.0+hanall.1/commit94f80350…, recorded process와 current release executable/config SHA도 일치했다. 이미 종료된 과거 PID의 환경을 이 검토자가 다시 관측했다고 주장하지 않는다.

native 호출자 HOME/XDG는 격리 x1-gui/native-home으로 명시됐다. 기존8설정 bytes는 전후·현재 모두 같으며 `cvpcb.json` 1개 신규생성이 공개되어 있다(`x1-gui/native-config-after.json:23-26`). 자식 /proc 환경 직접 관측은 아니다(`native-caller-environment.json:52`). 기존 설정 무변경과 전체 디렉터리 무변경은 구별한다.

PRE-CAD-SEAL의 현재 계획/registry/semantic SHA는 일치한다. 봉인시각은 완료/native보다 먼저지만 첫 원 mutation journal을 직접 재구성하지 않았으므로 제시된 CAD0 선행 기록 이상의 독립 시간 증명은 하지 않는다(`PRE-CAD-SEAL.json:2-3`). 일반 verifier도 phase root trust를 검사하지 않는다고 공개한다(`static-report.json:41`).

## 모든 원 scope 공개

기계적 정적 보고서의 not_checked를 이 사람의 판독으로 몰래 checked로 덮지 않는다. 다음은 원값이며, 시각 보완은 위 독립 단계로 분리했다.

### 정적 report scope

| key | 원값 |
|---|---|
| deterministic_static_contract | checked |
| visual_review | not_checked |
| dynamic_operation | not_checked |
| glyph_completeness | not_checked |
| all_pages_manual_review | not_checked |
| electrical_performance | not_checked |
| all_erc_rules | not_claimed |
| schematic_position_as_pcb_distance | not_checked_not_equivalent |
| voltage_current_rating_and_sequencing | not_checked |
| pcb_manufacturing_energization_physical_safety | not_checked |
| port_direction_and_return_semantics | not_checked |
| project_semantic_logic | not_applicable_explicit_empty |
| port_physical_attachment | checked |
| port_page_annotations | checked |
### semantic scope_limits

| key | 원값 |
|---|---|
| dynamic_operation | not_checked |
| footprint_and_physical_package | not_checked_empty_by_contract |
| pcb_manufacturing_energization_physical_safety | not_checked |
| pin_functions | not_checked_unless_full_pin_functions_is_present |
| port_direction_and_return_semantics | not_applicable_no_global_ports |
| visual_review | not_checked |
### native collector scope

| key | 원값 |
|---|---|
| native_static_collection | checked |
| gui_roundtrip_receipt | not_checked_not_synthesized |
| all_pages_visual_review | not_checked |
| native_erc | owning root의 --severity-all JSON과 원 rc를 보존; configured policy·identity만 검증; all-checks·PCB 거리·전압/전류 정격을 주장하지 않음 |
| protocol_page | not_collected; 별도 운영자가 외부 증거로 결속 |
| pdf_page_png | not_generated; 필요 시 pdftoppm을 별도 명시 실행해 결속 |
| electrical_dynamic_manufacturing_energization | not_checked |

## 남은 unknown과 다음 결정

- 실제 주입 전압·부하·허용오차·전류·ADC 요구·동적 응답·sequencing은 계약에 없고 검사하지 않았다.
- 실물 package pad/pin 대응, footprint, PCB 거리·배치·routing·DFM·열·절연·정격·실물 안전은 이 예제 밖이다.
- no-port는 empty inventory의 적용불가이며 방향/return 의미 전범위 PASS가 아니다.
- 원작성 최초 mutation chronology와 native 자식환경 직접관측, CAD전후 field원bytes는 위와 같이 미확인이다.
- 정확한 SHA가 유지되고 제한 범위를 인정할 때 Root가 합성 X1의 해당 package/실행 조합 receipt에 이 독립 결과를 연결할 수 있다. 다른 과제·OS·모델·제조/실물 안전 지원으로 자동 승계하지 않는다.

## 읽기 전용 재대조 명령

기존 산출물을 다시 읽는 명령만 제공한다. native 재생성·GUI·MCP·CAD 저장·계정 조작·설치·commit/push 명령은 없다.

```bash
P='/home/hanol/kicad-konnect-mcp-workspace/.artifacts/20261012-040121-standard-quality/x1-managed/case/project'
sha256sum "$P/x1.kicad_sch" "$P/registry.json" "$P/contracts/x1-v2.semantic.json"
pdfinfo "$P/evidence/root-post-gui/schematic.pdf"
pdftotext -bbox-layout "$P/evidence/root-post-gui/schematic.pdf" -
python3 -B -c 'import json,sys; j=json.load(open(sys.argv[1])); print([(x["phase"],x["rc"]) for x in j["commands"]])' "$P/evidence/root-post-gui/commands.json"
```

## SHA와 산출물

- 시각 봉인: `76fcf1a5ad812a5227d6531a2bfecada57d19a1aea719238f68d3bd7cff71be8`
- package: `c77ca8ed6783532aaad86496f868f9d22af376c5756c9464c35938bdaf3ce3ca`
- 현재 CAD: `fec0092cb81f57ca5e9d700a40978fd12503d161ab4079e5dd5120f9e63b522e`
- 현재 PDF: `b2e18475a917406fdbabff5055c0811278cd86a1511347a5559f745233c14d5a`
- 정식 독립 report: `62142a295684a45ca50aa5d28080d150d1be8bc252a154a47d70725c9e26074a`
- `VERDICT.json`, `INDEPENDENT-CHECKS.json`, `LOCATIONS.json`, `manifest.json`이 판정/검사/파일행/전체 산출물 SHA를 담는다.
- 원복: CAD·계정·원본 변경0이므로 필요 없다. 검토 신규산출물 외 변경을 되돌리지 않았다.
