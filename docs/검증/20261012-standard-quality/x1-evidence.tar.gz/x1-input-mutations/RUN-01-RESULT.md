# X1 actual native 사본 변이 결과

판정: `PASS / SURVIVOR 0 / ORIGINALS UNCHANGED`

- 공개 verifier 원 rc: 전체 suite rc0.
- 무변이 control과 최종 GREEN2: 2/2 rc0/PASS.
- causal 입력 변이: 12/12 rc1/FAIL, 기대 인과 문구 일치, 단순 runtime input hash 거부 0.
- 과거 boolean survivor 재검증: 1/1 rc1/FAIL.
- 추가 strict type 변이: 4/4 rc1/FAIL.
- 금지 scope 승격: 3/3 rc1/FAIL.
- survivor: 0.
- 원 CAD·registry·semantic·source runtime/report: 전후 SHA 불변.

actual review의 `run_design_review`는 footprint 미할당 5건을 error로 보고했고 verdict는 `NOT READY`다. outcome failed와 diagnostic count는 0이지만 footprint error를 시스템 오류 0과 섞어 숨기지 않는다. 이 예제의 빈 footprint는 계약된 정적 범위이며 제조 준비는 범위 밖이다. decoupling은 `pcb_distance_checked=false`, power rail 0 findings는 정격 검사가 아니다.

변이는 `project/evidence/x1-input-mutations/run-01/`의 XML/layout/ERC/PDF/runtime 사본에만 적용했다. 실제 MCP·GUI·CAD 쓰기는 수행하지 않았다.
