# X1 actual-input mutation harness 준비본

상태: `PREPARED / DRY-RUN-ONLY / ROOT-GO-REQUIRED`

현재 X1 author 프로세스와 live CASE에는 접근하거나 쓰지 않았다. 실제 native source 경로를 Root가 전달하고 GO하기 전에는 이 스크립트를 일반 모드로 실행하지 않는다.

## 고정 계약

- CASE: `$D/x1-managed/case`
- project: `case/project`
- current skill: `case/skills/kicad-schematic-quality`
- package identity: `c77ca8ed6783532aaad86496f868f9d22af376c5756c9464c35938bdaf3ce3ca`
- registry SHA: `b67c028146ddb06e1c3f5e5510fbfd275d6ab3925d2e5a772bac7ac528e55980`
- semantic SHA: `3c5adc5d5f80e30b07697a7c8721c0457acb9c2adbb59a90959ad2f985d15f6b`
- source files: `x1.kicad_sch`, `x1.kicad_pro`, `x1.kicad_pcb`, `sym-lib-table`

## 실행 계약

```bash
python3 run_mutations.py \
  --source /absolute/path/under/project/to/current-native-pass \
  --output /absolute/new/path/under/project/evidence/x1-input-mutations/run-01 \
  [--review-responses /absolute/path/under/project/to/review/responses]
```

`--source`는 current collector PASS의 XML/layout/ERC/PDF/runtime/static-report를 가져야 한다. `--output`은 존재하지 않는 새 경로여야 한다. script는 사본만 변이하고 원 CAD·registry·semantic·source runtime/report의 전후 SHA가 같을 때만 전체 PASS한다.

예정 검증은 무변이 control, causal 12개, 원 bool survivor 재검증 1개, strict type 4개, 금지 scope 승격 3개, 최종 GREEN2다. 입력 파일 변이는 runtime input SHA를 다시 봉인해 단순 hash mismatch가 아닌 인과 검사를 요구한다. scope 3개는 주장 승격 거부이며 PCB거리·정격·DFM 알고리즘의 실증이 아니다.

## 현재 수행한 것

- Python AST parse: PASS
- `--help`: rc0
- 임시 경로 `--dry-run`: rc0, 쓰기 0, source/output 생성 0
- CAD·native·MCP·GUI·모델 실행: 0
