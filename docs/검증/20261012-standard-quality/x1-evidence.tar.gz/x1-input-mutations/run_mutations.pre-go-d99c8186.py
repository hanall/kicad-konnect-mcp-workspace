#!/usr/bin/env python3
"""X1 current native 입력의 사본 변이 검증기.

실제 실행은 Root가 GUI 저장과 current native 수집을 마친 뒤 명시한
``--source``와 새 ``--output``에 대해서만 수행한다. 원 CAD·registry·semantic은
읽기만 하고 XML/layout/ERC/PDF/runtime 사본만 변이한다.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

REPO = Path(__file__).resolve().parents[3]
D = REPO / ".artifacts/20261012-040121-standard-quality"
CASE = D / "x1-managed/case"
PROJECT = CASE / "project"
SKILL = CASE / "skills/kicad-schematic-quality"
VERIFIER = SKILL / "scripts/verify_quality.py"
REGISTRY = PROJECT / "registry.json"
SEMANTIC = PROJECT / "contracts/x1-v2.semantic.json"
REGISTRY_SHA256 = "b67c028146ddb06e1c3f5e5510fbfd275d6ab3925d2e5a772bac7ac528e55980"
SEMANTIC_SHA256 = "3c5adc5d5f80e30b07697a7c8721c0457acb9c2adbb59a90959ad2f985d15f6b"
PACKAGE_SHA256 = "c77ca8ed6783532aaad86496f868f9d22af376c5756c9464c35938bdaf3ce3ca"
PROFILE_ID = "independent-x1-sense-filter-v2"
INPUT_NAMES = {"netlist": "netlist.xml", "layout": "layout.json",
               "erc": "erc.json", "pdf": "schematic.pdf"}
REQUIRED_SOURCES = {"x1.kicad_pro", "x1.kicad_sch", "x1.kicad_pcb", "sym-lib-table"}
EXPECTED_COMPONENTS = {
    "J1": {"value": "VIN", "footprint": "", "lib_id": "Connector_Generic:Conn_01x02"},
    "J2": {"value": "SENSE", "footprint": "", "lib_id": "Connector_Generic:Conn_01x02"},
    "R1": {"value": "10k", "footprint": "", "lib_id": "Device:R"},
    "R2": {"value": "10k", "footprint": "", "lib_id": "Device:R"},
    "C1": {"value": "10n", "footprint": "", "lib_id": "Device:C"},
}
EXPECTED_NETS = {
    "VIN": ["J1.1", "R1.1"],
    "SENSE": ["R1.2", "R2.1", "C1.1", "J2.1"],
    "GND": ["J1.2", "R2.2", "C1.2", "J2.2"],
}


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def dump_new(path: Path, value) -> None:
    with path.open("x", encoding="utf-8") as handle:
        handle.write(json.dumps(value, ensure_ascii=False, indent=2,
                                sort_keys=True, allow_nan=False) + "\n")


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def under_project(path: Path, label: str, *, must_exist: bool) -> Path:
    require(path.is_absolute(), f"{label}는 absolute path여야 함")
    resolved = path.resolve(strict=must_exist)
    try:
        resolved.relative_to(PROJECT.resolve(strict=True))
    except ValueError as exc:
        raise RuntimeError(f"{label}가 project root 밖임: {resolved}") from exc
    if must_exist:
        require(resolved.is_dir() and not resolved.is_symlink(),
                f"{label}가 일반 directory가 아님: {resolved}")
    else:
        require(not path.exists() and not path.is_symlink(),
                f"{label}는 새 경로여야 함: {path}")
    return resolved


def import_identity_helper():
    sys.path.insert(0, str(SKILL / "scripts"))
    import package_identity
    return package_identity


def source_file_hashes(layout: dict) -> dict[str, str]:
    files = layout.get("files")
    require(isinstance(files, dict) and set(files) == REQUIRED_SOURCES,
            f"actual layout source 범위 불일치: {set(files or {})}")
    actual = {name: sha(PROJECT / name) for name in files}
    require(actual == files, "actual source file SHA가 layout snapshot과 불일치")
    return actual


def validate_oracle() -> dict:
    require(sha(REGISTRY) == REGISTRY_SHA256, "원 registry SHA 불일치")
    require(sha(SEMANTIC) == SEMANTIC_SHA256, "원 semantic SHA 불일치")
    registry = load(REGISTRY); semantic = load(SEMANTIC)
    require(type(registry.get("schema_version")) is int and registry["schema_version"] == 1,
            "registry schema_version strict integer 불일치")
    require(type(semantic.get("schema_version")) is int and semantic["schema_version"] == 2,
            "semantic schema_version strict integer 불일치")
    require(semantic.get("profile_id") == PROFILE_ID, "semantic profile_id 불일치")
    require(semantic.get("components") == EXPECTED_COMPONENTS,
            "semantic 5부품 계약 불일치")
    require(semantic.get("nets") == EXPECTED_NETS, "semantic 3망 계약 불일치")
    require(set(semantic.get("required_source_files", [])) == REQUIRED_SOURCES,
            "semantic required source 범위 불일치")
    require(len(semantic.get("pin_types", {})) == 10
            and set(semantic.get("pin_units", {})) == set(semantic["pin_types"])
            and all(type(value) is int and value == 1
                    for value in semantic["pin_units"].values()),
            "semantic 10pin/unit strict 계약 불일치")
    return {"registry_sha256": sha(REGISTRY), "semantic_sha256": sha(SEMANTIC)}


def validate_source(source: Path, package_identity) -> tuple[dict, dict, dict]:
    for name in [*INPUT_NAMES.values(), "runtime.json", "static-report.json"]:
        require((source / name).is_file(), f"actual native source 입력 누락: {name}")
    layout = load(source / "layout.json")
    runtime = load(source / "runtime.json")
    report = load(source / "static-report.json")
    require(report.get("status") == "PASS", "actual native source report가 PASS가 아님")
    require(type(runtime.get("schema_version")) is int and runtime["schema_version"] == 2,
            "actual runtime schema_version 불일치")
    require(runtime.get("profile_id") == PROFILE_ID, "actual runtime profile_id 불일치")
    current_package = package_identity.capture(SKILL)
    require(current_package["sha256"] == PACKAGE_SHA256,
            "CASE current package identity 불일치")
    require(package_identity.strict_equal(runtime.get("producer_package_identity"),
                                          current_package),
            "actual runtime producer package identity 불일치")
    actual_inputs = {key: sha(source / name) for key, name in INPUT_NAMES.items()}
    require(runtime.get("candidate", {}).get("inputs_sha256") == actual_inputs,
            "actual native input SHA와 runtime 불일치")
    sources = source_file_hashes(layout)
    sheet = layout.get("sheets", {}).get("x1.kicad_sch")
    require(isinstance(sheet, dict), "actual X1 layout sheet 누락")
    require(len(sheet.get("layout", {}).get("components", [])) == 5,
            "actual layout component 수 불일치")
    pin_count = sum(len(item.get("pins", [])) for item in sheet.get("pins", {}).get("components", []))
    require(pin_count == 10, "actual layout pin 수 불일치")
    return current_package, sources, actual_inputs


def copy_inputs(source: Path, case: Path) -> None:
    case.mkdir(parents=True, exist_ok=False)
    for name in [*INPUT_NAMES.values(), "runtime.json"]:
        shutil.copyfile(source / name, case / name)


def refresh_runtime(case: Path) -> None:
    runtime = load(case / "runtime.json")
    runtime["candidate"]["inputs_sha256"] = {
        key: sha(case / name) for key, name in INPUT_NAMES.items()
    }
    (case / "runtime.json").write_text(
        json.dumps(runtime, ensure_ascii=False, indent=2, sort_keys=True,
                   allow_nan=False) + "\n", encoding="utf-8")


def xml_component(tree: ET.ElementTree, ref: str):
    return next(item for item in tree.findall("./components/comp") if item.get("ref") == ref)


def xml_node(tree: ET.ElementTree, ref: str, pin: str):
    for net in tree.findall("./nets/net"):
        for node in net.findall("node"):
            if node.get("ref") == ref and node.get("pin") == pin:
                return net, node
    raise RuntimeError(f"XML pin 누락: {ref}.{pin}")


def mutate_value(case: Path) -> str:
    path = case / "netlist.xml"; tree = ET.parse(path)
    xml_component(tree, "R1").find("value").text = "11k"
    tree.write(path, encoding="utf-8", xml_declaration=True)
    return "R1 value 10k -> 11k"


def mutate_netpin(case: Path) -> str:
    path = case / "netlist.xml"; tree = ET.parse(path)
    source, node = xml_node(tree, "R1", "1")
    target = next(net for net in tree.findall("./nets/net")
                  if net.get("name") in {"/SENSE", "SENSE"})
    source.remove(node); target.append(node)
    tree.write(path, encoding="utf-8", xml_declaration=True)
    return "R1.1 net VIN -> SENSE"


def mutate_pintype(case: Path) -> str:
    path = case / "netlist.xml"; tree = ET.parse(path)
    _, node = xml_node(tree, "R1", "1"); node.set("pintype", "output")
    tree.write(path, encoding="utf-8", xml_declaration=True)
    return "R1.1 pintype passive -> output"


def mutate_unit(case: Path) -> str:
    path = case / "layout.json"; data = load(path)
    component = next(row for row in data["sheets"]["x1.kicad_sch"]["pins"]["components"]
                     if row["reference"] == "R1")
    next(pin for pin in component["pins"] if pin["number"] == "1")["unit"] = 2
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n")
    return "R1.1 top-level unit 1 -> 2"


def _point(value):
    return round(float(value[0]), 5), round(float(value[1]), 5)


def _on_segment(point, wire):
    p = _point(point); a = _point((wire["x1"], wire["y1"])); b = _point((wire["x2"], wire["y2"]))
    cross = (b[0]-a[0])*(p[1]-a[1]) - (b[1]-a[1])*(p[0]-a[0])
    return (abs(cross) < 1e-5 and min(a[0], b[0])-1e-5 <= p[0] <= max(a[0], b[0])+1e-5
            and min(a[1], b[1])-1e-5 <= p[1] <= max(a[1], b[1])+1e-5)


def mutate_wiregap(case: Path) -> str:
    path = case / "layout.json"; data = load(path)
    sheet = data["sheets"]["x1.kicad_sch"]
    component = next(row for row in sheet["pins"]["components"] if row["reference"] == "R1")
    pin = next(row for row in component["pins"] if row["number"] == "1")
    target = _point((pin["x"], pin["y"]))
    wires = sheet["layout"]["wires"]
    touching = [wire for wire in wires if _on_segment(target, wire)]
    require(touching, "R1.1을 지나는 actual wire를 찾지 못함")
    replacements = []
    for index, wire in enumerate(touching):
        a = _point((wire["x1"], wire["y1"])); b = _point((wire["x2"], wire["y2"]))
        horizontal = a[1] == b[1]
        require(horizontal or a[0] == b[0], "wiregap 대상 사선")
        step = 1.27
        if target == a:
            new = dict(wire)
            if horizontal: new["x1"] = a[0] + (step if b[0] > a[0] else -step)
            else: new["y1"] = a[1] + (step if b[1] > a[1] else -step)
            replacements.append(new)
        elif target == b:
            new = dict(wire)
            if horizontal: new["x2"] = b[0] + (step if a[0] > b[0] else -step)
            else: new["y2"] = b[1] + (step if a[1] > b[1] else -step)
            replacements.append(new)
        else:
            left = dict(wire); right = dict(wire)
            left["uuid"] = f"mutation-gap-{index}-a"; right["uuid"] = f"mutation-gap-{index}-b"
            if horizontal:
                direction = 1 if b[0] > a[0] else -1
                left["x2"] = target[0] - direction*step
                right["x1"] = target[0] + direction*step
            else:
                direction = 1 if b[1] > a[1] else -1
                left["y2"] = target[1] - direction*step
                right["y1"] = target[1] + direction*step
            replacements.extend([left, right])
    ids = {id(item) for item in touching}
    sheet["layout"]["wires"] = [item for item in wires if id(item) not in ids] + replacements
    sheet["layout"]["wire_count"] = len(sheet["layout"]["wires"])
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n")
    return f"R1.1 actual endpoint 주위 {len(touching)}개 wire에 1.27 mm gap 생성"


def mutate_missing_orphan(case: Path) -> str:
    path = case / "layout.json"; data = load(path)
    del data["sheets"]["x1.kicad_sch"]["orphans"]
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n")
    return "required raw orphan evidence field removed"


def mutate_ignored_erc(case: Path) -> str:
    path = case / "erc.json"; data = load(path)
    data["ignored_checks"].append({"description": "Mutation-only ignored check",
                                   "key": "mutation_ignore"})
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n")
    return "unexpected ERC ignored_checks entry added"


def mutate_severity(case: Path) -> str:
    path = case / "erc.json"; data = load(path)
    data["included_severities"] = [item for item in data["included_severities"]
                                   if item != "warning"]
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n")
    return "warning removed from ERC included_severities"


def mutate_pdf(case: Path) -> str:
    path = case / "schematic.pdf"; data = path.read_bytes()
    path.write_bytes(data[:max(64, len(data)//2)])
    return "native PDF truncated to half bytes"


def mutate_package(case: Path) -> str:
    path = case / "runtime.json"; data = load(path)
    data["producer_package_identity"]["sha256"] = "0"*64
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n")
    return "runtime producer package identity sha256 replaced"


def mutate_plan(case: Path) -> str:
    path = case / "runtime.json"; data = load(path)
    data["producer_plan_binding"]["plan_index"]["sha256"] = "0"*64
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n")
    return "runtime producer plan-index sha256 replaced"


def mutate_missing_erc(case: Path) -> str:
    path = case / "erc.json"; data = load(path); del data["sheets"]
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n")
    return "required native ERC sheets field removed (T10)"


def mutate_runtime_float(case: Path) -> str:
    path = case / "runtime.json"; data = load(path); data["schema_version"] = 2.0
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n")
    return "runtime schema_version integer 2 -> float 2.0"


def mutate_layout_bool(case: Path) -> str:
    path = case / "layout.json"; data = load(path); data["schema_version"] = True
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n")
    return "layout schema_version integer 1 -> boolean true"


def mutate_plan_bool(case: Path) -> str:
    path = case / "runtime.json"; data = load(path)
    data["producer_plan_binding"]["schema_version"] = True
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n")
    return "producer_plan_binding schema_version integer 1 -> boolean true"


def mutate_package_size_float(case: Path) -> str:
    path = case / "runtime.json"; data = load(path)
    value = data["producer_package_identity"]["files"][0]["size"]
    data["producer_package_identity"]["files"][0]["size"] = float(value)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n")
    return "producer package first file size integer -> equal float"


CAUSAL = [
    ("01-value", mutate_value, "부품 속성 불일치 R1"),
    ("02-netpin", mutate_netpin, "net-pin 전수 계약 불일치"),
    ("03-pintype", mutate_pintype, "pin type 계약 불일치"),
    ("04-unit", mutate_unit, "top pin-semantic unit 소유 불일치"),
    ("05-wiregap", mutate_wiregap, "실선 그룹 분리"),
    ("06-missing-orphan", mutate_missing_orphan, "layout sheet 필수 필드 누락"),
    ("07-ignored-erc", mutate_ignored_erc, "ERC 비활성/포함 severity policy 불일치"),
    ("08-severity-missing", mutate_severity, "ERC 비활성/포함 severity policy 불일치"),
    ("09-pdf-damaged", mutate_pdf, "PDF text 검사가 unknown 상태로 실패"),
    ("10-producer-package", mutate_package, "producer package identity"),
    ("11-producer-plan", mutate_plan, "producer_plan_binding"),
    ("12-required-erc-missing", mutate_missing_erc, "ERC sheets 구조 불일치"),
]
STRICT = [
    ("14-runtime-schema-float", mutate_runtime_float, "runtime schema_version"),
    ("15-layout-schema-bool", mutate_layout_bool, "layout schema_version"),
    ("16-plan-schema-bool", mutate_plan_bool, "producer_plan_binding schema_version"),
    ("17-package-size-float", mutate_package_size_float, "producer package identity"),
]
SCOPE_CLAIMS = [
    ("18-t11-pcb-distance", "schematic_position_as_pcb_distance",
     "decoupling/geometry 결과를 PCB 거리 checked로 승격"),
    ("19-t12-ratings", "voltage_current_rating_and_sequencing",
     "power audit 결과를 전압·전류 정격·sequencing checked로 승격"),
    ("20-t13-t15-manufacturing-ready", "pcb_manufacturing_energization_physical_safety",
     "aggregate review를 DFM·제조·발주 READY로 승격"),
]


def invoke(case: Path, registry: Path, registry_sha: str):
    report = case / "report.json"
    argv = [sys.executable, str(VERIFIER), "--project-root", str(PROJECT),
            "--registry", str(registry), "--registry-sha256", registry_sha,
            "--contract", str(case/"runtime.json"), "--netlist", str(case/"netlist.xml"),
            "--layout", str(case/"layout.json"), "--erc", str(case/"erc.json"),
            "--pdf", str(case/"schematic.pdf"), "--report", str(report),
            "--pdf-text-tool", "/usr/bin/pdftotext"]
    completed = subprocess.run(argv, cwd=case.parent, text=True, capture_output=True)
    (case/"stdout.txt").write_text(completed.stdout, encoding="utf-8")
    (case/"stderr.txt").write_text(completed.stderr, encoding="utf-8")
    payload = load(report) if report.is_file() else {}
    return argv, completed, payload


def result_record(case: Path, name: str, description: str, argv, completed,
                  payload, expected_fragment: str | None, expected_pass: bool) -> dict:
    errors = payload.get("errors", [])
    hash_only = any("runtime-CLI 입력 SHA 불일치" in value for value in errors)
    causal = expected_fragment is None or any(expected_fragment in value for value in errors)
    passed = completed.returncode == 0 and payload.get("status") == "PASS"
    assertion = passed if expected_pass else (
        completed.returncode != 0 and payload.get("status") == "FAIL"
        and causal and not hash_only)
    return {"case": name, "description": description, "argv": argv,
            "rc": completed.returncode, "status": payload.get("status", "NO_REPORT"),
            "expected": "PASS" if expected_pass else "FAIL",
            "expected_error_fragment": expected_fragment or "not_applicable",
            "first_error": (errors or [""])[0], "causal_assertion_matched": causal,
            "rejected_only_by_input_hash": hash_only, "assertion_passed": assertion,
            "runtime_sha256": sha(case/"runtime.json"),
            "report_sha256": sha(case/"report.json") if (case/"report.json").is_file() else "missing"}


def run_copy_case(source: Path, output: Path, name: str, mutation=None,
                  expected_fragment: str | None = None, expected_pass: bool = False):
    case = output/name; copy_inputs(source, case)
    before = {key: sha(case/value) for key, value in INPUT_NAMES.items()}
    description = "unmodified actual current native copy"
    if mutation: description = mutation(case)
    refresh_runtime(case)
    after = {key: sha(case/value) for key, value in INPUT_NAMES.items()}
    argv, completed, payload = invoke(case, REGISTRY, REGISTRY_SHA256)
    result = result_record(case, name, description, argv, completed, payload,
                           expected_fragment, expected_pass)
    result.update({"input_sha256_before_mutation": before,
                   "input_sha256_after_mutation_and_runtime_reseal": after,
                   "registry_expected_sha256": REGISTRY_SHA256})
    dump_new(case/"result.json", result)
    return result


def run_registry_bool(source: Path, output: Path):
    name = "13-registry-schema-bool"; case = output/name; copy_inputs(source, case)
    registry = copy.deepcopy(load(REGISTRY)); registry["schema_version"] = True
    reg = case/"registry-schema-bool.json"; dump_new(reg, registry); refresh_runtime(case)
    argv, completed, payload = invoke(case, reg, sha(reg))
    result = result_record(case, name,
        "원 bool survivor 재현: registry schema_version integer 1 -> boolean true; caller copy SHA 고정",
        argv, completed, payload, "registry schema_version은 integer 1이어야 함", False)
    result.update({"original_survivor_replayed": True, "registry_copy_sha256": sha(reg),
                   "original_registry_sha256": REGISTRY_SHA256})
    dump_new(case/"result.json", result); return result


def run_scope_claim(source: Path, output: Path, name: str, key: str, claim: str,
                    review_dir: Path | None):
    case = output/name; copy_inputs(source, case)
    semantic = copy.deepcopy(load(SEMANTIC)); semantic["scope_limits"][key] = "checked"
    sem = case/"semantic-scope-claim.json"; dump_new(sem, semantic)
    registry = copy.deepcopy(load(REGISTRY)); registry["profiles"][PROFILE_ID]["semantic_contract"] = str(sem.relative_to(PROJECT)); registry["profiles"][PROFILE_ID]["sha256"] = sha(sem)
    reg = case/"registry-scope-claim.json"; dump_new(reg, registry); refresh_runtime(case)
    argv, completed, payload = invoke(case, reg, sha(reg))
    expected = f"scope_limits가 검증기 예약 scope를 확장할 수 없음: {key}=checked"
    result = result_record(case, name, claim, argv, completed, payload, expected, False)
    receipts = []
    if review_dir is not None:
        for path in sorted(review_dir.glob("*.json")):
            receipts.append({"path": str(path), "sha256": sha(path)})
    result.update({"semantic_copy_sha256": sha(sem), "registry_copy_sha256": sha(reg),
                   "original_semantic_sha256": SEMANTIC_SHA256,
                   "original_registry_sha256": REGISTRY_SHA256,
                   "actual_review_receipts": receipts,
                   "boundary": "checked 주장 승격 거부; PCB거리·정격·DFM 알고리즘 실증 아님"})
    dump_new(case/"result.json", result); return result


def build_parser():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True,
                        help="current collector PASS native evidence directory의 absolute path")
    parser.add_argument("--output", type=Path, required=True,
                        help="project root 아래의 존재하지 않는 새 output directory")
    parser.add_argument("--review-responses", type=Path,
                        help="선택 actual review responses directory")
    parser.add_argument("--dry-run", action="store_true",
                        help="파일을 읽거나 쓰지 않고 고정 계약과 mutation 목록만 출력")
    return parser


def dry_run(args) -> int:
    require(args.source.is_absolute() and args.output.is_absolute(),
            "dry-run에서도 --source/--output은 absolute path여야 함")
    value = {"status": "DRY_RUN_ONLY", "writes": 0, "model_runs": 0,
             "project_root": str(PROJECT), "source": str(args.source),
             "output": str(args.output), "package_identity": PACKAGE_SHA256,
             "registry_sha256": REGISTRY_SHA256, "semantic_sha256": SEMANTIC_SHA256,
             "causal_cases": [item[0] for item in CAUSAL],
             "bool_survivor_replay": "13-registry-schema-bool",
             "strict_cases": [item[0] for item in STRICT],
             "scope_cases": [item[0] for item in SCOPE_CLAIMS],
             "controls": ["00-control", "99-green2"]}
    print(json.dumps(value, ensure_ascii=False, indent=2))
    return 0


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    if args.dry_run:
        return dry_run(args)
    source = under_project(args.source, "source", must_exist=True)
    output = under_project(args.output, "output", must_exist=False)
    require(output != source and source not in output.parents and output not in source.parents,
            "source와 output은 분리돼야 함")
    review_dir = None
    if args.review_responses is not None:
        review_dir = under_project(args.review_responses, "review-responses", must_exist=True)
    oracle = validate_oracle()
    package_identity = import_identity_helper()
    package, source_before, native_inputs = validate_source(source, package_identity)
    source_runtime_sha = sha(source/"runtime.json")
    source_report_sha = sha(source/"static-report.json")
    registry_before = sha(REGISTRY); semantic_before = sha(SEMANTIC)
    output.mkdir(parents=True, exist_ok=False)
    baseline = {"schema_version": 1, "source": str(source),
                "current_package_identity": package["sha256"], **oracle,
                "source_files_before": source_before, "native_inputs": native_inputs,
                "source_runtime_sha256": source_runtime_sha,
                "source_static_report_sha256": source_report_sha,
                "scope": "actual current native input copies only; no CAD/MCP/GUI mutation"}
    dump_new(output/"source-baseline.json", baseline)
    results = [run_copy_case(source, output, "00-control", expected_pass=True)]
    results.extend(run_copy_case(source, output, name, mutation, fragment)
                   for name, mutation, fragment in CAUSAL)
    results.append(run_registry_bool(source, output))
    results.extend(run_copy_case(source, output, name, mutation, fragment)
                   for name, mutation, fragment in STRICT)
    results.extend(run_scope_claim(source, output, name, key, claim,
                                   review_dir) for name, key, claim in SCOPE_CLAIMS)
    results.append(run_copy_case(source, output, "99-green2", expected_pass=True))
    source_after = source_file_hashes(load(source/"layout.json"))
    unchanged = (source_before == source_after and registry_before == sha(REGISTRY)
                 and semantic_before == sha(SEMANTIC)
                 and source_runtime_sha == sha(source/"runtime.json")
                 and source_report_sha == sha(source/"static-report.json"))
    summary = {"schema_version": 1,
               "status": "PASS" if all(row["assertion_passed"] for row in results) and unchanged else "FAIL",
               "results": results,
               "counts": {"controls": sum(row["case"] in {"00-control", "99-green2"} and row["assertion_passed"] for row in results),
                          "causal_rejected": sum(row["case"].startswith(tuple(f"{i:02d}" for i in range(1,13))) and row["assertion_passed"] for row in results),
                          "original_bool_survivor_rejected": int(next(row for row in results if row["case"] == "13-registry-schema-bool")["assertion_passed"]),
                          "strict_rejected": sum(row["case"] in {item[0] for item in STRICT} and row["assertion_passed"] for row in results),
                          "scope_claims_rejected": sum(row["case"] in {item[0] for item in SCOPE_CLAIMS} and row["assertion_passed"] for row in results)},
               "source_files_before": source_before, "source_files_after": source_after,
               "originals_unchanged": unchanged,
               "boundaries": {"cad_mcp_gui_writes": 0,
                              "candidate_values_used_to_change_oracle": False,
                              "producer_identity": "copied from actual runtime; not synthesized",
                              "scope_claims": "claim escalation refusal only"}}
    dump_new(output/"suite-summary.json", summary)
    files = []
    for path in sorted(output.rglob("*")):
        if path.is_file() and path.name != "SHA256SUMS":
            files.append((sha(path), path.relative_to(output).as_posix()))
    (output/"SHA256SUMS").write_text("".join(f"{value}  {path}\n" for value, path in files), encoding="utf-8")
    print(json.dumps({"status": summary["status"], "output": str(output),
                      "counts": summary["counts"], "originals_unchanged": unchanged},
                     ensure_ascii=False))
    return 0 if summary["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
