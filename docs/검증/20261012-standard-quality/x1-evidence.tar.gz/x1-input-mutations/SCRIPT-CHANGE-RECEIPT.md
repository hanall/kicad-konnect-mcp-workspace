# X1 mutation harness d99 -> bd60 변경 영수증

## 언제·왜

준비 완료 시점의 script는 `--review-responses`를 directory로만 받아 `*.json`을 열거했다. Root의 실행 GO에서 실제 입력이 directory가 아니라 `root-actual-review/dispatch-records.json` 단일 파일로 지정됐다. run-01 실행 전에 이 단일 파일을 project root 안의 regular file로 검증하고 그대로 하나의 review receipt로 결속하도록 변경했다. 그 뒤 bd60 script로 run-01을 한 번 실행했다.

## 변경 범위

변경은 review evidence 인자 처리 네 곳뿐이다: parameter 이름, 단일 file/dir 분기, project-root 경계 확인, call-site 변수명. causal 12개, bool replay 1개, strict 4개, scope claim 3개, mutation 함수, 기대 오류, verifier argv, 판정식, control/GREEN2, 원본 불변 검사는 바뀌지 않았다. 두 script의 해당 AST inventory가 exact 동일함을 JSON receipt에 기록했다. 따라서 변이 판정 변경이 아니라 actual GO의 review receipt 형태를 수용하는 실행 경로 조정이다.

## bytes와 실행 결속

- 준비 원본: `run_mutations.pre-go-d99c8186.py` SHA `d99c8186cdc230169bf121da17fc4cab6d271de9fbe179c8fc2b48545534f6a5`
- 실행본: `run_mutations.py` SHA `bd60cead796c443f00b89d9f24ff99de83b32a93c3f8b98724bbe95b4ab7a81a`
- 원 준비 manifest `SHA256SUMS`는 덮지 않았고 SHA `ca13d8cb9118415df6216214f47c85b73b916eb0e879367ae64d849571694f7e` 그대로다.
- actual 실행 argv, rc, stdout/stderr, suite summary와 output manifest SHA는 `SCRIPT-CHANGE-RECEIPT.json`에 결속했다.
- 이 보충 영수증을 만들면서 변이 suite를 추가 실행하지 않았다.
