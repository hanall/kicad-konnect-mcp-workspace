# X1 루트 페이지 정식 사전 계획 v1

대상 x1.kicad_sch, design, 제목 sense-filter, A4 landscape 한 페이지. 일반 독자가 J1 입력에서 J2 출력까지 분압과 병렬 필터 및 GND 반환을 실선으로 추적하도록 구성한다. 공통 계획 plans/common.md SHA fcfcefd1cd98245d9eaee1ec6fef1f83988d7dcc35bb7d05f8bcc5f940f4e543. 원문 SHA는 아래와 같다.
- sources/native-assumptions.refined.json: `5e7225c269af5c57b491eed60bac61257b0ed9300d82d7cf98a0c3f5941945e5`
- sources/requirements.refined.md: `2f7030ee8a587730ff72d53ce69a447f8daa4a3cdf1dfa39fc5dffbcd4a3b91b`
- sources/symbol-endpoints.refined.json: `0600393a08d5fcc2aeac9f721a23f773348dac7294f99c59fca80f98174173c5`
- sources/unit-source-observation.json: `a4fe2ed7e7b02e520ef62243a3c3023db8f0cd01ba5d175e9ed72847e2cbd5e6`

## 부품·핀 소유
전 부품은 이 루트에 unit 1 하나씩, 모든 pin 1/2는 passive, footprint는 빈 문자열이다. J1=Connector_Generic:Conn_01x02/value VIN, J2=같은 symbol/value SENSE, R1/R2=Device:R/value 10k, C1=Device:C/value 10n. 제조용 package 매핑은 범위 밖이다. 설치 source 관측의 단일 unit과 extends 없음은 봉인된 근거를 사용하고, fresh get_symbol_info와 배치본 endpoint를 대조한다. 불완전한 조회를 쓰기 batch에 섞지 않는다.

## 배치와 읽는 순서
J1은 (66.04,76.20) mm 부근에서 핀이 오른쪽으로 향하도록 배치한다. R1은 (101.60,76.20), pin1 왼쪽/pin2 오른쪽의 수평 방향이다. R2는 (134.62,96.52), C1은 (170.18,96.52)에서 pin1 위/pin2 아래로 배치한다. J2는 (208.28,76.20)에서 pin이 왼쪽을 향한다. 정확한 rotation/mirror 인자는 fresh schema 및 실제 endpoint로 결정하고 방향이 맞지 않으면 배선 전 정식 MCP로 교정한다. J1 pin2가 위쪽에 배치되는 회전이면 왼쪽 우회 경로로 y=119.38 반환선에 연결한다. 숫자 핀과 선을 읽을 충분한 간격을 유지한다. field는 자동 배치를 먼저 확인하며 선과 겹치면 정식 field 위치 API로 이동한다.

## 실선 계약
VIN: J1.1 → R1.1. SENSE: R1.2에서 y=76.20 수평 trunk로 R2.1, C1.1의 수직 가지 및 J2.1까지 연결한다. GND: J1.2, R2.2, C1.2, J2.2를 y=119.38 수평 반환 trunk로 연결한다. J1.2 우회는 VIN과 접촉하지 않게 x=58.42로 왼쪽 우회 또는 실제 핀 방향에 맞는 분리 경로를 사용한다. J2.2는 pin에서 약 8 mm 왼쪽 위치에서 아래 반환선으로 내려간다. trunk는 분기점마다 wire를 분할하고 T 접점 junction을 둔다. local label VIN/SENSE/GND는 각 실선의 여유 있는 구간에 하나씩만 둔다. label로 연결 성분을 합성하지 않는다. 분기 이외 교차를 만들지 않는다.

## 포트·반환·보존
페이지 간 포트는 없고 J1/J2가 외부 경계다. VIN과 SENSE는 GND를 공통 신호 반환으로 사용한다. PE, chassis, Kelvin, floating domain, power source 모델은 추가하지 않는다. 전기적 승인 변경은 없으며 semantic의 5부품/10핀/3망/값/빈 footprint를 보존한다. PCB 기본 생성 외 편집, no-connect, PWR_FLAG, 전원 symbol, global label은 금지한다.

## 검증·실패 대응
fresh runtime schema → project 생성과 project library 등록 → 부품 배치 → 10핀 endpoint/unit/type 조회 → 실선·junction·label → 저장본 전수 조회 → fresh native 수집 순서다. 각 batch 전 plan SHA·lock을 guarded adapter가 재대조하고 요청/응답/원 rc/파일 SHA를 남긴다. partial/error/timeout은 적용상태를 먼저 조사한다. native XML은 exact net membership과 unit/type/value/lib/footprint를 확인하고 layout은 wire-only 3 연결 성분, orphan0, short0, bounds unresolved0을 검사한다. ERC는 오류/경고/제외 0과 기본 ignored 네 항목을 공개한다. PDF 전체와 회로 확대에서 field·핀·선·junction·제목을 자체 판독하고 GUI 검토나 독립 검토로 확대하지 않는다.

## unknown·다음 동작
현재 CAD 첫 쓰기는 미착수이며 첫 mutation 시각은 별도 evidence에 남긴다. 실제 endpoint·fresh runtime·native 결과는 앞으로 관측해 닫는다. GUI 왕복, 실물 package, 정격, 동적 동작, PCB, 제조·통전 안전은 미검증 범위다. 사전 계획 SHA는 PRE-CAD-SEAL.json에 봉인하고 허용 범위를 넘는 변경이 필요하면 작성 중단 후 보고한다.
