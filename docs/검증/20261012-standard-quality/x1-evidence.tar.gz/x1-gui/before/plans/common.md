# X1 정식 공통 사전 계획 v1

모드 design. 사용자 sameCASE 제한적 GO와 TASK.md가 권위다. 단일 작성자는 이 세션 Codex이며 독립 검토자는 사용자 측 Root다. GUI는 열지 않는다. saved CAD는 전부 미생성, 프로젝트 lock은 없음으로 baseline.json에 기록했다. 다른 작업과 원제품을 조회하거나 수정하지 않는다.

workspace-root: /home/hanol/kicad-konnect-mcp-workspace/.artifacts/20261012-040121-standard-quality/x1-managed/case
project-dir: /home/hanol/kicad-konnect-mcp-workspace/.artifacts/20261012-040121-standard-quality/x1-managed/case/project
허용 파일은 x1.kicad_pro, x1.kicad_sch, x1.kicad_pcb, sym-lib-table 네 개뿐이다. PCB는 create_project의 기본 생성만 허용한다. 원문, registry, semantic, package는 불변이다. 이 격리 X1 소회로 자체에서 capability와 정적 계약을 확인한다.

profile independent-x1-sense-filter-v2; registry SHA b67c028146ddb06e1c3f5e5510fbfd275d6ab3925d2e5a772bac7ac528e55980; semantic SHA 3c5adc5d5f80e30b07697a7c8721c0457acb9c2adbb59a90959ad2f985d15f6b; package SHA c77ca8ed6783532aaad86496f868f9d22af376c5756c9464c35938bdaf3ce3ca.

## 원문 SHA
- sources/native-assumptions.refined.json: `5e7225c269af5c57b491eed60bac61257b0ed9300d82d7cf98a0c3f5941945e5`
- sources/requirements.refined.md: `2f7030ee8a587730ff72d53ce69a447f8daa4a3cdf1dfa39fc5dffbcd4a3b91b`
- sources/symbol-endpoints.refined.json: `0600393a08d5fcc2aeac9f721a23f773348dac7294f99c59fca80f98174173c5`
- sources/unit-source-observation.json: `a4fe2ed7e7b02e520ef62243a3c3023db8f0cd01ba5d175e9ed72847e2cbd5e6`

## 기능·전기·시각
A4 landscape 297×210 mm 한 페이지 sense-filter. J1 왼쪽 입력, R1 수평 직렬, R2와 C1 아래 방향 shunt, J2 오른쪽 출력. 5부품/10핀/3망과 값·빈 footprint를 semantic 그대로 구현한다. 1.27 mm 배치 격자, 기본 KiCad field 크기를 우선하며 텍스트와 선을 분리한다. 본문은 x=65~210, y=75~120 mm 범위에 배치한다. 자세한 ref.pin과 경로는 root.md를 따른다. GND는 단일 신호 반환이며 PE/chassis/절연 반환이 아니다. 전압·전류·허용오차·ADC 부하·동적 성능은 미지정이고 평가하지 않는다. power symbol/PWR_FLAG/global port는 없다. 각 망은 실선 하나의 연결 성분으로 닫고 label은 이름 표시만 한다.

## 정식 실행과 검증 순서
CASE PROBE pass를 확인했다. plans/common.md, plans/root.md, plan-index.json의 SHA를 PRE-CAD-SEAL.json에 첫 쓰기 전에 기록한다. launcher /home/hanol/kicad-konnect-mcp-workspace/scripts/run-konnect.sh, config /home/hanol/kicad-konnect-mcp-workspace/config/konnect.toml, cwd /home/hanol/kicad-konnect-mcp-workspace, version 0.13.0+hanall.1, commit 94f80350cf67db27b179a06a8f6dbebfe4717927을 매 guarded_mcp 연결에서 대조한다. fresh schema 확인 후에만 정확한 요청 인자를 확정한다. 두 설치 symbol directory는 plan-index의 exact mapping으로 project scope 등록만 한다. 배치 후 실제 endpoint를 조회해 회전·핀을 확인한 다음 작은 batch로 실선을 작성한다.

각 요청은 work/requests 아래 새 JSONL을 flush/fsync, atomic rename, 부모 fsync, 전체 readback 후 사용한다. 매 실행 evidence 아래 새 디렉터리를 사용한다. 부분 실패/timeout은 원 rc와 SHA를 보존하고 적용상태 readback 전 반복하지 않는다. offline atomic file commit 후 새 연결에서 저장본 재조회하며 live PCB save는 호출하지 않는다.

native는 HOME=/home/hanol/kicad-konnect-mcp-workspace/.artifacts/20261012-040121-standard-quality/x1-managed/case/native-home, XDG_CONFIG_HOME=/home/hanol/kicad-konnect-mcp-workspace/.artifacts/20261012-040121-standard-quality/x1-managed/case/native-home/.config, TMPDIR=/home/hanol/kicad-konnect-mcp-workspace/.artifacts/20261012-040121-standard-quality/x1-managed/case/work/tmp, APPIMAGE_EXTRACT_AND_RUN=1을 명시한다. KONNECT_GUI_SYNC=0, KONNECT_RUNTIME_HOME=/home/hanol/kicad-konnect-mcp-workspace/.artifacts/20261012-040121-standard-quality/x1-managed/case/runtime, KICAD_API_SOCKET=ipc:///tmp/x1-no-shared-kicad.sock 유지. collect_evidence.py로 owning root kicadxml/PDF/severity-all ERC와 layout/pin/wire/orphan/short를 수집한다. 5부품/10핀/3망, wire coverage, orphan0/short0/bounds unresolved0, ERC 0/0/0 및 계약의 ignored 4종을 확인한다. 전페이지 PDF는 렌더 가능하면 자체 판독한다. GUI 왕복과 독립 시각 검토는 미실행으로 남긴다.

## 차단·인계
unit 미제공 symbol 조회는 INCOMPLETE를 보존하고 unit-source-observation 및 배치 endpoint로 보완한다. CAD·입력·계획·package SHA가 달라지면 진행을 멈추고 원인을 확인한다. 필수 검증 실패를 assertion 완화로 숨기지 않는다. AUTHOR-RESULT.md는 실제 관측 범위·원 rc·남은 unknown을 기록한다. 계획 SHA는 자기참조 대신 PRE-CAD-SEAL.json에 결속한다.
